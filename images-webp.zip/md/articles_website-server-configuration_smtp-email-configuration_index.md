[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# SMTP Email Configuration

 

---

 

## Introduction

 

Connexus uses Office365 for Exchange email services. In order for applications and services deployed at Connexus or Rackspace to use this service as an SMTP server to send emails out to clients and users, we utilise an **SMTP Relay** at Connexus located on CON-SEC1

 

This fundamentally acts as a "middle-man" between the application or service and the SMTP server on O365, allowing us to use simple SMTP authentication and not the multi-factor authentication required by O365.

 

The relay that runs on IIS/SMTP has a Smart Host onwards to the Connexus O365 tenant. see ticket #48766

 

connexus-co-uk.mail.protection.outlook.com

 

This relay in turn links to a connector called "CP-Relay" in O365 (note SPF records are needed on each sending domain).

 

There are two ip addresses bound to the SMTP relay 192.168.30.49 and 192.168.30.65

 

Websites should use 192.168.30.65

 

Transactor should use 192.168.30.49

 

## Transactor TES_MSMQ_Trigger

 

The Transactor TES_MSMQ_Trigger service, which reads from the Microsoft Message Queueing service (MSMQ) in Windows to send emails out from Transactor uses the SMTP relay account details in its configuration file on each Transactor application server.

 

The configuration file on each server is located at:

 

- C:\Program Files (x86)\Transactor\TES_MSMQ\TES_MSMQ_Trigger.exe.config

 

## Websites and Applications

 

The following websites and applications utilise the SMTP relay account details to send emails:

 

- Insure with Audi
- Insure with Porsche
- Insure with SEAT
- Insure with SKODA
- Insure with Volkswagen
- Insure with VWCV
- Velosure

 

All of these applications will store the SMTP relay details in one of two places:

 

1. web.config or app.config file; normally in the <system.net><mailsettings> configuration section
2. ConnexusConfig database, which will be accessed at runtime by injected services