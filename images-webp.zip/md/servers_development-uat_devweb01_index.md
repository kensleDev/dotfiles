[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# DEVWEB01

 

---

 

## Server Details

  **Server Type:** Web **IP Address:** 192.168.204.217  

---

 

Public: 95.138.129.217 (as per ipchicken.com).

 

This is the UAT **IIS** web server for the following websites hosted at Connexus:

 

### VWFS

 

- **Insure with Audi** - [https://insurewithaudi.connexus-test.co.uk/](https://insurewithaudi.connexus-test.co.uk/)
- **Insure with SEAT** - [https://insurewithseat.connexus-test.co.uk/](https://insurewithseat.connexus-test.co.uk/)
- **Insure with SKODA** - [https://insurewithskoda.connexus-test.co.uk/](https://insurewithskoda.connexus-test.co.uk/)
- **Insure with Volkswagen** - [https://insurewithvolkswagen.connexus-test.co.uk/](https://insurewithvolkswagen.connexus-test.co.uk/)
- **Insure with VWCV** - [https://insurewithvwcv.connexus-test.co.uk/](https://insurewithvwcv.connexus-test.co.uk/)
- **Loan Car Insurance** - [https://loancarinsurance.connexus-test.co.uk/](https://loancarinsurance.connexus-test.co.uk/)
- **VWFS Insurance Portal** - [https://vwfsinsuranceportal.connexus-test.co.uk/](https://vwfsinsuranceportal.connexus-test.co.uk/)

 

### Lawshield

 

- [](https://autoglassbodyrepair.lawshield.co.uk/)**Connexus Claim Tracker** - various white-labelled URLs:[](https://claimtracker.connexus.co.uk/) 

- [https://claimtracker-uat.connexus-test.co.uk/](https://claimtracker-uat.connexus-test.co.uk/)
- [https://chubb-claimtracker.connexus-test.co.uk/](https://chubb-claimtracker.connexus-test.co.uk/)
- **Connexus Claim Tracker API** - [https://claimtracker-uat-api.connexus-test.co.uk/](https://claimtracker-uat-api.connexus-test.co.uk/)
- **CMA Core** - [https://core.connexus-test.co.uk/](https://core.connexus-test.co.uk/)
- **Lawshield DSP** - [https://dsp.connexus-test.co.uk/](https://dsp.connexus-test.co.uk/)
- **Hi-Vis** - [https://hi-vis.connexus-test.co.uk/](https://hi-vis.connexus-test.co.uk/)
- **Hi-Vis API** - [https://hi-visapi.connexus-test.co.uk/](https://hi-visapi.connexus-test.co.uk/)
- **Lawshield V6 API** - [https://lawshieldv6-api.connexus-test.co.uk/](https://lawshieldv6-api.connexus-test.co.uk/) (Connexus - Transactor V6 Middleware API)
- **Connexus Policy Validator (API)** - [https://policy-validator-api.connexus-test.co.uk/](https://policy-validator-api.connexus-test.co.uk/)
- **ProClaim API** - [https://proclaim-api.connexus-test.co.uk/](https://proclaim-api.connexus-test.co.uk/) (Connexus - ProClaim Middleware API)
- **Velosure** - [https://velosure.connexus-test.co.uk/](https://velosure.connexus-test.co.uk/)

 

---