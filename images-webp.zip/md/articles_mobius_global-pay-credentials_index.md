[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Global Pay credentials

 

---

 

![](../images-webp/image_6.webp)

 

![](../images-webp/image_7.webp)

 

Signed up 21/02/25 via invite, instigated from Open GI who have the agreement with Global Pay.

 

 

 

**Details**

 

**Lawshield**

 

Client ID: CLAWS001LS

 

Merchant ID: 1782475

 

Acquirer: Barclays - acquirer BIN 523065

 

**Volkswagen**

 

Client ID: CLAWS001VW

 

Merchant ID: 1783116

 

Acquirer: Barclays - acquirer BIN 523065

 

 

 

Note that the merchant ID's are configured for MOTO, for use by the call centre.

 

No Merchant ID has been configured for e-commerce via Mobius API as a web transaction, as we will be using our own existing payment API.

 

 

 

Further details:

 

![](../images-webp/image_8.webp)