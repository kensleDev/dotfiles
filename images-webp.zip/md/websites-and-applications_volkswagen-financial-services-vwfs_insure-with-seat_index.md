[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Insure with SEAT

 

---

   

## Website Details

  **Live URL:** [https://www.insurewithseat.co.uk/](https://www.insurewithseat.co.uk/) **UAT URL:** [https://insurewithseat.connexus-test.co.uk/](https://insurewithseat.connexus-test.co.uk/)    .NET Framework C# ASP.NET MVC Entity Framework 6 HTML SCSS Bootstrap JavaScript jQuery AngularJS   

---

 

Insure with SEAT is a public, customer-facing insurance quote-and-buy website for Volkswagen Financial Services (VWFS) insurance products. The website provides information relating to:

 

- Car Insurance
- Extended Warranty
- Ensurance
- GAP Insurance

 

This website provides quote-and-buy functionality for two of these:

 

- Extended Warranty
- Ensurance

 

It also provides functionality for customers making claims, including:

 

- Claim Tracker
- FNOL Claim Notification
- Approved Paint & Body Centre Locator

 

## Content Management

 

The Insure with SEAT website is integrated with the **Umbraco Content Management System (CMS)**. This provides a platform for the management and maintenance of the majority of the text, graphics and documentation available to customers on the website.

 

## Integrations

 

The Insure with SEAT website integrates with several third-party services hosted both internally at Connexus and externally:

 

- **OpenGI Transactor v6** - internal, used for quoting and inception of insurance policies
- **Eclipse ProClaim** - internal, used for claims functionality
- **FastCode Database** - internal, used for address lookups
- **Carweb** - external, used to look up vehicle details from a VRM
- **BottomLine** - external, used to validate a customers' bank account details
- **2SMS** - external, used for sending SMS text messages

 

## Analytics Details

 

 

 

## Further Reading

 

Further details about technologies, architecture and insurance products can be found in other areas of the Knowledgebase:

 

- [Insure with Websites - Architecture](/articles/vwfs-insure-with-websites/vwfs-websites-architecture/)
- [VWFS Extended Warranty](/insurance-products/volkswagen-financial-services-vwfs/vwfs-extended-warranty/)
- [VWFS Ensurance](/insurance-products/volkswagen-financial-services-vwfs/vwfs-ensurance/)