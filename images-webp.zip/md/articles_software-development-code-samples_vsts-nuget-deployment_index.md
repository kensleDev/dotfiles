[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# VSTS NuGet Deployment

 

---

 

## Publish NuGet package

 

A full example can be found here: [https://www.visualstudio.com/en-us/docs/package/nuget/publish](https://www.visualstudio.com/en-us/docs/package/nuget/publish)

 

First, we need to connect to our feed for Azure DevOps. Log into Azure DevOps and navigate to packages in the Connexus project. This can be found in the Build and release tab.

 

Then locate and click the Connect to feed button:

 

![](../images-webp/image_78.webp)

 

This should open a dialog like below:

 

![](../images-webp/image_79.webp)

 

### Step 1:

 

Download Nuget and VSTS Credential Provider by clicking the link provided. Copy this to a new location called C:\Nuget_VSTS

 

### Step 2: Add Our Feed

 

Open a command line and browse to the newly created location

 

```
cd C:\ Nuget_VSTS
```

 

We then want to connect to our by running the following command

 

```
nuget.exe sources Add -Name "Connexus" -Source "https://connexusdigital.pkgs.visualstudio.com/_packaging/Connexus/nuget/v3/index.json"
```

 

This will ask you for your VSTS credentials.

 

Once you have logged in successfully you are then associated with the Connexus Feed. You shouldn't have to do this again. But will be prompted when you run step 3 if there is an issue.

 

### Step 3: Push a package.

 

Now we are associated with the Connexus feed. locate the package you want to push and run the following. Changing my_package.nupkg to the location of your package

 

```
nuget.exe push -Source "Connexus" -ApiKey VSTS my_package.nupkg
```

 

For example:

 

```
C:\Nuget_VSTS\nuget.exe push -Source "Connexus" -ApiKey VSTS C:\inetpub\ConnexusNuGet\Packages\ConnexusComponents.VehicleLookup\1.1.1\ConnexusComponents.VehicleLookup.1.1.1.nupkg
```

 

The script should execute and state that your package has been pushed successfully. If there any issues the script will let you know.

 

### Step 4: Complete

 

To confirm that your package has been published correctly. Refresh the feed and it should appear in the list:

 

![](../images-webp/image_80.webp)