[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Open GI FTP Connection details

 

---

 

# Open GI FTP Connection details

 

**USE THIS ONE FOR OPEN GI FTP**
Server: ftp.opengi.co.uk 
Port: 21 
Protocol: Explicit FTP over SSL 
Username: Lawshield
Password: !zxtr5JrELn?6@aH

 

**FASTCODE / POSTCODE UPDATES**

 

These should be released bi-annually, however this service from Open GI seems to be sporadic at best.

 

ftps.opengihosting.com
Protocol: Use explicit FTP over TLS if available
Username: paf_download
Password: 9Y9ymgCWewC8gUznAChH

 

*** OLD ONE DOESNT WORK ANY MORE**
* Server: ftp.opengi.co.uk 
* Port: 21 
* Protocol: Explicit FTP over SSL 
* Username: connexus1 
* Password: X9WxjPg57s=NSB37