[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Data Models

 

---

 

Below are the specifications of entity framework data models used by the Connexus CMS:

 

#### Data Models

 

 

 

###### Article

 

 

 

| Property Name | Property Type | Comments |
| --- | --- | --- |
| Id | int | Primary key |
| Status | ArticleStatus | See ArticleStatus enumeration below, required field |
| Headline | string | Required field |
| SubHeading | string | Required field |
| Category | int | Required field, values stored in json file to allow modification without the need to re-deploy the code. |
| ImageUrl | string | Required field |
| Body | string | Required field, contains html |
| Author | string | Required field |
| SortOrderIndex | int | Required field, used to determain the order of which the articles will appear on the website |
| ConnexusBrand | ConnexusBrand | See ConnexusBrand enumeration below, required field |
| CreatedDate | DateTime | Required field |
| PublishedDate | DateTime |  |

 

 

 

###### FAQ

 

 

 

| Property Name | Property Type | Comments |
| --- | --- | --- |
| Id | int | Primary key |
| Status | FAQStatus | See FAQStatus enumeration below, required field |
| Question | string | Required field |
| Category | int | Required field, values stored in json file to allow modification without the need to re-deploy the code. |
| Answer | string | Required field, contains html |
| SortOrderIndex | int | Required field, used to determain the order of which the articles will appear on the website |
| ConnexusBrand | ConnexusBrand | See ConnexusBrand enumeration below, required field |
| CreatedDate | DateTime | Required field |
| PublishedDate | DateTime |  |

 

 

 

#### Enumerations used

 

 

 

###### ArticleStatus

 

Archived = 1,
Testing = 2
Live = 3

 

 

 

###### FAQStatus

 

Archived = 1,
Testing = 2
Live = 3

 

 

 

###### ConnexusBrand

 

Velosure = 1