[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Update letter or email templates

 

---

 

Open TES Tool Suite 

 

Log in 

 

--> Document Manager 

 

--> Configuration 

 

 

 

*Note that in this context "Documents" is actually a document pack which may contain multiple letters/emails that get sent to a customer at the same time. Individual letters/emails are "templates" in this context.* 

 

 

 

To update a template: 

 

1. Select the required template from the list
2. Expire this version by  

1. clicking Expire button
2. Set the End Date to current date and select a time that this template expires (give yourself enough time to complete the update.
3. Click Expire
3. Update by 

1. Reselecting the template
2. Click Update button
3. Browse for new version ( ensure correct folder if doing multiple brands!)
4. Start date will have been set automatically as 1 min after the Expire time
5. Set End Date as todays date but in 2099 at 0900
6. Click update.

 

 

 

As a check, unclick 'Current only' update template will be blue to indicate that it is not yet in use (previous version not expired yet).