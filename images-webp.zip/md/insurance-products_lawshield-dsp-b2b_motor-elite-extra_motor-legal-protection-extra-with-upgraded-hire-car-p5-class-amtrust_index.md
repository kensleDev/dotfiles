[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Motor Legal Protection Extra with Upgraded Hire Car P5 Class AmTrust

    **Underwriter:** AmTrust Europe Limited **Net Premium:** £31.25     **UAT Scheme Table Id:** 1557 **UAT Scheme File Name:** 4352ALJ9.wpd  

---

  **Live Scheme Table Id:** 1518 **Live Scheme File Name:** 4358K418.wpd    

---

 

## Product

 

- [Motor Elite Extra](/insurance-products/lawshield-dsp-b2b/motor-elite-extra/)

 

---

 

## Scheme Description

 

The Motor Elite Extra AmTrust **Product** has a number of different scheme files; some for variations in cover types, others are specific to particular brokers.

 

The **Motor Legal Protection Extra with Hire Car P5 Class AmTrust** scheme is only available to **Towergate Antur** brokers.

 

### Scheme Validity

 

There is a DateDiff operation ensuring that policy start dates are on or after 1st June 2020 when the scheme started.

 

### Broker-Specific Logic

 

The scheme checks that the **Subagent Id** = 15 (Towergate Antur). It declines for all other brokers.

 

### Risk Data Validation

 

The scheme then checks that the **Hire Vehicle Id** = 6 (P5 Class Hire Vehicles) to ensure quotes can only be obtained for P5 Class Hire Vehicles. It declines in all other cases.

 

---