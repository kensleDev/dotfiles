[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Displaying SSRS Reports in an ASP.Net MVC Site

 

---

 

Microsoft provide a Nuget package for viewing reports in MVC, however this is a wrapper around a WebForm ReportViewerWebForm.aspx which is installed into the root of the project:

 

```
Install-Package ReportViewerForMvc
```

 

The ReportViewer is setup in a controller action as follows; note that the server URL, path and authentication details are held in Web.config in this case:

 

```
public ActionResult Index()
{
    var reportViewer = new ReportViewer();
    reportViewer.ProcessingMode = ProcessingMode.Remote;
    reportViewer.SizeToReportContent = true;
 
    reportViewer.ServerReport.ReportServerUrl = new Uri(AppSettings.ReportServerUrl);
    reportViewer.ServerReport.ReportPath = AppSettings.ReportPath;
    reportViewer.ServerReport.ReportServerCredentials = new ReportServerCredentials(AppSettings.SsrsUsername,
                                                                                    AppSettings.SsrsPassword,
                                                                                    AppSettings.SsrsDomain);
    reportViewer.ServerReport.SetParameters(new ReportParameter[] { new ReportParameter("UserID", Session["UserId"].ToString()) });
 
    ViewBag.ReportViewer = reportViewer;
    return View();
}
```

 

And the ReportViewer can then be rendered in an ASP.Net MVC view as follows:

 

```
@Html.ReportViewer(ViewBag.ReportViewer as Microsoft.Reporting.WebForms.ReportViewer)
```

 

Note that there is no concrete implementation of IReportServerCredentials supplied out of the box; MSDN recommends the following implementation:

 

```
/// <summary>
/// Local implementation of IReportServerCredentials
/// </summary>
public class ReportServerCredentials : IReportServerCredentials
{
    private string _userName;
    private string _password;
    private string _domain;
 
    public ReportServerCredentials(string userName, string password, string domain)
    {
        _userName = userName;
        _password = password;
        _domain = domain;
    }
 
    public WindowsIdentity ImpersonationUser
    {
        get
        {
            // Use default identity.
            return null;
        }
    }
 
    public ICredentials NetworkCredentials
    {
        get
        {
            // Use default identity.
            return new NetworkCredential(_userName, _password, _domain);
        }
    }
 
    public bool GetFormsCredentials(out Cookie authCookie, out string user, out string password, out string authority)
    {
        // Do not use forms credentials to authenticate.
        authCookie = null;
        user = password = authority = null;
        return false;
    }
}
```

 

The server and path were obtained by doing File-> Save As in SSRS.