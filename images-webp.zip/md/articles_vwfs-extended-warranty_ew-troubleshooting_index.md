[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# EW - Troubleshooting

 

---

 

### EW gives a standard rate when the user was expecting a discounted rate

 If the policy number is supplied but not the reg plate or VIN then these need to be looked up on Transactor:   

```
DECLARE @PolicyNumber VARCHAR(30) = 'EWC199693'SELECT TOP 10 vd.REGISTRNO, vd.VINNUMBERFROM CUSTOMER_POLICY_DETAILS cpdJOIN USER_VW_VEHDETS vd ON cpd.POLICY_DETAILS_ID = vd.POLICY_DETAILS_IDWHERE POLICYNUMBER = @PolicyNumber
```

    Look in the VWFSMarketing database to see if there is a policy expiring on the expected date:    

```
DECLARE @RegistrationNo NVARCHAR(24) = 'KRZ5931'DECLARE @VinNumber VARCHAR(200) = 'TMBFM6NJ6GZ140868'SELECT TOP 10 * FROM WarrantyWHERE RegistrationNo = @RegistrationNoOR ChasisNumber = @VinNumber
```

    

## EW fails to incept for a particular vehicle

 

EW fails to incept for a particular vehicle

 

Run through the debugger, breakpoint QuoteAndSaveProspect in ExtendedWarrantyTransactorInteractions, if the error is at global::Transactor.Web.Engine.Helpers.UserHelper.B2C.SaveProspect then try comparing the data parameter in this method against that for a vehicle that works.

 

If nothing looks suspicious bar the encrypted data then deserialize the data parameter in QuoteAndSaveProspect in ExtendedWarrantyTransactorInteractions and compare this against that for a vehicle that works.

 

Hint - it's likely to be Abi1

 

Try the following on UAT & Live Transactor, the latter being more likely to be correct as Open GI update it:

 

```
SELECT TOP 10 * FROM SYSTEM_LIST_VEHICLE WHERE ABICODE = '90316567'
```

 

If that returns data on live but not UAT then that's the problem so in Redgate SQL Data Compare:
Select the source and target Transactor databases
Tables & views, enter SYSTEM_LIST_VEHICLE in the search box and select
Highlight the SYSTEM_LIST_VEHICLE row and click Where clause
Enter ABIMAKE = 'VOLKSWAGEN'
Save and Compare

 

## Troubleshoot VWCV website failing to obtain quote from Transactor

 

Firstly put a breakpoint in SmartExtendedWarrantyData -> SetValuesFromVehicleLookupResult and obtain the ABI code. Ensure this exists in the database:

 

```
SELECT TOP 10 * FROM SYSTEM_LIST_VEHICLE WHERE ABICODE = @AbiCode
```

 

Check to see whether the rates exist. If the vehicle is a Caddy Maxi then VWFS don't provide rates and they may not have been copied from Caddy:

 

Get the ID of the current rates:

 

```
SELECT * FROM TGSLUser.RATE_EW_DATES_RANGE
```

 

The current ID is 6, so check the rates table:

 

```
SELECT * FROM TGSLUser.RATE_VWCV_RATES_V2 WHERE MODEL = 'Caddy Maxi' AND DATE_RANGE_ID = 6
```

 

If this doesn't return any rows, copy them from Caddy, only committing the work once you are happy with the data:

 

```
BEGIN TRANINSERT INTO dbo.RATE_VWCV_RATES_V2(SUBSCRIPTION_TYPE_ID, COVER_TYPE_ID, VOL_EXCESS_ID, MILEAGE_LIMIT_ID, MIN_CURRENT_MILEAGE, MAX_CURRENT_MILEAGE, MODEL, DATE_RANGE_ID, PREMIUM, TPA_FEE_OPTEVEN, TPA_FEE_CONNEXUS, VWFS_UK_COMM, VW_VERS_ADMIN, FULFILLMENT_FEE, LIBTECH_ID, LIBTECH_VERSION)SELECT SUBSCRIPTION_TYPE_ID, COVER_TYPE_ID, VOL_EXCESS_ID, MILEAGE_LIMIT_ID, MIN_CURRENT_MILEAGE, MAX_CURRENT_MILEAGE, 'Caddy Maxi', DATE_RANGE_ID, PREMIUM, TPA_FEE_OPTEVEN, TPA_FEE_CONNEXUS, VWFS_UK_COMM, VW_VERS_ADMIN, FULFILLMENT_FEE, LIBTECH_ID, LIBTECH_VERSIONFROM dbo.RATE_VWCV_RATES_V2 WHERE MODEL = 'Caddy' AND DATE_RANGE_ID = 6COMMIT TRAN
```

 

Note that UAT uses dbo.RATE_VWCV_RATES_V2 to quote, so the same needs performing for this table