[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Porsche Standard Merge

 

---

 

Below are the steps needed to merge the Porsche Standard changes into Trunk branch

 

 

 

#### Moving Umbraco Databases

 

Dev and UAT databases for the Porsche **AnnualJourney-Multi-Vehicle** branch are located on the 192.168.200.113 server:

 

- InsureWithPorscheUmbraco_Annual_Dev
- InsureWithPorscheUmbraco_Annual_UAT

 

Above Dev database should be merged with UAT prior to moving to **Trunk**. (Unless there are any changes still in development that do not need merging)

 

**InsureWithPorscheUmbraco_Annual_UAT** is to be moved to **InsureWithPorsche_UAT** which is the current database for the main UAT website.

 

 

 

#### Moving ConnexusConfig Databases

 

It is only the Porsche Standard branch (**AnnualJourney-Multi-Vehicle**) that uses the **ConnxusConfig**database, other websites in both Dev and UAT seem to be using **ConnexusConfig_UAT.**For this reason, I have decided to use the former as updating the configs would not affect the main UAT and Dev setups.

 

There is no need to copy the entire database as only certain values have changed in the **Configurations** table.

 

Porsche has an **ApplicationId** of **6** and the values that need to be copied to **ConnexusConfig_UAT** are:

 

- NcdConfig (which has the JSON object needed to populate the NCB/NCD view model)
- PorscheSchemes (which stores scheme values for each journey)

 

**DriveAwayEndoresementExclusions** key can be removed from the table as the website is no longer using it.

 

 

 

#### Merging Branches

 

**AnnualJourney-Multi-Vehicle**should have all the latest changes from **Trunk**, therefore this step would only require the former merging into the latter.

 

*web.config files should not require any changes apart from making sure the connection strings are pointing to the correct databases.*