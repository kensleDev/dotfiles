[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Useful Transactor Information

 

---

 

Transactor software is the policy administration system and quotation system for insurance products that Connexus uses. It is provided by Transactor, who are now owned by Open GI.

 

Our DSP, VW, Velosure and Porsche web sites are heavily integrated in to this system to provide quotations and store client policy information.

 

You can find a list of the Transactor servers and Databases on the [Server](/servers/) page

 

If in doubt, you can find on each **v6** application server the location of the database in the Windows Registry (note that there are a LOT of entries, and it's a mess - many keys are duplicated in different areas, and some servers also have 32 bit and 64 bit entries):

 

![](../images-webp/image_26.webp)

 

For v7, all registry settings were moved in to a configuration database, tidying up all the mess from the registry and removing unneeded duplicates:

 

![](../images-webp/image_27.webp)

 

**Transactor Files and services on each app server**

 

There are Transactor Web services on each app server

 

![](../images-webp/image_28.webp)

 

![](../images-webp/image_29.webp)

 

And there are Transactor Services on each app server too:

 

![](../images-webp/image_30.webp)

 

![](../images-webp/image_31.webp)

 

![](../images-webp/image_32.webp)

 

![](../images-webp/image_33.webp)

 

 

 

The main folder for Transactor **v6** and **v7** files is *C:\Program Files (X86)\Transactor*

 

![](../images-webp/image_34.webp)

 

The *C:\Program Files (X86)\Transactor\TES_MSMQ* folder is useful for seeing a log of emails sent from an application server:
![](../images-webp/image_35.webp)

 

There is also a *D* drive on each app server that contains a load of files and folders in the following location:

 

For Transactor **v6**: *D:\TCAS*

 

For Transactor **v7**: *C:\Transactor\Broker\WA02* and **D***:\Transactor\Broker\WA02*

 

The files and folder structure in both these folders are very similar

 

![](../images-webp/image_36.webp)

 

![](../images-webp/image_37.webp)

 

![](../images-webp/image_38.webp)

 

Folders we commonly would access are **Documents**and **Schemes**

 

*Documents*- contains all document templates

 

**Documents\Source Documents** - this contains an archive of every document/email ever printed/emailed from Transactor and takes up a lot of disk space. These were historically on C Drive but recently moved to D drive across all servers to prevent running out of space regularly.

 

**Documents\Templates** - this contains all the document files that are promoted through the Transactor Document Manager ("Doc Manager")

 

**Schemes**- contains all Product Modeller scheme files for DSP and Velosure - the files are plain text and can be loaded and viewed:

 

![](../images-webp/image_39.webp)

 

**Useful scripts**

 

See [this article](/articles/transactor/useful-transactor-scripts/).

 

**Printing / Event Queue**

 

See [this article](/articles/transactor-documents-and-emails/transactor-email-queues/) (and Transactor Documentation below)

 

**Useful tables in the DB**

 

There is a full database schema document here for **v7**, but most of it is relevant to **v6** too: "\\192.168.30.18\CompanyData\Transactor User Guides\Database Schema - User Guide v7_Updated.doc"

 

Commonly accessed tables: 

 

**Customer data**

 

CUSTOMER_ * - all customer data

 

CUSTOMER_POLICY_DETAILS

 

CUSTOMER_INSURED_PARTY

 

CUSTOMER_CLIENT_ADDRESS

 

CUSTOMER_VEHICLE

 

**List of vehicles available in Transactor**

 

SYSTEM_LIST_VEHICLES - Cars (E.g. Porsche)

 

SYSTEM_LIST_CV - Commercial Vehicles

 

SYSTEM_LIST_MC - Motorcycles

 

**Other lists**

 

Most lists in Transactor begin with LIST_ in the database, e.g. LIST_SOURCE_BUSINESS

 

**Rates**

 

RATE_ * - all tables with rates for Product Modeller schemes

 

TGSLUser.RATE_ * - all tables with rates for Product Modeller schemes

 

**Relationship Manager configuration**

 

RM_ * - All Relationship Manager data

 

**Scheme information**

 

SYSTEM_SCHEME_NAME

 

SYSTEM_SCHEME_DEFINITIONS

 

RM_SCHEME

 

**Document Manager Configuration**

 

SYSTEM_DM_ *

 

**User Lines of Business Data**

 

USER_VW001_VW001

 

USER_VW001_VW002

 

USER_VW001_VW003

 

USER_VW001_VW004

 

**Logging in to Transactor**

 

When loading TCAS, login as sysadmin, password2 across all TCAS environments

 

**Transactor applications**

 

TCAS - main admin / quotation system

 

TES Tool Suite - a lot of configuration in here, including the Document manager and Events & Triggers

 

TES Accounts Suite - Accounts, rarely used by Digital Development

 

Relationship Manager - Configuration of Agents, Sub Agents, Schemes, Commissions etc.

 

**Transactor documentation and guides**

 

Numerous documentation and guides are available from Transactor, and they are located here:

 

\\192.168.30.18\CompanyData\Transactor User Guides