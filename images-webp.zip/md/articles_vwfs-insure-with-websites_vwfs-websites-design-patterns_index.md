[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# VWFS Websites - Design Patterns

 

---

 

## Introduction

 

The VWFS "Insure with" websites adopt many design patterns in their implementations; some more common than others. These patterns and the reasons for their use are documented below.

 

## Common Design Patterns

 

There are several common design patterns in use in the VWFS "Insure with" websites, including:

 

- Singleton
- Factory
- Adapter
- Facade

 

There are excellent definitions and descriptions of these patterns on the DoFactory website: [https://www.dofactory.com/net/design-patterns](https://www.dofactory.com/net/design-patterns)

 

## Less Common and Custom Design Patterns

 

Some of the design patterns used in the VWFS "Insure with" websites are less common and/or customised to suit the context of the solution.

 

### Chain of Responsibility

 

The Chain of Responsibility pattern aims to avoid coupling the sender of a request to its receiver by giving more than one class a chance to handle the request. The pattern chains multiple receiving objects and passes the request along the chain until an object handles it and provides the required response.

 

The classes and objects participating in this pattern are:

 

- **Handler** (Approver) 

- defines an interface for handling a request
- (optional) implements the *Successor* link
- **ConcreteHandler** (Director, VicePresident, President) 

- handles requests it is responsible for
- can access its *Successor*
- if the ConcreteHandler can handle the request, it does so; otherwise, it forwards the request to its *Successor*
- **Client** (ChainApp) 

- initiates the request to a ConcreteHandler object on the chain

 

#### Connexus Implementation - Vehicle Lookup

 

The pattern has been modified in its only use at Connexus to expand on the idea of multiple objects having the chance to handle the request. The Connexus implementation uses the pattern to *build up* a response from several chained handlers all of whom can provide some, but not all, of the necessary response data.

 

The VWFS Extended Warranty journey is required to look up a vehicle and existing policy details from several different data sources; all of which can provide some of the data required to initialise a complete response:

 

- **Carweb** - to retrieve details about a vehicle, such as Date of Registration, Fuel Type and Engine Size
- **VMS Database** - to retrieve potential Manufacturer and Approved Used policy details
- **Transactor Database** - to retrieve potential Extended Warranty policy details

 

A successful response from the call to look up vehicle and policy details can potentially include data from all three of these sources. Therefore, the Chain of Responsibility pattern has been implemented to pass the single request to all three data sources sequentially in order to construct a complete set of response data.

 

The specific classes participating in the Connexus implementation are documented below.

 

##### Handler

 

**HandlerBase.cs** in *RefreshMvc.Services.Shared*/Classes/LookupChain/ is an abstract class responsible for providing the base implementation for handling a request in a Chain of Responsibility.

 

1. It first executes an abstract method **concreteHandlerForRequest()** which must be implemented by any inheriting concrete classes to provide their specific 'handling' implementation.
2. Then there is a check to determine whether the *result* is "complete"; that is to say does it contain the minimum data required to be considered a valid response. If so, the result is returned.
3. If there is some data in the result, but it is not considered complete, we add the current data to the request. This is so that subsequent concrete handlers have access to data already retrieved by predecessors.
4. If there is a successor concrete handler, we then recursively ask that handler to handle the request, and the chain continues.
5. Once we reach the end of the chain and there are no more successors, the result is returned.

 

```
public abstract class HandlerBase<Tin, Tout> : IHandleLookupRequest<Tin, Tout> 
    where Tout: class, ICompleteCheck, new()
{

    ...

    public Tout HandleRequest(RequestWrapper<Tin, Tout> request)
    {
        var result = this.concreteHandlerForRequest(request);

        if (result.IsComplete())
            return result;

        if (result != null)
        {
            request.CurrentData = result;
        }

        if (this.successor != null)
            return this.successor.HandleRequest(request);

        return result;
    }
    
    ...

    protected abstract Tout concreteHandlerForRequest(RequestWrapper<Tin, Tout> request);
}
```

 

##### ConcreteHandlers

 

The three concrete handlers in our Chain of Responsibility all reside in *RefreshMvc.Services.EwRenewals*/Classes/LookupHandler/ and provide the concrete implementations that perform their specific lookup functionality for the chain. They all implement the **concreteHandlerForRequest()** abstract method defined in **HandlerBase****.cs** above.

 

- **CarWebHandler.cs** 

- handles the lookup of vehicle details with Carweb
- **VmsHandler.cs** 

- handles the lookup of Manufacturer and Approved Used policy details from the VMS database
- **TransactorHandler.cs** 

- handles the lookup of Extended Warranty policy details from the Transactor database

 

##### Client

 

The **IVehicleLookupChainForExtendedWarranty.cs** interface and its concrete implementation, **VehicleLookupExtendedWarrantyChain.cs** provide the entry point for any calling code to execute the Chain of Responsibility. The concrete class uses a *builder* class to construct the chain of handlers: **ChainOfResponsibilityBuilder.cs**. This ensures the order of the chain is maintained based on the order the dependencies are supplied to the constructor.