[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Setup Google Optimize

 

---

 

## Introduction

 

Google Optimze is an application available on the Google platform that allows variants of web pages to be tested to see how they perform against specified objectives. Optimize monitors the results of the experiment and reports which it believes to be the preferred variant.

 

Using Google Analytics segments (see separate section) most of the built-in and custom GA reports can be configured to compare between multiple variants.

 

You can log in to our [Google Optimize](https://optimize.google.com/) setup with: websitesupport@connexus.co.uk.

 

## Google Optimize Accounts

 

When setting up Google Optimize for the first time for a new customer, website or application, it may be necessary to create a new Account. Accounts are placeholders for all data associated with a high-level entity such as an entire customer; for example, we have an account for all websites and applications we manage for VWFS.

 

### Existing Account

 

It is likely that a valid account already exists for the website or application you are implementing in GTM; it is important to check before creating a new account.

 

### New Account

 

You can follow the below steps to create a new account:

 

1. 1. In the *All Accounts* page, click **Create account** (you can always click the Optimize icon at the top-left to navigate to the *All Accounts* page)
2. Type the new **Account Name** e.g. "VWFS"
3. Select "United Kingdom" from the **Country** dropdown
4. Accept the terms of service, Data Processing Terms and Data Protection Terms
5. Continue with configuring a **Container** by following the instructions below

 

## Optimize Containers

 

**Containers** are placeholders that uniquely identify an individual website or application. They are configured with a unique *code* that is used to ensure data for that website or application is always associated with the correct **Container** in Google Optimize.

 

### Creating a new Container

 

If you have identified an existing **Account** to use for integrating your website or application, you can create a new **Container** as follows:

 

1. Find the required account and click the + (Create new container) button to the right of the panel
2. Type the **Container Name** e.g. "Insure with Skoda - UAT"
3. Click **Create**
4. Click **Let's Go** to create your first experience

 

## Optimize Experiences

 

**Experiences** are either tests or personalisations. A test may be an A/B, multivariate or redirect test, while a personalisation is customisation to the website made for a specific group of visitors. The various types of test will be described later.

 

### Creating a new Experience

 

1. Enter a **Name**
2. Enter the URL of the website the experience is to run against, including the https:// prefix
3. Select **A/B test**, **Multivariate test**, or **Redirect test**
4. Click **Create**
5. Click **Add Variant**
6. If asked to install the **Optimize Chrome Extension**, do so

 

#### A/B Test

 

An A/B Test allows for things that can be done purely in Optimize such as textual and CSS changes. It does allow JavaScript to be run but this has proven not to be suitable for SPA applications; Optimize can either run too early in the lifecycle when the SPA has not been setup, or too late in which case the replaced markup will not have the SPA functionality.

 

1. Enter a **Variant name** for the B version
2. Click **Done**
3. Click **Edit** against the variant
4. Make the changes as required: 

- If the element to be changed is visible 

- Click on the element
- Click **Edit element**
- Select **Edit HTML**
- Make the required changes, e.g. change the text of a button
- Select Replace, Insert, Append, Before or After from the dropdown as required
- Click **Apply**
- If the element to be changed is not visible 

- Click the **Interactive mode** icon in the top right corner
- Navigate through the page until the item to change is visible, note that if this is hidden when exiting from interactive mode then if it is right-clicked then it remains selected
- Click **Exit**
- Proceed as if the element was visible above
- If changes are required on a different page to the home page 

- Click **Add page**
- Enter a **Page name**
- Enter the URL of the page to edit
- Proceed with editing the new page in the same way as before
- To make changes to multiple pages 

- Click the pencil next to "*URL matches*" in the Page targeting frame
- Select "**matches regex**" from the dropdown next to URL
- Delete the URL if not required
- Enter the regex in the textbox
- The rule can be checked by entering URLs in the textbox in the *Check your rule* panel and clicking **Check**; this will show an icon as to whether the URL has passed or failed. Multiple URLs can be checked
- Click **Save**
- Note that if changes are made to multiple pages then the regex must exclude any pages handled by another page
- Variants can be previewed by clicking the **Preview** button against the variant

 

#### Multivariate Test

 

A Multivariate Test allows for more than one variant. **Note that we have not done this yet and the documentation needs to be updated once we have experience of doing this**.

 

#### Redirect Test

 

A redirect test is used when the changes are too significant to be done within Optimize and require an alternative version of the website to be created. The visitor will either remain on the standard site or be redirected to the alternative version.

 

1. Enter a **Variant name** for the alternative version
2. Select **Redirect to a single page** from the Redirect type radio buttons
3. Enter the URL of the alternative version
4. This then adds a hyperlink to the alternative version in the Preview panel
5. Click **Done**

 

### Linking to Analytics

 

Optimize must be linked to the Google Analytics code of the relevant site

 

1. Click Link to Analytics
2. Select the Google Analytics property, using the Search if it is not visible
3. Select All Web Site Data or UAT as required from the dropdowns
4. Click **Link**

 

### Adding Objectives

 

**Objectives** are the criteria by which the success of an experiment is measured. Up to 3 objectives can be added

 

1. Click **Add experiment objective**
2. To set an event as an objective: 

1. Select "**Create custom**" from the dropdown
2. Enter a **name**, eg Event - EW Get Cover Now
3. Select **Events**
4. Set the rules to exactly match the tag created in the *Add some Events* document, eg: 

- Event Category, Equals, Button
- Event Action, Equals, Click
- Event Label, Equals, EW Get a quote banner C2A
5. Enter a description, eg Event - EW Get Cover Now
6. Select One per session or Many per session from the Counting method dropdown as appropriate
3. To set a goal as an objective:
 

1. Select "**Choose from list**" from the dropdown
2. Select the required goal from the list

 

## Adding Google Optimize to a website or application

 

The Javascript code necessary to integrate your website or application with Google Optimize can be accessed at any time from the Experiment by by clicking on the **"View** instruction" button and copying the Optimize snippet. For Google Optimize there is one code block required for the <head /> tag.

 

This segment must sit as in the <head> following the GTM and GA segments. At Connexus this code block is usually separated into partial views in MVC solutions or separate components in SPA-driven websites. It may also be conditionally rendered by the website for privacy reasons such as GDPR cookie acceptance.

 

**Note:** if the code already exists in the source, only the unique "OPT-" code needs to be updated in the relevant place.

 

## Environment Switching

 

Each expperiment has its own unique Optimize code, so to avoid having to change partial views when creating a new experiment we are steadily implementing storage of the unique *code* in AppSettings -> GoogleOptimizeKey in the web.config file; this has already been completed for Insure with Audi.

 

## Example: adding Google Analytics to a VWFS InsureWith website

 

The VWFS "Insure with" websites hold the Google Optimize Javascript code blocks in a separate partial view:

 

- **/Views/Shared/_googleTagManager.cshtml**

 

### Checking the experiment

 

1. Click Check installation. Note that if GTM and GA are conditionally added after accepting cookies then the site needs to be run first and cookies accepted
2. Assuming that Optimize is correctly installed dialog appears, click Back to Experience

 

### Scheduling the experiment

 

By default, experiments start immediately and run for 90 days, however this can be changed. Note that the Google Optimize documentation states that all experiments are ended after 90 days

 

1. Click the clock icon in the heading at the top of the screen
2. Enter a **Start date**, or select from the date picker
3. Select a time from the **Start time** dropdown
4. Enter an **End date**, or select from the date picker
5. Select a time from the **End time** dropdown
6. Click **Done**
7. Click "**Got it**"

 

### Starting the experiment

 

1. Click **Start**
2. Uncheck "**Receive email notifications**"
3. Click **Start**
4. NB Optimize takes a while before the experiment can actually be used (10-15 mins perhaps)

 

## Google documentation

 

For further information about Google Optimize, visit the [Optimize Resource Hub](https://support.google.com/optimize/?hl=en).