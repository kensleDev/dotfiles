[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# ARCHIVED

 

---

   

#### Hi-Vis

 

---

 

- ** [Hi-Vis - Architecture](/archived/hi-vis/hi-vis-architecture/)
- ** [Cazana Component - Architecture](/archived/hi-vis/cazana-component-architecture/)

   

#### Google Play Store

 

---

 

- ** [Enable /Disable Apps](/archived/google-play-store/enable-disable-apps/)

   

#### Azure DevOps Management

 

---

 

- ** [DevOps - Users and Permissions](/archived/azure-devops-management/devops-users-and-permissions/)
- ** [DevOps - Agile Process Management](/archived/azure-devops-management/devops-agile-process-management/)
- ** [Planning Poker for User Stories](/archived/azure-devops-management/planning-poker-for-user-stories/)

   

#### Indivual Articles Archived

 

---

 

- ** [Heartcore - working with Deploy](/archived/indivual-articles-archived/heartcore-working-with-deploy/)
- ** [Restict Back Office /UMBRACO Access](/archived/indivual-articles-archived/restict-back-office-umbraco-access/)
- ** [Required elements/steps](/archived/indivual-articles-archived/required-elements-steps/)
- ** [Visual Studio Publish of Insure with websites](/archived/indivual-articles-archived/visual-studio-publish-of-insure-with-websites/)
- ** [Manually Deploying InsureWith Sites to Production](/archived/indivual-articles-archived/manually-deploying-insurewith-sites-to-production/)
- ** [Deploying InsureWith Sites to Production using the PowerShell Script](/archived/indivual-articles-archived/deploying-insurewith-sites-to-production-using-the-powershell-script/)
- ** [Understanding the deployment script](/archived/indivual-articles-archived/understanding-the-deployment-script/)
- ** [Why Production InsureWith Sites have an Admin Instance](/archived/indivual-articles-archived/why-production-insurewith-sites-have-an-admin-instance/)
- ** [Configuring the InsureWith Sites to Load Google Keys From the web.config](/archived/indivual-articles-archived/configuring-the-insurewith-sites-to-load-google-keys-from-the-web-config/)
- ** [Deployment Issues - Insurewith sites](/archived/indivual-articles-archived/deployment-issues-insurewith-sites/)
- ** [Clear previous version when debugging](/archived/indivual-articles-archived/clear-previous-version-when-debugging/)
- ** [First time run of Vue/.net app](/archived/indivual-articles-archived/first-time-run-of-vue-net-app/)
- ** [Velosure Deployments](/archived/indivual-articles-archived/velosure-deployments/)