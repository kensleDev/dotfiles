[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Configuring the InsureWith Sites to Load Google Keys From the web.config

 

---

 

## Introduction

 

Historically the Google Tag Manager and Analytics keys have been held in two partial views in the *Views/Shared* folder, **_googleTagManager.cshtml** and **_googleTagManagerNoScript.cshtml**.

 

Now that Google Optimize has been introduced and will be used in UAT, this data should come from web.config and be dynamically loaded into the views.

 

## InsureWithAudi

 

This was setup on InsureWithAudi, but not put live due to a mistaken belief that the Google Optimize key would need to be updated for each experiment, requiring an out-of-hours deployment and negating the benefit of Google Optimize being able to schedule the start of an experience.

 

The following config has been included in web.config in the Trunk and ABTesting-195 branch; this has been setup on UAT **but will need adding to live on the next deployment**:

 

```
<!-- GOOGLE TAG MANAGER, ANALYTICS & OPTIMIZE KEYS -->
  <!-- UAT -->
  <add key="GoogleTagManagerKey" value="GTM-N7WDVL2" />
  <add key="GoogleAnalyticsKey" value="UA-165030466-2" />
  <add key="GoogleOptimizeKey" value="OPT-NMPL27J" />
  <!-- LIVE 
  <add key="GoogleTagManagerKey" value="GTM-TXC6XK" />
  <add key="GoogleAnalyticsKey" value="UA-23869986-1" />
  <add key="GoogleOptimizeKey" value="OPT-NMPL27J" />
  -->
```

 

The _googleTagManager.cshtml and _googleTagManagerNoScript.cshtml scripts have also both been updated in source and on UAT for both branches:

 

_googleTagManager.cshtml

 

```
@* for inclusion in the header of each page where google analytics is required to track a journey *@
@using System.Configuration
<!-- Google Tag Manager -->
<script>
    (function (w, d, s, l, i) {
        w[l] = w[l] || []; w[l].push({
            'gtm.start':
                new Date().getTime(), event: 'gtm.js'
        }); var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', '@ConfigurationManager.AppSettings["GoogleTagManagerKey"]');
</script>
<!-- End Google Tag Manager -->
<!-- Google Analytics -->
<script>
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date(); a = s.createElement(o),
            m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');
 
    ga('create', '@ConfigurationManager.AppSettings["GoogleAnalyticsKey"]', 'auto');
    ga('send', 'pageview');
 
</script>
<!-- End Google Analytics -->
<!-- Google Optimize -->
<script src='https://www.googleoptimize.com/optimize.js?id=@ConfigurationManager.AppSettings["GoogleOptimizeKey"]'></script>
<!-- End Google Optimize -->
```

 

_googleTagManagerNoScript.cshtml

 

```
<!-- Google Tag Manager (noscript) -->
@using System.Configuration
<noscript>
    <iframe src="https://www.googletagmanager.com/ns.html?id=@ConfigurationManager.AppSettings["GoogleTagManagerKey"]"
            height="0" width="0" style="display:none;visibility:hidden"></iframe>
</noscript>
<!-- End Google Tag Manager (noscript) -->
```

 

## Other InsureWith Sites

 

UAT instances of Google Tag Manager, Analytics and Optimize have been setup for all InsureWith sites, and live instances of Optimize. The websites have been updated to pick the keys up from config in all branches, but have not been deployed to UAT.

 

The Optimize containers have not been linked to GA; this should be done when the first experience is created for each brand.