[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Renewing SSL Certs (Apache)

 

---

 

#### Overview

 

IT (usually Mark Baines) handles purchasing of SSL certificates and will contact you when the time comes to update them usually over a month in advance.

 

#### Log into to the server via SSH

 

Using your SSH client of choice, log in to the server which hosts the website (and certificate) that you want to update (see Website List for location of each website).

 

#### Locate the current certificate

 

Navigate to the list of configuration files for the website and list the contents of the directory to make sure you select the correct configuration file:

 

```
cd /etc/apache2/sites-available
```

 

If there are multiple configuration files for a single site, you can navigate to /etc/apache2/sites-enabled and list the contents of that directory which will show you which configuration files are currently active.

 

Edit the configuration file:

 

 

 

```
sudo nano name_of_my_conf_file
```

 

Look for the SSL configuration lines, for example:

 

```
SSLEngine OnSSLCertificateFile /etc/ssl/certs/2022/chr.crtSSLCACertificateFile /etc/ssl/certs/2022/chr-wildcard.caSSLCertificateKeyFile /etc/ssl/certs/2022/chr.key
```

 

You only need to update the **SSLCertificateFile**and **SSLCertificateKeyFile** lines, so in the interest of keeping everything as organised as possible, make a note of where those files are currently stored (/etc/ssl/certs).

 

Exit Nano and navigate to where they are saved (e.g. cd /etc/ssl/certs).

 

### Create the new certificate files

 

Create a new folder here for the year of the certificate you’re applying, if there's none for your year:

 

```
cd /etc/ssl/certs
```

 

```
sudo mkdir 2023
```

 

```
cd 2023
```

 

Open the text file provided by IT and **copy**the **Certificate section**(starts with -----BEGIN CERTIFICATE-----)

 

Now create a new certificate file in your new folder on the server:

 

```
sudo nano cycleaccident.crt
```

 

Paste in what you copied from the TXT file (*Just the section between BEGIN CERTIFICATE AND END CERTIFICATE*) and press **CTRL+X**and answer **Y/Yes** to the save prompt.

 

Go back to the text file provided by IT and copy the Key section(starts with -----BEGIN PRIVATE KEY-----):

 

Create a new key file on the server:

 

```
sudo nano cycleaccident.key
```

 

Paste in the content of the private key and **CTRL+X** and save. We are now ready to update the configuration file to point to the updated certificate and key files.

 

### Update the configuration file

 

Navigate to the configuration file again:

 

```
cd /etc/apache2/sites-available
```

 

```
sudo nano cycleaccident.conf
```

 

(or as a one liner)

 

```
sudo nano /etc/apache2/sites-available/cycleaccident.conf
```

 

And update the **SSLCertificateFile**and **SSLCertificateKeyFile**lines to point to the newly created files e.g 

 

```
SSLEngine OnSSLCertificateFile /etc/ssl/certs/2023/chr.crtSSLCACertificateFile /etc/ssl/certs/2022/chr-wildcard.caSSLCertificateKeyFile /etc/ssl/certs/2023/chr.key
```

 

### Check for errors

 

Once done, save the file (**CTRL+X, Y/Yes**) and run Apache’s config test to ensure no mistakes or typos have been made.

 

```
sudo apachectl configtest
```

 

If all is well, you should receive “**Syntax OK**”. Do not worry if it also mentioned not being able to determine the server’s fully qualified domain name.

 

If you did not receive *Syntax OK*, **DO NOT** reload Apache as it will not be able to start up again, causing the sites to go down. Read the error message and fix the issue that’s being described.

 

### Reload Apache

 

Once you’re happy, the Apache service can safely be reloaded:

 

```
sudo service apache2 reload
```

 

If no message is returned, everything is fine! Load the website in question and check the certificate in your browser to make sure it’s updated.

 

#### REMEMBER:

 

**FOR CMS’s LIKE LAWSHIELD, YOU NEED TO GO INTO PRD-LINUX-VM01, GO INTO THE .CONF FILE FOR THE WEBSITE AND REAPPLY THE SSL CERT TO THAT SERVER TO APPLY THE CERT TO THE CMS.**

 

FOR CMS’s LIKE **CHR**, YOU NEED TO GO INTO PRD-LINUX-VM01, GO AND REAPPLY THE SSL CERT TO THAT SERVER FOR THE CMS PART as well as PRD-UBUNTU-20.04

 

**KLS, SPECTERS and OYB**need to be applied to PRD-LINUX-VM02

 

WHEN RENEWING **CONNEXUS’s** CMS – ADD TO SPECTERS CMS IN PRD-LINUX-VM02