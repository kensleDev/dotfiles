[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Loan Car Insurance

 

---

   

## Website Details

  **Live URL:** [https://www.loancarinsurance.com/](https://www.loancarinsurance.com/) **UAT URL:** [https://loancarinsurance.connexus-test.co.uk/](https://loancarinsurance.connexus-test.co.uk/)    .NET Framework C# ASP.NET MVC HTML CSS Bootstrap JavaScript jQuery   

---

 

Loan Car Insurance is a semi-public-facing website offering information to participants of the Loan Car scheme of the Volkswagen Group, which provides Motor Insurance to employees of the Volkswagen Group.

 

## Content Management

 

The Loan Car Insurance website is integrated with the **Umbraco Content Management System (CMS)**. This provides a platform for the management and maintenance of the majority of the text, graphics and documentation available to users of the website.

 

[https://admin.loancarinsurance.com/umbraco#/umbraco](https://admin.loancarinsurance.com/umbraco#/umbraco)

 

usual password...