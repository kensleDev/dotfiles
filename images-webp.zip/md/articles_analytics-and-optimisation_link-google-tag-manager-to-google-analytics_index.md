[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Link Google Tag Manager to Google Analytics

 

---

  

## Introduction

  GA reports on events triggered by GTM, but in order to do so, GTM needs to be aware of the GA property that is listening for these events, so the GA Tracking ID needs to be linked to GTM.  

## Obtaining the GA Tracking ID

 In Google Analytics:  

1. Click the **Admin gear icon** in the bottom left
2. Select the correct **Account** and **Property** from the relevant dropdowns
3. Click **Property Settings**
4. The **Tracking ID** is under Basic Settings; it begins UA-

   

## Storing the GA Tracking ID in a variable

 

The GA Tracking ID could just be entered as text wherever it is required but it makes sense to create a user-defined variable so it only needs to be entered once.

 

In Google Tag Manager:

 

1. Find the required account and click the required **Container Name**
2. Select **Variables** from the menu bar on the left hand side of the screen
3. Click **New** in the User-Defined Variables panel
4. Change the name from "Untitled Variable" to "GA Tracking ID"
5. Click the pencil in Variable Configuration
6. Select **Utilities** -> **Google Analytics Settings** in the Choose variable type dialog
7. Enter the **GA tracking ID** as the Tracking ID
8. Leave the Cookie Domain as auto
9. **Save**

 

 

 

1. Select **Tags** from the menu bar on the left hand side of the screen
2. Click **New** in the Tags panel
3. Change the name from "Untitled Tag" to "Universal Analytics"
4. Click the pencil in the Tag Configuration panel
5. Select **Featured** -> **Google Analytics: Universal Analytics** in the Choose tag type dialog
6. Select "Page View" from the Track Type dropdown
7. Select "{{GA Tracking ID}}" from the Google Analytics Settings dropdown
8. Click the pencil in the Triggering panel
9. Select **All Pages**
10. **Save**

 

## Publishing the changes

 Unlike Google Analytics, Google Tag Manager does not update in real time and needs to be published 

1. Click the **Submit** button in the top right hand corner
2. Enter a **Version Name** and **Version Description**
3. Click **Publish**