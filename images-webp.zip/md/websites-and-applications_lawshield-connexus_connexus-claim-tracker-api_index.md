[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Connexus Claim Tracker API

 

---

   

## Website Details

  **Live URL:** [https://claimtracker-api.connexus.co.uk/](https://claimtracker-api.connexus.co.uk/) **UAT URL:** [https://claimtracker-uat-api.connexus-test.co.uk/](https://claimtracker-uat-api.connexus-test.co.uk/)    .NET Core C# ASP.NET MVC Core   

---

 

This is the REST API for the Connexus Claim Tracker