[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Brokerbility Breakdown Insurance

 

---

 

Comprehensive Motor Breakdown Cover at competitive rates, 24/7/365 assistance to enhance and add value to the main insurance policy.

 

Cover options for cars, motorcycles, commercial vehicles, fleets, taxis and couriers and cover available for UK only or UK & EU.

 

Please note that the policies are vehicle specific and the policy duration is for 12 months.
Features and Benefits:
UK Breakdown

 

- 12-month policy
- 24/7/365 days emergency helpline
- Doorstep and roadside assistance
- A nationwide network of recovery agents available to assist in emergency situations
- Onward transportation
- Recovery of caravans or trailers
- Cover for call out charges for lost or broken keys
- Message relay i.e. passes on up to 2 messages to either home or place of work to advise of the situation.
- Emergency driver if you become ill and are unable to finish the journey

 

UK & EU Breakdown (in addition to UK cover)

 

- Replacement parts dispatch
- Recovery of the vehicle, driver and passengers to a local garage
- If your vehicle can not be repaired at the roadside or it is stolen and not recovered within 8 hours, you are covered for one of the three options:-
 

- Onward destination and delivery of the vehicle to you once repaired
- Hire car
- Bed & Breakfast costs
- Transport costs to your home for you and passengers
- Storage costs whilst your vehicle is waiting to be repaired, collected or taken to the UK.

 

## Product Details

  **Product Reference:** BROKBILL **Product Type Id:** 435  

---

 

## Schemes

 

- [Brokerbility Axa Breakdown Scheme](/insurance-products/lawshield-dsp-b2b/brokerbility-breakdown-insurance/brokerbility-axa-breakdown-scheme/)

 

---