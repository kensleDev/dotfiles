[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - VWFS Ensurance

 

---

 

Ensurance is a free product for all VWFS brand customers. It gives the policyholder the ability to have their vehicle repaired at an approved garage free of charge regardless of fault.

 

## Product Details

  **Product Reference:** VW **Product Type Id:** 427  

---

 

## Schemes

 

- [VW Ensurance](/insurance-products/volkswagen-financial-services-vwfs/vwfs-ensurance/vw-ensurance/)

 

---