[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Updating Paint and Bodyshop content

 

---

 

A common task is adding and removing 'Paint and Body Shops' from the insureWith VW sites. 

 

This just requires adding data to one table as below 

 

UAT --> 192.168.200.113 VISinsureWith_UAT table 

 

Live -->  192.168.100.118 VISinsureWith table 

 

Notes: 

 

- Check if the data to add/delete is present
- Use Google maps to grab the Long/Lat values 

- Postcode for the centre can (at present be found using the centre number here:
- https://volkswagenapprovedrepair.co.uk/approved-crash-repair-centre-contact-info/**50550**
- This can be further automated using chromes custom search engines [like so](/articles/other-useful-info/browser-custom-search-engines/).
- Use ROLLBACK when testing, change to COMMIT when satisfied all is well

 

 

 

```
SELECT * FROM Locator.PaintAndBodyShop WHERE CentreNumber IN (50523);
```

 

**Insert new data...**

  

*BEGIN TRANSACTION*

 

*INSERT INTO Locator.PaintAndBodyShop (*

 

*CentreName,*

 

*AddressLine1,*

 

*AddressLine2,*

 

*AddressLine3,*

 

*Town,*

 

*County,*

 

*PostCode,*

 

*Telephone,*

 

*ContactName,*

 

*Email,*

 

*Latitude,*

 

*Longitude,*

 

*LastUpdated,*

 

*CentreNumber,*

 

*Deleted*

 

*)*

 

*VALUES (*

 

*'James Alpe ARC',*

 

*'Unit 1-2',*

 

*'Lincoln Way',*

 

*'Salthill Ind Est',*

 

*'Clitheroe',*

 

*'Lancashire',*

 

*'BB7 1QD',*

 

*'+441200444455',*

 

*'Claire Jenkin',*

 

*'lee@jamesalpe.co.uk',*

 

*53.87615893120985, -2.3780431425243456,*

 

*GETDATE(),*

 

*50523,*

 

*'False'*

 

*);*

 

*ROLLBACK TRANSACTION*

 

*--COMMIT TRANSACTION*

 

**

  

**Deleting**

  

*BEGIN TRANSACTION*

 

*UPDATE Locator.PaintAndBodyShop*

 

*SET Deleted = 1*

 

*WHERE CentreNumber IN (*

 

*50287,*

 

*50309*

 

*);*

 

*ROLLBACK TRANSACTION*

 

*--COMMIT TRANSACTION*