[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Transactor Development Environment Setup

 

---

 

## MS Word Add-in Setup

 

Within MS Word there is an add-in that allows the selection of "mail merge" fields into a document, for use in document packs, policy schedules, etc. This must be done for each user on each Transactor Application Server who wishes to use the add-in:

 

- Log in to the relevant server on which you wish to use the Document Manager MS Word add-in.
- Create a file called *addin.reg* with this text in it:

 

```
REGEDIT4
[HKEY_CURRENT_USER\Software\Microsoft\Office\Word\Addins\TCAS_Document_Manager.Addin]
"Description"="WIS XML Document Manager"
"FriendlyName"="Document Manager"
"LoadBehavior"=dword:00000003
```

 

- Double click the file to run it and make the necessary change to the registry.
- Now when you open Word, the top menu should include the link: Add-Ins and contain a link within it to TGSL > Document Manager.

 

## Code Projects - Local Machine Configuration

 

When running a project that interacts with Transactor on your local machine Transactor requires certain registry keys to exist. To make all developer environments consistent, you will need a folder structure like this:

 

```
C:\TCAS\Keys\Public\
```

 

You will need to add a Transactor public key file to this folder:

 

```
TGSLPubK.rsa
```

 

The file is available from other developers or from within a code project such as "Insure with Audi":

 

```
InsureWithAudi\App_Data\EncryptionKeys\TGSLPubK.rsa
```

 

You will also need to add a registry key to your local registry. Use:

 

```
REGEDIT.exe
```

 

in a CMD window - or access it in whichever method you're familiar with. Here's the key path:

 

```
key path = HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\TGSL\TES
key (string) = C:\TCAS\Keys\Public\TGSLPubK.rsa
```

 

Now when trying to convert a prospect to a policy, your machine will have access to the key which will tell it where to kind the encryption key.