[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Motor Legal Protection Farm AmTrust

    **Underwriter:** AmTrust Europe Limited **Net Premium:** £5.00     **UAT Scheme Table Id:** 1553 **UAT Scheme File Name:** 43527I30.wpd  

---

  **Live Scheme Table Id:** 1513 **Live Scheme File Name:** 4358JMR7.wpd    

---

 

## Product

 

- [Motor Elite](/insurance-products/lawshield-dsp-b2b/motor-elite/)

 

---

 

## Scheme Description

 

The Motor Elite AmTrust **Product** has a number of different scheme files; some for variations in cover types, others are specific to particular brokers.

 

The **Motor Legal Protection Farm AmTrust** scheme is currently only available to **Towergate Devon & Cornwall** brokers.

 

### Scheme Validity

 

There is a DateDiff operation ensuring that policy start dates are on or after 1st June 2020 when the scheme started.

 

### Risk Data

 

We then retrieve the **Number of Vehicles** to insure from the Motor Elite AmTrust Details screen, along with the **Subagent Id** (DSP variant) and **Policy Type Id** which dictates which of the Motor Elite schemes quote or decline.

 

### Towergate Devon & Cornwall Broker Checks

 

The scheme checks the **Subagent Id** = 16 to ensure only Towergate Devon & Cornwall brokers receive premiums from this scheme. It declines in all other cases.

 

### Risk Data Validation

 

The scheme checks that the **Policy Type Id** = 6, indicating "Farm Vehicles", and declines in all other cases.

 

### Premium Calculation

 

Finally, the **Net Premium** is multiplied by the **Number of Vehicles** to determine the premium before commissions.

 

---