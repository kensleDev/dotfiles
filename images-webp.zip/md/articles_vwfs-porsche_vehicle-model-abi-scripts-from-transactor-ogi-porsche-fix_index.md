[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Vehicle Model ABI scripts from Transactor / OGI - Porsche fix

 

---

 

#### Vehicle Model ABI scripts from Transactor / OGI - Porsche fix

 

**Overview**

 

Each month Transactor send over as part of their underwriting release updated vehicle list SQL scripts that look something along the lines of the below:

 

![](../images-webp/image_62.webp)

 

These will need running against the Porsche TCAS database. Open GI do currently run this on our Lawshield/Velosure environment as part of the release they are contracted to deploy.

 

A fix script then needs to be run afterwards, to fix various issues with the naming convention for Porsche, that if not run breaks our web site model selector.

 

**Steps to take**

 

1). Copy the latest scripts from the Email in to the below folder:

 

\\192.168.30.18\CompanyData\Connexus Digital\Web Development\ABI Model Scripts

 

2). On UAT first, and then on Live if no issues, run all the vehicle scripts, and then run the fix script. The Porsche database is called version7_WA02. The vehicle scripts will update any Transactor environment with the latest vehicle lists from the ABI.

 

3). The Porsche fix script is only required on the Porsche environment. The fix script is available here: 

 

"\\192.168.30.18\CompanyData\Connexus Digital\Web Development\ABI Model Scripts\Porsche model fix.sql"

 

Run this.

 

4). Note you will need to clear the Redis cache to see the changes to vehicle models in the Porsche web site.

 

5). If you see Porsche models named incorrectly on the web site when entering vehicles manually:

 

![](../images-webp/image_63.webp)

 

Then you need to run the Porsche Fix script - or modify it accordingly based upon what you see as the problem vehicle models. They should look like this:

 

![](../images-webp/image_64.webp)