[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Updating Porsche Centres

 

---

 

A common request is to add new Centres to the Porsche website. Unlike updating the Paint and body shop task, these centres are also added to 2 Transactor tables. 

 

If the transactor part is forgotten, the 'before you begin' page will be happy, but reaching the end of the process, the quote will fail.  

 

The following SQL query outlines the full process 

 

```
USE [InsureWithPorsche] GO SELECT * FROM PorscheCentre WHERE CentreCode = 92073 BEGIN TRANSACTION INSERT INTO PorscheCentre ( CentreCode, CentreName )  VALUES ( 92073, 'Porsche Centre Norwich' ); ROLLBACK TRANSACTION --COMMIT TRANSACTION  USE [version7_WA02] GO SELECT * FROM LIST_ACTIVITY WHERE ACTIVITY_ID = '92073' SELECT * FROM LIST_ACTIVITY_LINK WHERE ACTIVITY_ID = '92073' BEGIN TRANSACTION INSERT INTO LIST_ACTIVITY(ACTIVITY_ID, ACTIVITY_DEBUG, DELETED, ABIVALUE, STARTDATE, ENDDATE, EXCLUDEWEB) VALUES ('92073', 'Porsche Centre Norwich', 0, 0, NULL, NULL, 0) GO INSERT INTO LIST_ACTIVITY_LINK(ACTIVITY_ID, PORTFOLIOKEY, AGENT_ID, PRODUCT_ID, ACTIVITY_DEFAULT) VALUES ('92073', 182, NULL, NULL, 0) GO ROLLBACK TRANSACTION --COMMIT TRANSACTION
```