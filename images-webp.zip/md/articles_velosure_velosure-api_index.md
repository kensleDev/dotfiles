[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Velosure API

 

---

 

### Definitions:

 

[V1 full definition json](/media/jtwngagv/velosure-v1.json)

 

 

 

### URLs:

 

UAT: [http://velosureapi.connexus-test.co.uk/](http://velosureapi.connexus-test.co.uk/)

 

PROD: [http://velosureapi.velosure.co.uk](http://velosureapi.velosure.co.uk)

 

 

 

### API Keys:

 

UAT: Velosure|6d4e4382-2b2e-4f1e-898c-03ee3644c17b

 

PROD: Velosure|c4aafc0c-b429-4f6f-8612-b40a69f862ad

 

To use, you need to had a header to the request with key 'x-api-key' and one of the above as the value 

 

 

 

### Endpoint paths:

 

###### AddressLookup

 

/api/AddressLookup/AddressLookup

 

 

 

###### Connexus CMS Articles

 

/api/ConnexusCMS/Articles/GetArticle/{articleId}

 

/api/ConnexusCMS/Articles/GetArticles/{brand}

 

/api/ConnexusCMS/Articles/GetArticlesByCategory/{brand}/{categoryId}

 

/api/ConnexusCMS/Articles/GetNumberOfArticles/{brand}/{articleCount}

 

 

 

###### BankDetails

 

/api/BankDetails/ValidateSortcode

 

/api/BankDetails/ValidateUkBankAccount

 

 

 

###### Connexus CMS Categories

 

/api/ConnexusCMS/Categories/GetCategory/{categoryId}

 

/api/ConnexusCMS/Categories/GetCategories

 

/api/ConnexusCMS/Categories/GetCategoriesByType/{contentType}

 

 

 

###### Email

 

/api/Email/RequestCallback

 

/api/Email/ContactUs

 

 

 

###### Connexus CMS FAQs

 

/api/ConnexusCMS/FAQs/GetFAQ/{faqId}

 

/api/ConnexusCMS/FAQs/GetFAQs/{brand}

 

/api/ConnexusCMS/FAQs/GetFAQsByCategory/{brand}/{categoryId}

 

/api/ConnexusCMS/FAQs/GetNumberOfFAQs/{brand}/{faqsCount}

 

 

 

###### Payment

 

/api/Payment/RetrieveAccessToken

 

/api/Payment/ValidatePayment