[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Newtonsoft.Json and British Summer Time

 

---

 

## The Problem

 

When using the Newtonsoft.Json library with client-side Javascript JSON.stringify(), DateTime objects will not be serialised/deserialised correctly by default during British Summer Time (BST). This is because Newtonsoft.Json has a default configuration to accept a string DateTime literally, rather than concerning itself with the current timezone. However, the JSON.stringify() will convert a local time to 'Zulu' time, meaning the conversion back to a DateTime on the server results in an innacurate DateTime.

 

## The Solution

 

To avoid this issue, you will need to tell Newtonsoft.Json to be aware of the local timezone. There are two ways to achieve this:

 

### JsonConvert.Deserialize() options

 

You can tell the call to JsonConvert.Deserialize() how to deal with timezones:

 

```
var settings = new JsonSerializerSettings { DateTimeZoneHandling = DateTimeZoneHandling.Local };
JsonConvert.DeserializeObject<YourType>(jsonString, settings);
```

 

### Global.asax Application_Start()

 

You can tell JsonConvert globally in the Global.asax how to deal with timezones for all deserializations:

 

```
JsonConvert.DefaultSettings = () => new JsonSerializerSettings
{
    DateTimeZoneHandling = DateTimeZoneHandling.Local
};
```