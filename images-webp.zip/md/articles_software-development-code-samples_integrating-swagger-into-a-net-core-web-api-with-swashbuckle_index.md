[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Integrating Swagger into a .Net Core Web API with Swashbuckle

 

---

 

## Introduction

 

Swagger UI is essentially an interactive online documentation of an API, and is automatically generated from the OpenAPI specification.

 

Swashbuckle is the .Net Core implementation of the OpenAPI specification used at Connexus and is installed into the API project using Nuget. The package name is **Swashbuckle.AspNetCore**.

 

 

 

## Adding and configuring the Swagger middleware

 

A very basic implementation of Swagger could be added to your API by adding the following blocks of code to your **Startup.cs**:

 

### Registering the Swagger generator

 

Add the following line to the **ConfigureServices** method:

  

```
// Register the Swagger generator, defining 1 or more Swagger documentsservices.AddSwaggerGen();
```

 

### Enabling Swagger and setting up the JSON endpoint

 

Add the following line to the **Configure** method:

 

```
// Enable middleware to serve generated Swagger as a JSON endpoint.app.UseSwagger();// Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),// specifying the Swagger JSON endpoint.app.UseSwaggerUI(c =>{    c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");});
```

 

This will serve up the Swagger UI at *your website*/swagger, and the JSON definition at *your website*/swagger/v1/swagger.json.

 

 

 

## Serving up the Swagger UI at the site root

 

Set the RoutePrefix property to an empty string by adding the following to the app.UseSwaggerUI lambda created in the previous code block:

 

```
c.RoutePrefix = string.Empty;
```

 

 

 

## Serving up Swagger over https

 

By default Swagger is served up over http; if the site is running over https then the UI is served up but attempting to use the Try it out functionality will result in an error. To avoid this, serve Swagger up over https by passing to the UseSwagger method as follows:

  

```
// Enable middleware to serve generated Swagger as a JSON endpoint over https.app.UseSwagger(c =>{    c.PreSerializeFilters.Add((swagger, httpReq) =>    {        swagger.Servers = new List<OpenApiServer> { new OpenApiServer { Url = $"https://{httpReq.Host.Host}" } };    });});
```

  

You will also need using Microsoft.OpenApi.Models

 

 

 

## Including XML comments in the Swagger UI

 The part of XML comments on the endpoints enclosed in the <summary> tag can be shown against the endpoint path in the Swagger UI  The following code is added manually to the .csproj file:  

```
<PropertyGroup>    <GenerateDocumentationFile>true</GenerateDocumentationFile>    <NoWarn>$(NoWarn);1591</NoWarn></PropertyGroup>
```

   Unless the **NoWarn** attribute is provided, any public methods without an XML comment will throw a warning "*Missing XML comment for publicly visible type or member*"  The following code should also be added to the delegate passed to services.AddSwaggerGen:  

```
// Set the comments path for the Swagger JSON and UI.
var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
c.IncludeXmlComments(xmlPath);
```

   

### Data annotations

 Data annotations such as **[Required]** will change the underlying Swagger JSON schema to add the Required properties into an array called required, and add an asterisk to the field in the Schema section of the UI.