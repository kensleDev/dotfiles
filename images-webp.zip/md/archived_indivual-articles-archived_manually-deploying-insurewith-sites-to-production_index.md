[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Manually Deploying InsureWith Sites to Production

 

---

 

## Introduction

 

In the UAT environment there are only single instances of each brands' ‘InsureWith’ site.

 

In the production environments there are three instances that all must be kept in sync. These three instances bridge two load balanced servers;

 

- PRDWEB03(192.168.105.105)
- PRDWEB04(192.168.105.106)

 

*PRDWEB03 has an additional instance, the ‘admin’ version.* This instance helps to mask the fact that the site is powered by Umbraco and provides a way to access the umbraco portal. In addition, when media files (images, pdf’s etc) are added, it is this instance of the site (more specifically, it’s ‘Media’ folder) that holds the updates. 

 

See the Article "Why Production InsureWith Sites have an Admin Instance" for a guide to the configuration.

 

## Preparing to deploy

 

The following steps can be done in advance of the planned deployment time which will will be scheduled in an agreed time period.

 

1. Via IIS on UAT server, explore the insureWith Site and zip up the files. *EXCLUDE the following*

 

1. *web.config*
2. *Scripts/Connexus/Env.js*
3. *config folder*
4. *Media folder, unless a CMS freeze has been agreed and new media added by CNX*
2. Connect the required server using RD manager – PRDWEB03
3. Paste .zip on desktop
4. Open IIS on server and right click the required site. Browse to this folder using explorer
5. Create a new folder with the new version number and unpack the zip there
6. Copy the following from a previous version and paste into new folder:

 

1. web.config
2. *Scripts/Connexus/Env.js*
3. config folder
4. Media folder*, unless a CMS freeze has been agreed and new media added by CNX*
7. In whitespace of new folder in explorer, right click properties
8. In security tab, click **Edit** then **Add**
9. Click Locations – set this to root (first option)
10. Enter the user ‘Iusr’ then click check names – click ok
11. Make sure this new user (IUSR) has ‘full control’ ticked
12. Make sure the user IIS_IUSRS exists and has ‘full control’ ticked
13. Repeat 9 -16 for the ‘admin’ version of the site. Notes that web.config, Scripts/Connexus/Env.js + config folders needs to be copied from the previous ADMIN version.
14. Repeat steps 7-17 on the server PRODWEB04

 

 

 

## Final Deployment

 

The following steps can only take place during scheduled Out-of-Hours session. Note that if no CMS/Media changes have been made, some steps can be omitted.

 

##### Schedule Maintenance

 

Use the website 24/7 to schedule enough working time to complete the task. Note that the finish time can be adjusted. The documentation for Site 24/7 is [here](/articles/deployment/site-24-7-monitoring/).

 

##### Website Bindings

 

Alter website bindings to point to the new deployment version. On PRDWEB03 there will be two to update, one on PRDWEB04.

 

##### Updating the Umbraco Media

 

If the task has involved updating the CMS data there are further tasks to keep the media in sync;

 

1. Use RedGate SQL Data Compare to copy UAT database to the live database
2. Copy the media folder from each brand UAT media folder to the Live brand media folder
3. Update the Virtual media path in IIS on PRDWEB03
4. Update the DFS settings to sync PRDWEB03 and PRDWEB04 media folders

 

Each of these are detailed below.

 

**1 Redgate Compare**

 

1. Open RedGate SQL Data Compare 13 software
2. Select UAT as the source site, the target will be Live;![](../images-webp/image_5.webp)

 

 3. Click 'Compare now'

 

 4. Click DEPLOY to commit

 

 5. Do this for each brand if required

 

**2-****Copy the media folder**

 

1. Use RDM to open the UAT server DEVWEB01 (192.168.204.217)
2. Use IIS to locate the Admin site for the required brand
3. Zip up the contents of the media folder and copy the zip to local desktop. *Ignore the config file in the media folder*
4. Place this on the desktop of PRDWEB03
5. Use IIS to locate the admin site media folder and unzip the content here after creating a backup

 

**3-****Update the Virtual media path**

 

The media folders in the InsureWith sites are *virtual directories* linked to the ‘*admin*’ version of the site. This is only for PRDWEB03. We will deal with how PRDWEB04 is linked next.

 

```

```

 

1. Right click on the (virtual) media folder and choose Advanced.
2. Update the physical path to match the new version number

 

**4-****Update the DFS settings**

 

If possible this should be completed last.

 

*[please visit the connexus group drive for a video demonstrating this process here-*

 

*\\db2003b\CompanyData\Connexus Digital\Web Development\Knowledgebase\Videos]*

 

PRODWEB04 InsureWith sites have a link the media folder in the ‘admin’ site on PRODWEB03.

 

This link is managed by the *DFS* server operation which effectively watches and mirrors the media folder.

 

*Note all of the tasks for this take place on PRODWEB03*

 

 

 

1. *Open Windows Server on PRODWEB03*

 

```

```

 

 2. Click DFS Management from Tools Menu

 

 3. Choose Replication from Left menu

 

```

```

 

 4. Select the brand

 

```

```

 

 5. Click the Replicated folder tab

 

##### 6. Delete the 'Media' entry - RIGHT CLICK & DELETE FOLDER NOT THE REPLICATION GROUP!!!!!

 

```

```

 

 7. Add a new replicated Folder from the left menu

 

 8. Select PRDWEB03 as the primary Member

 

```

```

 

 9. Click next then browse for the media folder (admin version) by clicking Add

 

```

```

 

 10. Click ok, then next to set up the ‘slave’ path (will be on PRDWEB04)

 

```

```

 

 11. Click Edit

 

 12. Click Enable then browse for the local source folder on PRDWEB04

 

```

```

 

 13. Clicking ok and next gives you a summary page

 

```

```

 

 14. Click Create. Click OK when shown the replication Delay dialog

 

 15. We can force the replication to happen without delay by opening ‘Services’ (still on PRDWEB03) and selecting the ‘DFS Replication’ service. Right click this and select ‘Restart’

 

```

```

 

This will be needed to be done for each brand/site.

 

##### Finally

 

1. Restart each site in IIS and recycle each application pool (on both servers)
2. Remove any unneeded zip files
3. the 24/7 site will show the status of the sites after the maintenance period has elapsed
4. If a specific feature has been added, test that feature across each site as appropriate