[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# VWFS Extended Warranty - Eligibility Criteria

 

---

 

There are some basic rules around Extended Warranty eligibility which are largely based on the extent to which the VWFS Manufacturer Warranties provide cover. There are additional rules for particular makes and models for various reasons, e.g. incentive to purchase.

 

## Basic Details

 

### Manufacturer Warranty

 

All VWFS-brand vehicles come with a Manufacturer Warranty that covers the vehicle from new, usually for a fixed term of 3 years up to a mileage limit during the third year, with some exceptions.

 

### Manufacturer Extended Warranty

 

VWFS-brand dealers offer a Manufacturer Extended Warranty to "top up" the Manufacturer Warranty; typically where a vehicle has been purchased second-hand between 2 and 3 years old in order to ensure a minimum 12 months warranty is supplied with the vehicle.

 

### Approved Used Warranty

 

VWFS-brand dealers offer an Approved Used Warranty on vehicles sold second-hand and usually last for 12 months from the date of purchase.

 

### Extended Warranty

 

#### Rates

 

VWFS Extended Warranty is then offered outside of the parameters of the above warranties at two different "rates":

 

##### Discounted

 

Where the customer purchases the Extended Warranty at a particular time, vehicle age or mileage.

 

In this case, the premium is heavily discounted dependent on other rating criteria and parameters.

 

##### Lapsed

 

Where a customer purchases the Extended Warranty outside of all of the above parameters.

 

In this case, the full premium is charged for the Extended Warranty dependent on other rating criteria and parameters.

 

#### Start Dates

 

VWFS Extended Warranty has protection rules applied to the possible start date of a policy to prevent fraudulent claims and incentivise renewal of existing policies:

 

##### Day-One Start

 

Where a customer purchases an Extended Warranty within +/-30 days of their existing policy, be it a Manufacturer, Approved or Extended Warranty, expiring.

 

In this case, the customer is granted continuous cover by starting the new policy the day after the existing policy expires, or the "next day" if their existing policy has expired, but they are within 30 days of that date.

 

##### Grace/Delayed Start

 

Where a customer purchases an Extended Warranty more than 30 days after any existing policy, be it a Manufacturer, Approved or Extended Warranty, expires.

 

In this case, the policy start date is delayed by 30 days in order to ensure no pre-existing faults are used to submit a claim against the new policy.

 

## Non-Commercial Vehicles (Audi, SEAT, SKODA and Volkswagen)

 

For Audi, SEAT, SKODA and Volkswagen the Manufacturer Warranty covers vehicles for unlimited mileage in the first two years, and up to 60,000 miles (total) in the third year before ceasing. Therefore the eligibility criteria for Extended Warranty is:

 

- The vehicle must be at least 2 years old
- The vehicle must have done at least 60,000 miles if between 2-3 years old
- The vehicle must have done less than 100,000 miles at the start of the policy

 

Additionally, there is an "incentive to buy" rule for vehicles that have only just breached the 60,000-mile boundary:

 

- If vehicle mileage is between 60,000-62,500 miles, the **discounted** rate applies

 

## Commercial Vehicles (VWCV)

 

For VWCV the Manufacturer Warranty covers vehicles for unlimited mileage in the first two years, and up to 100,000 miles (total) in the third year before ceasing. Therefore the eligibility criteria for Extended Warranty is:

 

- The vehicle must be at least 2 years old
- The vehicle must have done less than 100,000 miles if between 2-3 years old
- The vehicle must have done less than 120,000 miles at the start of the policy

 

However, there are special rules for the **Crafter** model of vehicle where the date of manufacture is after 24th April 2018. These vehicles are covered by an *unlimited mileage* Manufacturer Warranty for the first 3 years. Therefore for this specific model, built on or after 24th April 2018 the rule is simply:

 

- The vehicle must be at least 3 years old

 

There is no "incentive to buy" for VWCV as there is for the other brands.