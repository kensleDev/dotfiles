[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Family Select Legal Expenses

 

---

 

Family Select is a Legal Expenses product for families. Providing up to £50,000 legal expenses cover for the client and their family, for Personal Injury, Employment and Contract Disputes, Identity Fraud, Work Legal Defence, Property and Tax Protection and Jury Service. Family Select has been specifically designed to ensure that clients have peace of mind knowing that they are fully covered.

 

## Product Details

  **Product Reference:** FAMSEL **Product Type Id:** 667  

---

 

## Schemes

 

- [Family Select Legal Cover F&L](/insurance-products/lawshield-dsp-b2b/family-select-legal-expenses/family-select-legal-cover-f-l/)

 

---