[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# YAGNI Principle

 

---

 

- **Y** you
- **A** ain't
- **G** gonna
- **N** need
- **I** it

 

This principle goes hand-in-hand with KISS.

 

Development is a balance where we should define requirements that are essential, whilst considering non-essential or future requirements. This may cause you to expose your code through an interface, or provide some mechanism for future expansion (see SOLID principles) but that doesn't mean you create a whole new framework or service infrastructure that you *might* need later.