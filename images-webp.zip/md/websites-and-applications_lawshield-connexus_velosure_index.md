[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Velosure

 

---

   

## Website Details

  **Live URL:** [https://www.velosure.co.uk/](https://www.velosure.co.uk/) **UAT URL:** [https://velosure.connexus-test.co.uk/](https://velosure.connexus-test.co.uk/)    HTML ReactJS CSS Bootstrap   

---

 

Velosure is a public, customer-facing insurance quote-and-buy website for Lawshield's Pedal Cycle insurance product. The website provides information and a quote-and-buy facility allowing customers to purchase pedal cycle insurance, written in React JS. 

 

## Content Management

 

Velosure uses our internal [light weight CMS](/websites-and-applications/lawshield-connexus/velosure-connexus-cms/) which is served by the [Velosure API](/websites-and-applications/lawshield-connexus/velosure-api/)

 

## Integrations

 

The Velosure website integrates with several third-party services hosted both internally at Connexus and externally which are all handle with request to and from the [Velosure API](/websites-and-applications/lawshield-connexus/velosure-api/)

 

The Velosure website integrate with Transactor are handle though the [Lawshield V6 API](/websites-and-applications/lawshield-connexus/lawshield-v6-api/)

 

## Further Reading

 

Further details about technologies, architecture and insurance products can be found in other areas of the Knowledgebase:

 

- [Lawshield Pedal Cycle (Velosure)](/insurance-products/lawshield-b2c/lawshield-pedal-cycle-velosure/)