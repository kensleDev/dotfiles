[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Motor Elite Extra Panel Van AmTrust

    **Underwriter:** AmTrust Europe Limited **Net Premium:** £5.00     **UAT Scheme Table Id:** 1554 **UAT Scheme File Name:** 435295V5.wpd  

---

  **Live Scheme Table Id:** 1515 **Live Scheme File Name:** 4358JSG9.wpd    

---

 

## Product

 

- [Motor Elite Extra](/insurance-products/lawshield-dsp-b2b/motor-elite-extra/)

 

---

 

## Scheme Description

 

The Motor Elite Extra AmTrust **Product** has a number of different scheme files; some for variations in cover types, others are specific to particular brokers.

 

### Scheme Validity

 

There is a DateDiff operation ensuring that policy start dates are on or after 1st June 2020 when the scheme started.

 

### Broker-Specific Logic

 

The scheme checks that the **Subagent Id** != 15 (Towergate Antur), **Subagent Id** != 27 (Romero Insurance Brokers) and **Subagent Id** != 28 (Howden). It declines for all three brokers.

 

### Risk Data Validation

 

The scheme then checks that the **Hire Vehicle Id** = 3 (Panel Van Hire Vehicles) to ensure quotes can only be obtained for Panel Van Hire Vehicles. It declines in all other cases.

 

---