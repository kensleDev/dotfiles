[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Home Emergency

    **Underwriter:** Inter Partner Assistance SA (IPA) which is fully owned by the AXA Assistance Group **Net Premium:** £31.00     **UAT Scheme Table Id:** 1376 **UAT Scheme File Name:** 3QV2VP68.wpd  

---

  **Live Scheme Table Id:** 1376 **Live Scheme File Name:** 3QV2VP68.wpd    

---

 

## Product

 

- [Home Emergency](/insurance-products/lawshield-dsp-b2b/home-emergency/)

 

---

 

## Scheme Description

 

No rating logic required for the Home Emergency scheme - just a flat underwriter net rate.

 

---