[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Adding Parameters to Email Links

 

---

 

Below are the steps explaining how to append parameters to the email links:

 

1. On Step 3 of creating a new email campaign, click the **Links parameters (UTM, ... )**option.
2. Using the "**+**" icon, add as many key-value pairs for the link as required (there is a quick link to add all required Google Analytics parameters (**utm_source**, **utm_campaign**, **utm_medium**) by clicking "Add google analytics"
3. When done, click "Save" and carry on with setting up the email campaign