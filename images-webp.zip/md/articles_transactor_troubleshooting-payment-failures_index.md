[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Troubleshooting Payment Failures

 

---

 

There is a special log in Event Viewer under "Application and Service Logs" called "eTES" which is where any payment issues are logged by Transactor
Look for anything unknown; known errors are:
Card payment failed. NOT AUTHORISED (card declined)