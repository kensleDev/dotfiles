[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Planning Poker for User Stories

 

---

 

## Planning Poker

 

Planning Poker is the process of determining an estimated 'effort' value for a given customer requirement based on two or more factors; usually considering at least **time** and **complexity**.

 

Each developer decides what 'effort' they feel should be applied in private before everyone shares with the group. On sharing there are usually only two outcomes:

 

1. All developers agree on the same 'effort' value - in which case that is the effort estimated for the requirement
2. At least one developer differs in their 'effort' value - in which case developers with high *and* low efforts should justify their choice before an estimate is applied to the requirement

 

### Effort Values

 

There is a "standard" set of effort values to use in Planning Poker, typically designed to represent an exponential increase in the effort:

 

- 1, 2, 3, 5, 8, 13, 20, 40, 100

 

### Effort Representation

 

At Connexus, the effort values above have typically represented the following breakdown with respect to **time** and **complexity**:

 

- **1** - usually only taking an hour or two; or one that is very simple to complete
- **2** - taking up to half a day; some potential for complexity
- **3** - taking up to a full day; likely some level of complexity involved
- **5** - taking 2-3 days; a reasonable level of complexity
- **8** - taking up to a week (5 days); a high level of complexity
- **13** - taking more than a week; very high complexity

 

Anything reaching an effort value higher than **5** should be considered as a candidate for further refinement and breaking down into smaller sub-requirements.