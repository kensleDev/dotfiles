[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Porsche - showing "holding page" for Aviva downtime

 

---

 

Navigate to [https://admin.insurewithporsche.co.uk/umbraco](https://admin.insurewithporsche.co.uk/umbraco) and login

 

Expand Home in the Content tab

 

Click on **Before You Begin Annual** and select the Properties tab

 

Change the Template dropdown from Annual Car Insurance to Annual Car Insurance Unavailable

 

Save and publish

 

Repeat for **Before You Begin Drive Away**