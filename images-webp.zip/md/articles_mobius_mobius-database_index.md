[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Mobius Database details

 

---

 

**You have to access the database from DEVSQL02, PRDSQL1 or PRDSQL2 as whitelisted for those servers only.**

 

**In SSMS**

 

**Login TAB**

 

Server name: sql-asqlgr-prod-uks.database.windows.net

 

Authentication: Microsoft Entra MFA

 

User name: Your Open GI Mobius login, for the relevant database.

 

E.g.

 

**Volkswagen**

 

[Your.Name@VW01.tenant.ogi-mobius.com](mailto:Digital.Development@VW01.tenant.ogi-mobius.com)

 

****

 

**Lawshield (Carbon / Velosure)**

 

[Your.Name@LS01.tenant.ogi-mobius.com](mailto:Your.Name@VW01.tenant.ogi-mobius.com) 

 

![](../images-webp/image_3.webp)

 

**Connection TAB**

 

Connect to database:

 

**Volkswagen**

 

tenant-db-vw01

 

![](../images-webp/image_4.webp)

 

**Lawshield (Carbon / Velosure)**

 

tenant-db-ls01

 

![](../images-webp/image_5.webp)