[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# IIS config for routing

 

---

 

As React is a SPA and handles routing internally with JS, if 'regular' routing is attempted the links don't exist producing a 404 error. 

The solution is URL rewriting in IIS. Rules can be added through the IIS panel, but much simpler is to add a web.config file. 

 

For Velo2022 on UAT the following Web.config was added. In addition a base href was added to <head> in index.html -

 

<base href="velosure2022.connexus-test.co.uk"/>

 

```
<?xml version="1.0" encoding="UTF-8"?><configuration><system.webServer><rewrite><rules><rule name="ReactRouter Routes" stopProcessing="true"><match url=".*" /><conditions logicalGrouping="MatchAll"><add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" /><add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" /><add input="{REQUEST_URI}" pattern="^/(docs)" negate="true" /></conditions><action type="Rewrite" url="index.html" /></rule></rules></rewrite></system.webServer></configuration>
```