[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# GlobalPay Hosted Payment Page (HPP) Styling

 

---

 

For the GlobalPay Hosted Payment Page (HPP) styling, please see the Summary, with the details below for further information.

 

**HPP Styling Requirements Summary**

 

- **File size:** Maximum 262 KB per file (zipped), no maximum set size to full zip.
- **File types:** HTML, CSS, JPG, PNG, GIF only
- **Resources:** Must be locally referenced (no external URLs)
- **Security:** No scripting allowed
- **Structure:**
- **Submission:** Create template → ZIP all files → Send to Global Payments support

 

 

 

Further details...

 

- To use a custom font, you can upload a .woff file
- Individual font files **must not exceed 512 KB** in size (once zipped up)

 

- **Fallback font**: If a custom font cannot be loaded, or if a non-Latin character is needed and not supported by your custom font, the HPP will fall back to a default font.
- **Web-safe options**: The platform supports common web-safe fonts that can be referenced in your CSS, such as Arial, Georgia, and Verdana.

 

- **Apply with CSS**: After uploading, you will need to reference the font using the @font-facerule in your custom CSS file. For example:

 

```
@font-face {font-family: 'MyCustomFont';src: url('custom-font.woff') format('woff');}body {font-family:'MyCustomFont', sans-serif;}
```

 

**What is the maximum size of a zip that i can upload for HPP styling?**

 

The maximum size for any individual file (HTML, CSS, or image) within your Hosted Payment Page (HPP) styling ZIP is 

 

**262 KB**. The total size of the compressed ZIP file is not specified, but this limit on individual files must be followed. 

 

 

 

**Key requirements for HPP styling**

 

When you prepare and submit your custom design templates, you must adhere to the following guidelines: 

 

- **Maximum individual file size:** Each file, such as desktop.html, mobile.html, CSS files, and images (JPG, PNG, GIF), must not exceed 262 KB.
- **Supported files:** The compressed ZIP should only contain HTML, CSS, JPG, PNG, and GIF file types.
- **Local references only:** All external resources like images and CSS must be referenced locally within the template files. External URLs are not permitted.
- **Secure contents:** The template files cannot contain any scripting for security reasons.
- **Specific file names and structure:**

 

**How to submit your styling**

 

1. **Create your template:** Build your custom HTML and CSS files, ensuring all resources are locally referenced.
2. **Compress your files:** Place all your files and asset folders into a single ZIP archive.
3. **Contact support:** Send the completed ZIP to your Global Payments account manager or support team to have it uploaded and applied to your HPP.