[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Landlord Legal Expenses

 

---

 

Landlord Legal is a Legal Expenses product for landlords when they need legal cover in case of a dispute.

 

## Product Details

  **Product Reference:** LLEGAL **Product Type Id:** 679  

---

 

## Schemes

 

- [Landlord Legal Expenses](/insurance-products/lawshield-dsp-b2b/landlord-legal-expenses/landlord-legal-expenses/)

 

---