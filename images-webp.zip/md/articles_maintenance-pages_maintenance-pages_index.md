[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# How to use Maintenance Pages

 

---

 

#### About

 

For those occasions where we need to take a website offline, we have created a collection of HTML 'Maintenance Pages' - one per each brand/site. These all have the name "App_Offline.html" and are branded appropriately and typically feature the customer service telephone number for that brand/product.

 

For both production servers (PRDWEB1 and PRDWEB2) and UAT there is a folder containing these pages. 

 

```
c:\inetpub\maintenancePages\[Brand]
```

 

#### How to use?

 

Simply locate the required maintenance page from the folder above, copy and paste this App_Offline.html file into the root of the website.

**How does it work?**

 

IIS will see that this certain file is in the root folder and redirect all traffic to this page, effectively hiding the actual page. 

 

#### Notes

 

Be careful to copy, not move the html page from the c:\inetpub\maintenancePages\[Brand] folder

 

Delete the file from the website root to allow traffic to be correctly routed once maintenance is complete.