[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Ensurance - Customer Communications - Emails and Letters

 

---

 

## Introduction

 

Connexus use the **Transactor** platform to send out customer communications regarding VWFS Ensurance.

 

### Emails

 

There are four email templates per brand:

 

| Template Name | Purpose |
| --- | --- |
| confirmation_of_cover.html | Confirmation of Cover email |
| renewal_reminder_01.html | Standard renewal invitation email |
| renewal_reminder_02.html | Renewal invitation reminder email |
| renewal_reminder_03.html | Cover lapsed renewal invitation email |

 

Some of these template names may vary slightly from brand to brand, but they serve the same purposes.

 

### Letters

 

There are three letter templates per brand, plus a Confirmation of Cover document:

 

| Template Name | Purpose |
| --- | --- |
| Your Confirmation of Cover.doc | Confirmation of Cover letter |
| Renew your Ensurance Cover.doc | Standard renewal invitation letter |
| Your Ensurance cover has ended.doc | Cover lapsed renewal invitation letter |
| Ensurance Confirmation of Cover.doc | Provides confirmation of insurance to the customer and acts as a Statement of Fact including the cover details provided. |

 

Again, some of these template names will vary slightly from brand to brand.