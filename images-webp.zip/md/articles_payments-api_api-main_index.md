[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Payments API

 

---

 

**The Project**

 

The API calls are presently in Payments ReactJS which is an NPM package, eventually this will need to be installed in NPM Privately, but for now you can register it using this:

 

[https://medium.com/dailyjs/how-to-use-npm-link-7375b6219557](https://medium.com/dailyjs/how-to-use-npm-link-7375b6219557) (NPM Link)

 

the rest of my front end code is in PaymentsNew, and we’re using the googlepay-fix branch because the payment branch is broken.

 

**Credentials**

 

| Login | User | Pass | Notes |
| --- | --- | --- | --- |
| Apple Pay | development@connexus.co.uk | k80W1z5PFp&K | Used to manage certificates for the button (alongside Worldpay) |
| Paypal (Account) | development@connexus.co.uk | *1OaT#tnWg3h | For Account Management |
| Paypal (Sandbox Admin) | sb-4nbmk21529801@business.example.com | d?!}Kvz6 | To Check for Payments |
| Paypal (Sandbox User) | sb-47asc319868174@personal.example.com | 0V8BtEv> | To make a Payment |
| Google (for Pay) | connexus.developer@gmail.com | 1XhgZY53V!gD | Dedicated account for google payments |

 

Note: Google and Apple pay do not provide test users, these must be created, see the specific pages on setup and testing for more info.

 

**Card Payments**

 

Card payments are handled through the GpAPI route (Global Pay API) on the .Net SDK and implements the 3DSecure processes described in the Global Pay documentation, [see here for full details.](/articles/payments-api/card-payments/)

 

**Digital Wallets**

 

**Paypal**

 

Paypal is simply a passthrough for the paypal API, payments are collected and logged directly through paypal so there is no API/SDK integration through world pay for this route. 

 

We connect to the payments API purely to log successful and failed payments.

 

More Details Here: [Paypal Pay](/articles/payments-api/paypal-pay/)

 

**Google Pay**

 

The Google pay system uses a ReactJS plugin to provide an overlayer to the existing Google payment javascript, this generates a token to process payment via the GP-Ecom API's. More detail can be found [here](/articles/payments-api/google-pay-setup-and-testing/)

 

**Apple Pay**

 

Due to an issue with certificates this section is still under development and subject to change. The placeholder page can be found [here](/articles/payments-api/apple-pay-setup-and-testing/)