[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# DEVAPP1

 

---

 

## Server Details

  **Server Type:** Transactor **IP Address:** 192.168.204.75  

---

 

This server is the development and test **Transactor v6 Application Server** for all Lawshield B2B and B2C products and hosts all Transactor v6 applications and services, including:

 

- TCAS
- TES Tool Suite
- Relationship Manager
- TES Screen Builder
- Relationship Manager Service
- Document Service (incl. MSMQ etc.)
- TES PCEFT Server

 

 

 

---

 

## Insurance Products

 

- [Lawshield Pedal Cycle (Velosure)](/insurance-products/lawshield-b2c/lawshield-pedal-cycle-velosure/)
- [Motor Elite](/insurance-products/lawshield-dsp-b2b/motor-elite/)
- [Motor Elite Extra](/insurance-products/lawshield-dsp-b2b/motor-elite-extra/)
- [Family Select Legal Expenses](/insurance-products/lawshield-dsp-b2b/family-select-legal-expenses/)
- [Equestrian Plan Legal Protection](/insurance-products/lawshield-dsp-b2b/equestrian-plan-legal-protection/)
- [Park Homes and Static Caravan Legal Protection](/insurance-products/lawshield-dsp-b2b/park-homes-and-static-caravan-legal-protection/)
- [Home Emergency](/insurance-products/lawshield-dsp-b2b/home-emergency/)
- [Keycare](/insurance-products/lawshield-dsp-b2b/keycare/)
- [Excess Waiver](/insurance-products/lawshield-dsp-b2b/excess-waiver/)
- [Brokerbility Breakdown Insurance](/insurance-products/lawshield-dsp-b2b/brokerbility-breakdown-insurance/)
- [Landlord Home Emergency](/insurance-products/lawshield-dsp-b2b/landlord-home-emergency/)
- [Landlord Legal Expenses](/insurance-products/lawshield-dsp-b2b/landlord-legal-expenses/)
- [Landlord Rent Guarantee](/insurance-products/lawshield-dsp-b2b/landlord-rent-guarantee/)