[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Getting the correct typescript version

 

---

 

This solution requires the typescript package v2.3. Looking at the properties of the InsureWithPorsche project - typescript panel, you will see that 2.3 is marked as unavailable.

 

Running a newer version as suggested by the IDE causes errors.

 

run this to get the correct version..

 [http://download.microsoft.com/download/7/0/A/70A6AC0E-8934-4396-A43E-445059F430EA/2.3.3-TS-release-dev14update3-20170519.1/TypeScript_SDK.exe](http://download.microsoft.com/download/7/0/A/70A6AC0E-8934-4396-A43E-445059F430EA/2.3.3-TS-release-dev14update3-20170519.1/TypeScript_SDK.exe)  then restart VS.