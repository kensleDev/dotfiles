[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Landlord Home Emergency

 

---

 

Landlord Home Emergency will provide assistance in the event of an emergency situation.
Cover will be provided for rapid expert help using a national network of contractors to assist and stabilise the problem.
Our Landlord Home Emergency cover complements the landlord buildings insurance and provides peace of mind for customers.
The cover is provided for labour, parts and materials to carry out emergency repairs.

 

## Product Details

  **Product Reference:** LLHMEMRG **Product Type Id:** 670  

---

 

## Schemes

 

- [Landlord Home Emergency](/insurance-products/lawshield-dsp-b2b/landlord-home-emergency/landlord-home-emergency/)

 

---