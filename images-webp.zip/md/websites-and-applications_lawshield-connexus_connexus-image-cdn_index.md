[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Connexus Image CDN

 

---

 

##### Introduction

 

A new image hosting solution was required in 2020 when the previous method was retired. It was decided to build our own in house leveraging the Azure Blob storage. Image hosting is required to serve all of the images that we use in the various emails sent out by the company. The original project was built using .net core with a VueJS front end. Both of these elements are in the same solution.
The solution was well adopted and used in wider projects than just emails. This led to questions about whether we could expand the app to allow other file types to be stored including PDFs and DOC.

 

A new version was created utilizing a ReactJS client side with a .net core API. The API connects to the same Azure blob store as the previous version. The new app can manage the previous image types - jpg, gif and png but can now take document types - PDF and DOC and also SVG images. 

 

#### How to use it

 

The App is called from the Intranet front page;

 

![](../images-webp/image_89.webp)

 

 The App starts as follows
![](../images-webp/image_90.webp)

 

Clicking a container will show the contents in the main panel. From here, mousing over an image/doc will show basic information, as well as the option to see a larger 'preview' or to copy the link to the clipboard;

 

![](../images-webp/image_91.webp)

 

Once the link is in the clipboard it can then be inserted into an emails template or html etc. It will have the form....

 

 https://connexus-cdn.azureedge.net/aa1/skoda3.jpg

 

New containers can be added by clicking the large '+' button. Characters are limited here to lowercase, no spaces and limited 'special' characters. Folder names should follow the existing formatting i.e. lowercase with a dash to separate words.

 

To add new files ( png, bmp, gif, jpg, pdf, doc, svg) either click the upload button (inside the dashed box) and select from windows explorer, or drag your file(s) over the dashed box. This will generate a list of uploads. Click the 'Upload Files' blue button to store these files in your selected folder. 

 

#### Technologies Used

 

The front-end is built using ReactJS v18.

 

API is .net 6.0

 

#### Deployment

 

Both the front-end App and the API are installed on Intranet - PRDWEB07 (192.168.104.63) server.

 

![](../images-webp/image_92.webp)

 

#### Source Control

 

Both projects are stored in GitHub.

 

[https://github.com/Connexus-Digital-Development/ConnexusCDN-Client](https://github.com/Connexus-Digital-Development/ConnexusCDN-Client)

 

[https://github.com/Connexus-Digital-Development/ConnexusCDN-API](https://github.com/Connexus-Digital-Development/ConnexusCDN-API) 

 

#### API Project

 

The API project is the 'back-end' for the solution and handles the requests from the client-side React App. It also handles all of the interactions with the Azure blob storage. In development mode/UAT the API has a swagger page to outline the available endpoints. Note that no delete functionality is available to the client. This is true for both Containers and the Blobs (files). 

 

#### Azure Blob Storage

 

The blob storage can be found [here](https://portal.azure.com/#@ConnexusInsurance.onmicrosoft.com/resource/subscriptions/45ecb0bd-11a6-46b2-8175-534bdc9fba00/resourceGroups/Azure_CDN/providers/Microsoft.Storage/storageAccounts/connexuscdnstorage/containersList)

 

Within the Azure portal files/folders/containers can be deleted/renamed etc.

 

![](../images-webp/image_93.webp)![](blob:http://connexusknowledgebase.connexus.rackspace/cb25a780-677c-4e43-89a9-cfebeae512b7?width=787&height=357&mode=max)

 

 As it is almost impossible to track where these files(blobs) are being used, the utmost care should be exercised when deleting blobs / containers.