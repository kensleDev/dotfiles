[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# PRDWEB05

 

---

 

## Server Details

  **Server Type:** Web **IP Address:** 192.168.104.4  

---

 

This is the primary **IIS** web server for the following Lawshield websites hosted at Connexus and is load-balanced at Rackspace with [PRDWEB06](/servers/production-lawshield/prdweb06/).

 

Public: 94.236.15.219 (as per ipchicken.com).

 

---

 

## Websites

 

- Velosure - [https://www.velosure.co.uk/](https://www.velosure.co.uk/)
- Lawshield Digital Sales Platform (DSP) - [https://dsp.lawshield.co.uk/](https://dsp.lawshield.co.uk/)
- Connexus Claim Tracker - [https://claimtracker.connexus.co.uk/](https://claimtracker.connexus.co.uk/)
- Connexus Claim Tracker API - [https://claimtracker-api.connexus.co.uk/](https://claimtracker-api.connexus.co.uk/)
- Lawshield V6 API - [https://lawshieldv6-api.lawshield.co.uk/](https://lawshieldv6-api.lawshield.co.uk/)
- Connexus Policy Validator API - [https://policy-validator-api.connexus.co.uk/](https://policy-validator-api.connexus.co.uk/)
- ProClaim API - [https://proclaim-api.lawshield.co.uk/](https://proclaim-api.lawshield.co.uk/)
- Autoglass Body Repair - [https://autoglassbodyrepair.lawshield.co.uk/](https://autoglassbodyrepair.lawshield.co.uk/)
- CMA Core - [https://core.connexusmedicalappointments.co.uk/](https://core.connexusmedicalappointments.co.uk/)
- Hi-Vis - [https://hi-vis.performancecarhire.co.uk/](https://hi-vis.performancecarhire.co.uk/)