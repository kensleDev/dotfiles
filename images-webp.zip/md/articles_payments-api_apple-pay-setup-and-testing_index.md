[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Apple Pay - Setup and Testing

 

---

 

# Setup

 

The Apple Pay button, is the only one without a specific walkthrough demo of its own. it follows the same concepts as the other buttons, in that you have to authorise a payment and return a token to global pay. to complete the transaction. 

 

installing the button is described here: [Apple Developer Docs](https://developer.apple.com/documentation/apple_pay_on_the_web/choosing_an_api_for_implementing_apple_pay_on_your_website)

 

essentially the core JS is provided here: [Setting up the Payment Request API](https://developer.apple.com/documentation/apple_pay_on_the_web/payment_request_api/setting_up_the_payment_request_api_to_accept_apple_pay)

 

Below is the main segment of code you will want to look at if the token is not being sent correctly, this is where the token will be returned and submitted.

 

```
paymentRequest.show().then(function(paymentResponse) {    if (paymentResponse.methodName === "https://apple.com/apple-pay") {       if (!hasValidShippingZIPCode(paymentResponse)) {          paymentResponse.retry({            paymentMethod: [                new ApplePayError("shippingContactInvalid", "postalCode", "ZIP Code is invalid"),             ],          });          return;        }          // Handle authorization with valid details here.   }});
```

 

Important: A certificate must be installed as part of initial setup, how to do this is described in the "Create and Upload an Apple Pay certificate" section of the [Global Payments API - Digital Wallets](https://developer.globalpay.com/docs/digital-wallets#apple-pay)

 

# Testing

 

[Sandbox Testing (Includes Test Cards)](https://developer.apple.com/apple-pay/sandbox-testing/)

 

We have set a test sandbox user for UAT testing and below is the recommend test card (some the test card will randomly fail when trying to add them to your apple pay wallet).

 

Username: [appletester@connexus.co.uk](mailto:appletester@connexus.co.uk)

 

Password: jJ45Ggj5BafC

 

card details:

 

- Card number: 4761 3497 5001 0326
- Expiration Date: 12/2025
- CVV: 747