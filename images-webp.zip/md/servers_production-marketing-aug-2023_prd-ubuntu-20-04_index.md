[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# PRD-UBUNTU-20.04

 

---

 

## Server Details

  **Server Type:** Web **IP Address:** 51.145.114.15  

---

 

Currently hosts KLS, Specters and OYB

 

---

 

## Websites

 

- KLS Law - [https://www.klslaw.co.uk](https://www.klslaw.co.uk)
- Specters - [https://www.specters.co.uk/](https://www.specters.co.uk/)
- Off Your Bike - [https://www.offyourbike.co.uk/](https://www.offyourbike.co.uk/)