[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Velosure - Architecture

 

---

 

## Introduction

 

The technology used in Velosure comprises:

 

- Microsoft .NET Core 3.1
- ASP.NET MVC Core
- Entity Framework Core
- VueJS (version 2) implemented in Typescript
- SCSS
- Umbraco Heartcore CMS
- Microsoft SQL Server
- OpenGI Transactor (version 6)

 

## Application Architecture

 

The website has the following projects:

 

- **Velosure** - the front-end project, mostly VueJS with some ASP.Net MVC controllers
- **Velosure.Common** - common models used by the front-end and service-layer
- **Velosure.Services** - major service-layer implementations

 

These projects are source controlled in an Azure DevOps "Project"; **Velosure**. This project has a master 'trunk' code line, plus 'branches' which have been used for work in progress.

 

#### Integrations

 

The website has several integrations with both internal and external systems:

 

- **Transactor v6** - for quoting and inception of insurance policies
- **FastCode** - for searching address details by postcode
- **BottomLine** - for validating bank account details

 

#### CMS Integration

 

The structure of the site is driven by the CMS. 

 

##### Routing

 

All routes are retrieved from the CMS and added to the predefined news routes. The CMS information for the whole site is retrieved on initial load, but all that is used at this point is:

 

- **Name** - The Content name from the CMS, used as the route name
- **Slug** - The relative URL of the page
- **Id** - The ID Guid from the *Info* tab, used to load the page on navigation

 

##### Page structure

 

The Velosure application has no knowledge of the website structure, nor even how to construct most of its pages. The **component** of each route is *VelosurePage.vue*, which takes the page ID as a prop, retrieves the page's content from the CMS, *with a depth of 3 - this is important as this is what enables embedded images to be retrieved with a single fetch*, and loops over the page's components retrieved from the CMS in order, rendering the appropriate Vue component.

 

##### Quote journey

 

The quote journey uses the CMS in a more traditional way, ie to retrieve content and styling rather than the page structure. This still uses *VelosurePage.vue* to render *QuoteJourneyComponent.vue* but this page is smarter than most of the Vue components, managing state and which page to display based on the step.

 

##### News

 

The main news page is *NewsBlockComponent.vue*, and the home page has a news carousel, *NewsLatestSummaryBlockComponent.vue*. Again this is a more traditional use of a CMS in that there are several sub-components and which are displayed and where comes from the HTML rather than being determined by the CMS.

 

News posts are added by Marketing, however note that there is a flaw with Umbraco Heartcore in that the sort order is determined by the Sort property, and this is not transferred from the Development to Live environment. Umbraco have suggested using GraphQL to retreive the news but we tried this and encountered so many bugs that it was not feasible. This would be worth revisiting at a later date.

 

## CMS User Guide (Training)

 

This is available [here](/media/daxf0gmy/velosure-umbraco-heartcore-user-guide-v2.pdf).