[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# VWFS Websites - Architecture

 

---

 

## Introduction

 

Connexus builds, manages and maintains eight websites for Volkswagen Financial Services (VWFS):

 

- Insure with Audi - [https://www.insurewithaudi.co.uk](https://www.insurewithaudi.co.uk)
- Insure with SEAT - [https://www.insurewithseat.co.uk](https://www.insurewithseat.co.uk)
- Insure with SKODA - [https://www.insurewithskoda.co.uk](https://www.insurewithskoda.co.uk)
- Insure with Volkswagen - [https://www.insurewithvolkswagen.co.uk](https://www.insurewithvolkswagen.co.uk)
- Insure with VWCV - [https://www.insurewithvwcv.co.uk](https://www.insurewithvwcv.co.uk)
- Insure with Porsche - [https://www.insurewithporsche.co.uk](https://www.insurewithporsche.co.uk)
- VWFS Insurance Portal - [https://www.vwfsinsuranceportal.co.uk](https://www.vwfsinsuranceportal.co.uk)
- Loan Car Insurance - [https://www.loancarinsurance.com](https://www.loancarinsurance.com)

 

All of these websites have a common technology base at present, mostly comprising:

 

- Microsoft .NET Framework 4.5+
- ASP.NET MVC 5
- Entity Framework 6
- jQuery and AngularJS (version 1) implemented in Typescript
- CSS 3 or SCSS
- UmbracoCMS (version 7)
- Microsoft SQL Server

 

Additionally, there are other technologies in use in some, but not all of these websites:

 

- OpenGI Transactor (version 6 or 7)
- Redis (for caching)

 

## Application Architecture

 

### Insure with Audi, SEAT, SKODA, VW and VWCV

 

These five websites not only share a common technology stack but also a common codebase for the most part. Each website has its' own unique ASP.NET MVC 5 front-end application project integrated with UmbracoCMS. However, they all share a common set of projects for their business logic, both on the server and client-side, including:

 

- **RefreshMvc.Services** - major service-layer implementations
- **RefreshMvc.Ensurance** - services and models specific to the *Ensurance* product
- **RefreshMvc.EwRenewals** - services and models specific to the *Extended Warranty* product
- **RefreshMvc.Proclaim** - services and models specific to *Proclaim* integration
- **RefreshMvc.Services.Shared** - shared services and models, such as ViewModels or Converters
- **RefreshMvc.Services.Transactor** - services and models specific to *Transactor* integration
- **RefreshMvc.Typescript** - client-side Typescript business logic and UI manipulation

 

These shared projects are source controlled separately from each of the front-end websites in their own Azure DevOps "Project"; **InsureWith-Shared**. This project has a master 'trunk' code line, plus brand-specific 'branches'.

 

The projects in each of the brand-specific branches are then referenced by the brand-specific *Solution* containing the same brand front-end project. Thus changes made within a brand-specific *Solution* are committed to the brand-specific branch of the shared project. These can then be merged to the **Trunk**, before merging out to the other brand-specific branches in order to share the same codebase.

 

#### RefreshMvc.Typescript Specifics

 

It is important to note that the client-side business logic is implemented with Typescript in a *shared* project. However, in order to be functional within a website, the resulting transpiled JavaScript must reside within the website itself. Unlike C#, the Typescript and/or JavaScript cannot be easily referenced by the website project from an external project.

 

Therefore each front-end website has a pre-build script that runs on a successful build of the solution. This pre-build script performs a copy of all files from the **RefreshMvc.Typescript** project to the **/Scripts** folder of the associated front-end website project. The below example is from Insure with Audi:

 

```
xcopy /Y /E "$(SolutionDir)..\..\InsureWith-Shared\Branches\InsureWithAudi\RefreshMvc.Typescript\Scripts\*.*" "$(ProjectDir)\Scripts\"
```

 

#### Integrations

 

These five "Insure with" websites have several integrations with both internal and external systems:

 

- **Transactor v6** - for quoting and inception of Extended Warranty and Ensurance policies
- **Proclaim** - for creation and reporting of claims
- **Carweb** - for searching vehicle details based on a VRM or VIN
- **FastCode** - for searching address details by postcode
- **BottomLine** - for validating bank account details

 

### Insure with Porsche

 

This website shares a fairly common technology stack with the other "Insure with" websites. As the insurance products on this website are entirely different, the projects implemented in this solution are unique to Insure with Porsche. However where possible the overall application architecture is very similar:

 

- **PorscheInsurance** - ASP.NET MVC 5, UmbracoCMS and AngularJS front-end website
- **PorscheInsurance.Services** - major service-layer implementations
- **PorscheInsurance.Shared** - shared services and models such as Configuration and Enumerations
- **PorscheInsurance.Validation** - validation services and models
- **PorcheInsurance.Data** - data-layer integrations, usually with Entity Framework 6
- **PorscheInsurance.Services.Sanctions** - 3rd party integration for sanctions checking
- **ConnexusComponents.SagePay** - a componentised 3rd party integration with SagePay

 

#### Integrations

 

The Insure with Porsche website has multiple integrations with both internal and external systems:

 

- **ConnexusComponents.TransactorV7** - a WebAPI 'wrapper' around the Transactor V7 API
- **Carweb** - for searching vehicle details based on a VRM or VIN
- **FastCode** - for searching address details by postcode
- **BottomLine** - for validating bank account details
- **SagePay** - for taking credit and debit card payments directly from the website
- **SanctionsSearch** - for performing sanctions checks such as money laundering and fraud

 

### VWFS Insurance Portal and Loan Car Insurance

 

The VWFS Insurance Portal and Loan Car Insurance websites are the most simple of the VWFS websites managed by Connexus. They still share a similar technology stack but don't require the more complex or involved technologies such as Transactor or Redis. The application architecture is much smaller too:

 

**VWFS Insurance Portal**

 

- **VWFSInsurancePortal** - ASP.NET MVC 5, UmbracoCMS website
- **VWFS** - services and models library mostly containing ViewModels and some 3rd party integrations that are currently out of use

 

**Loan Car Insurance**

 

- **LoanCar** - ASP.NET MVC5, UmbracoCMS website

 

#### Integrations

 

The VWFS Insurance Portal website has occasionally provided integrations with 3rd party APIs for reporting claims. However, none of these integrations are currently active and the website just serves content.