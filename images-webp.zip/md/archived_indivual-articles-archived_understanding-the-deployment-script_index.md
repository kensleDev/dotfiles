[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Understanding the deployment script

 

---

 

## Introduction

 

The deployment process has traditionally been done manually, however a PowerShell script has been created in order to simplify much of the out-of-hours process.

 

There are two files in the **c:\deployments** folder:

 

1. **deploy.ps1** is the PowerShell script itself
2. **brands.txt** is a CSV file used to drive which sites are to be updated in the format: 

- Brand name,IIS name

 

The deployment must be prepared as usual so that the new version is added as a subfolder to the current version's parent, i.e. that the parent contains at least two versions of the site but probably more:

 

- Root folder 

- v1.1
- v1.2
- v1.3 <- This is the prepped deployment we wish to release

 

The script automates the following processes which were previously done manually, and can be done as a single command against all sites listed in the CSV file:

 

1. Updates the Admin site, if one exists, to the version with the latest timestamp in the parent folder
2. Stops and restarts the application pool for the Admin site
3. Updates the front-end site to the version with the latest timestamp in the parent folder
4. If there is an Admin site, sets the **Media** folder in the front-end site to be a virtual directory pointing at the **Media** folder in the Admin site
5. Stops and restarts the application pool for the front-end site

 

The intention had been to also restart each site as per the manual process, but this is not possible with PowerShell on Windows Server 2012 R2, and the UAT and live servers are running this OS. It is possible with Windows Server 2016 onwards, and so the code to do so is commented out in the script, and should be reinstated if these servers are upgraded to a later OS.

 

## How the script works

 

1. The script takes a single parameter, **brand**
2. The webadministration module has to be imported as this is needed for some of the IIS commands
3. The **brands.txt** file is loaded into an array of objects with two properties, **Brand** and **SiteName**
4. If the **brand** parameter = "*all*" then the array is looped over, processing each **SiteName**
5. If the **brand** parameter matches any **Brand** in the array then its corresponding **SiteName** is processed

 

### Processing a site

 

The return value of a PowerShell function is not just anything specified in a **return** statement, but also anything that is output by the function. This goes some way to enforcing the *Single Responsibility Principle*, and most of the functions in the script perform one very specific task for this reason, as the front-end site depends on the Admin site in order for its virtual **Media** directory to work.

 

The process is as follows:

 

1. Get the current site name, i.e. the **SiteName** parameter suffixed with "*-UAT*" if applicable
2. Get the Admin site name, i.e. the **SiteName** parameter suffixed with "*-Admin*" if it exists
3. Get the fully-qualified path name of the front-end site to deploy
4. If there is an Admin site: 

- Get the fully-qualified path name of the Admin site to deploy
- Set the physical path of the Admin site to that of the new version
- Stop and restart the Admin site's application pool
5. Get the fully-qualified path name of the front-end site to deploy
6. Set the physical path of the front-end site to that of the new version
7. If the front-end site has a virtual **Media** directory: 

- Delete the front-end site's virtual **Media** directory
8. Create a virtual **Media** directory on the front-end site, pointing at that of the Admin site
9. Stop and restart the front-end site's application pool
10. Report on the updates made so the developer can cross-reference this with the expected versions

 

### Digital signing

 

The script will throw an error message, "deploy.ps1 is not digitally signed. The script will not execute on the system."

 

To avoid this, the following command must be run in the PowerShell window prior to running the script:

 

```
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

 

### The deploy.ps1 script

 

The complete script is as follows:

 

```
##################################################################################### Prior to running this script, the following needs entering in PowerShell: ## Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass ## otherwise an error is thrown: ## ps1 is not digitally signed. The script will not execute on the system. ########################################################################################################################################################################## Setup brand as a mandatory parameter #####################################################################################param(    [Parameter(Mandatory=$True)] [ValidateNotNull()] [string] $brand)##################################################################################### TODO: ## DFS????? #####################################################################################Import-Module webadministration##################################################################################### Returns the IIS sitename suffixed with -UAT if appropriate ## ie if the server is DEVWEB01 #####################################################################################function addSuffixIfOnUat($iisSiteName){    $hostName = HostName    if ( $hostName.Contains("devweb01") )    {        $iisSiteName = -join($iisSiteName, "-UAT")    }    return $iisSiteName}##################################################################################### Returns the current physical directory of the specified website #####################################################################################function getCurrentPhysicalDirectory($iisSiteName){    # Obtain the website and the fully-qualified name of its physical directory    $iisWebsite = Get-WebFilePath "IIS:\Sites\$iisSiteName"    $iisWebsite.FullName}##################################################################################### Returns the current physical directory of the website to deploy ## This is the latest folder in the parent of the website's current directory #####################################################################################function getPathOfVersionToDeploy($iisSiteName){    $fileName = getCurrentPhysicalDirectory($iisSiteName)    # Get the fully-qualified name of the last modified folder in the physical directory's parent    $parentDirectory = Split-Path $fileName -Parent    $latestFolder = Get-ChildItem $parentDirectory | Where-Object {$_.PSIsContainer -eq $true} | Sort-Object -pro LastWriteTime -Descending | Select -First 1    $latestFolder.FullName}##################################################################################### Returns the specified website name suffixed with -Admin if the admin site exists #####################################################################################function getAdminSiteName($iisSiteName){    $iisSiteName = -join($iisSiteName, "-Admin")    if ( Test-Path "IIS:\Sites\$iisSiteName" )    {        return $iisSiteName    }}##################################################################################### Gets the last modified folder in the parent of the physical directory ## Updates the physical directory of the specified website to the specified folder ## Creates a virtual directory to the admin site's Media folder if one exists ## Stops and restarts the site and Application pool #####################################################################################function updateSite($iisSiteName, $latestFolderName, $adminSiteTargetPath){    # Update the physical path to the last modified folder above    Set-ItemProperty -Path "IIS:\Sites\$iisSiteName" -name "physicalPath" -value $latestFolderName    # If there is an admin site then remove the virtual directory to its Media folder and recreate it at the new location    if ( $adminSiteTargetPath -ne $null )    {        $mediaVirtualDirectory = Get-WebVirtualDirectory -Site $iisSiteName -Name "Media"        if ( $mediaVirtualDirectory -ne $null )        {            Remove-WebVirtualDirectory -Site $iisSiteName -Name "Media" -Application "/"        }        $mediaFolder = -join($adminSiteTargetPath, "\Media")        Write-Output $mediaFolder        $output = New-WebVirtualDirectory -Site $iisSiteName -Name "Media" -PhysicalPath $mediaFolder    }    # Stop and restart the site; this doesn't work on Windows Server 2012 R2 so is currently commented out    #Stop-IISSite -Name $iisSiteName -Confirm:$false    #Start-IISSite -Name $iisSiteName -Confirm:$false    # Obtain the app pool name, stop and restart it    $appPoolName = "IIS:\AppPools\$iisSiteName"    Stop-WebAppPool -Name $appPoolName.split("\")[-1]    Start-WebAppPool -Name $appPoolName.split("\")[-1]}##################################################################################### Call the function to update the website and output the current folder name #####################################################################################function updateSiteAndReport($iisSiteName, $latestFolderName, $adminSiteTargetPath){    updateSite $iisSiteName $latestFolderName $adminSiteTargetPath    $iisWebsite = getCurrentPhysicalDirectory($iisSiteName)    $output = -join($iisSiteName, " has been updated to ", $iisWebsite)    Write-Output $output}##################################################################################### Get the name of the current website and its corresponding admin site ## and the fully-qualified name of the version to deploy in each case ## Update and report on both sites #####################################################################################function processSite($iisSiteName){    $currentSiteName = addSuffixIfOnUat($iisSiteName)    $adminSiteName = getAdminSiteName($iisSiteName)    $frontEndSiteTargetPath = getPathOfVersionToDeploy($currentSiteName)    if ( $adminSiteName -ne $null )    {        $adminSiteTargetPath = getPathOfVersionToDeploy($adminSiteName)        updateSiteAndReport $adminSiteName $adminSiteTargetPath $null    }    updateSiteAndReport $currentSiteName $frontEndSiteTargetPath $adminSiteTargetPath}##################################################################################### ## ENTRY POINT ## ###################################################################################### Store the sites from the brands csv file in an array# The format of the csv file is brand,site name, eg Audi,InsureWithAudi$sites = @()$validSites = ""$siteLookup = Get-Content "c:\temp\brands.txt"foreach ( $siteLookupEntry in $siteLookup ){    $siteLookupEntry = $siteLookupEntry.split(",")    $sites += [pscustomobject]@{Brand=$siteLookupEntry[0];SiteName=$siteLookupEntry[1]}    $validSites += $siteLookupEntry[0] + ", "} if ( $brand -eq "all" ){    # Update each site in the array and its admin site if applicable    foreach ( $site in $sites )    {        processSite($site.SiteName)    }}else{    # Get the sitename for the required brand from the array    foreach ( $site in $sites )    {       if ( $brand -eq $site.Brand )       {           $siteName = $site.SiteName       }    }    # Exit if no match found    if ( $siteName -eq $null )    {        $validSites += "and all"        Write-Output "Invalid parameter. Supported websites are " $validSites        Read-Host -Prompt 'Press a key'        Exit    }    # Update the site and its admin site if applicable    processSite($siteName)}
```

 

## Todo

 

If possible we would like to automate the DFS setup to replicate the Admin sites from PRDWEB03 to PRDWEB04. It is uncertain if this would be possible to do on UAT so may require developing against dummy folders on live.