[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Off Your Bike

 

---

   

## Website Details

  **Live URL:** [https://www.offyourbike.co.uk/](https://www.offyourbike.co.uk/) **UAT URL:** []()      

---

 

Motorcycle claims website

 

| URL | https://www.offyourbike.co.uk/ |
| --- | --- |
| Admin URL | https://cms.offyourbike.co.uk |
| CMS | Cockpit 0.9.3 |
| PHP version | ~7.2 |
| Location | prd-ubuntu-20 |
| Database location | N/A (SQLite hosted with CMS) |