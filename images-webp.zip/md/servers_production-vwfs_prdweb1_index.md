[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# PRDWEB1

 

---

 

## Server Details

  **Server Type:** Web **IP Address:** 192.168.104.178  

---

 

This is the primary **IIS** web server for the following VWFS websites hosted at Connexus and is load-balanced at Rackspace with [PRDWEB2](/servers/production-vwfs/prdweb2/).

 

 

 

 Public: 88.138.172.178 (as per ipchicken.com).

 

---

 

## Websites

 

- Insure with Audi - [https://www.insurewithaudi.co.uk/](https://www.insurewithaudi.co.uk/)
- Insure with Porsche - [https://www.insurewithporsche.co.uk/](https://www.insurewithporsche.co.uk/)
- Insure with SEAT - [https://www.insurewithseat.co.uk/](https://www.insurewithseat.co.uk/)
- Insure with SKODA - [https://www.insurewithskoda.co.uk/](https://www.insurewithskoda.co.uk/)
- Insure with Volkswagen - [https://www.insurewithvolkswagen.co.uk/](https://www.insurewithvolkswagen.co.uk/)
- Insure with VWCV - [https://www.insurewithvwcv.co.uk/](https://www.insurewithvwcv.co.uk/)
- Loan Car Insurance - [https://www.loancarinsurance.com/](https://www.loancarinsurance.com/)
- VWFS Insurance Portal - [https://www.vwfsinsuranceportal.co.uk/](https://www.vwfsinsuranceportal.co.uk/)