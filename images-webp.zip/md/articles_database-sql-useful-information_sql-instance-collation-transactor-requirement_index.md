[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# SQL Instance Collation

 

---

 

Transactor Databases SQL Instances must have a Server collation of SQL_Latin1_General_CP1_CI_AS as per the below screenshot.

 

Should the SQL instance be created with a different collation, this will cause issues within the Transactor software. SQL Instance Collation cannot be changed once created, this would need removing and starting again.

 

![](../images-webp/image_82.webp)

 

 

 

This info comes from Mark Reddy