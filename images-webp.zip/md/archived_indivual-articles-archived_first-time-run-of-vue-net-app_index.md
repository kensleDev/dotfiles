[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# First time run of Vue/.net app

 

---

 

The first time a solution is pulled from source ( For example, i just pulled down a branch of Velosure) The node packages must be installed. 

 

In Nuget package console, navigate to the vue 'src' folder (using cd.. etc)

 

Enter >npm build

 

Any missing packages reported here ( i was warned about Jquery 1.9.1 being required) add now, for example

 

 

 

# npm WARN bootstrap@4.2.1 requires a peer of jquery@1.9.1 - 3 but none is installed

 

 

 

Install as follows

 

```
npm i jquery@1.9.1 --save
```