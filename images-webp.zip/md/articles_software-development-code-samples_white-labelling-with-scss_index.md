[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# White Labelling with SCSS

 

---

 

The Proclaim Report Viewer had a requirement to be white-labelled with the following caveats:

 

- The preferred option was to be able to have a single deployment that would load the correct brand based on the URL
- Only the required brand should be loaded

 

This was achieved by making the site.scss a partial and creating an SCSS file per brand which defines the variables and imports the partial. The problem with this approach was that the _site.scss needs to have the variables defined, and if they are defined in here, as per this implementation, defined in another partial which is imported, then the values set here would overwrite those in the brand.

 

The solution was to use the SASS !default flag; the variables are set to their branded values at the highest level, and the defaults are only used if they are not previously defined. This also means that the branding files don't need to redefine any variables where the value is the same as the default.

 

The following are defined in the branding file:

 

- Colours
- Font families including imports if necessary
- Logo path and height; this is used to add padding and determine the banner and screen heights
- Background image path
- Border radius
- Border radius, style, colour and width for input boxes; these are passed to a parameterised mixin
- jQuery validate styling

 

For example the _variable-definitions.sccs defines the following variables for the primary button colours:

 

```
$color-button-text: #fdc300 !default;
$color-button-primary-background: black !default;
$color-button-primary-hover-background: #084c61 !default;
```

 

In the CMA brand these are overridden:

 

```
$color-button-text: $color-white;
$color-button-primary-background: $color-cma-aqua;
$color-button-primary-hover-background: $color-cma-aqua-dark;
```

 

Which uses colour definition variables set up at the top of the CMA brand SCSS:

 

```
$color-cma-aqua: #1ba4aa;
$color-cma-aqua-dark: #09878c;/* Some more colours here */
$color-white: #ffffff;
```

 

The branded SCSS files all import _site.scss:

 

```
@import "Content/Css/site.scss";
```

 

Which in turn imports the default variable definitions:

 

```
@import "variable-definitions";
```

 

and styles the primary button as follows:

 

```
/* override default bootstrap button styling */
.btn {
    border: none;
    border-radius: $border-radius;
    font-family: $font-family-buttons;
 
    /* remove button outlines on hover, focus and active states */
    &:hover, &:focus, &:active {
        outline: none !important;
        box-shadow: none !important;
    }
}
/* override default bootstrap 'primary' button styling */
.btn-primary {
    background-color: $color-button-primary-background;
    color: $color-button-text;
 
    &:hover, &:focus, &:active {
        background-color: $color-button-primary-hover-background !important;
        color: $color-button-text !important;
    }
 
    .disabled, &:disabled {
        background-color: lightgray !important;
        opacity: 0.5;
 
        &:hover, &:focus, &:active {
            background-color: lightgray !important;
            opacity: 0.5;
        }
    }
}
```

 

A bundle is created for each brand, and the bundle name for the brands is held in ConnexusConfig keyed by URL. All controllers derive from BaseController which has OnActionExecuting overridden to obtain the brand from the BrandService. The bundle name is stored in the ViewBag and the Layout views render the required bundle.