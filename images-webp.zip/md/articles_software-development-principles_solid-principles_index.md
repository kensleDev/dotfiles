[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# SOLID Principles

 

---

 

Connexus developers should be familiar with the kinds of programming principles that help us develop clean, maintainable code.

 

One such set of principles is an acronym called SOLID.

 

- **S** single responsibility principle
- **O** open-closed principle
- **L** Liskov substitution principle
- **I** interface segregation principle
- **D** dependency inversion principle (dependency injection, IOC, etc)

 

For a full explanation using C# code examples, [see here](http://www.codeproject.com/Articles/703634/SOLID-architecture-principles-using-simple-Csharp).