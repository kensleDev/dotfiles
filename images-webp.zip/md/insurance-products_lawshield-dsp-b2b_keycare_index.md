[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Keycare

 

---

 

Keycare provides annual cover up to £1,500 towards the replacement of keys, locks and call-out charges. Keycare will enhance and add value to the main motor or household insurance policy.

 

## Product Details

  **Product Reference:** KEYCARE **Product Type Id:** 425  

---

 

## Schemes

 

- [Keycare](/insurance-products/lawshield-dsp-b2b/keycare/keycare/)

 

---