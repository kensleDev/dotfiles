[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Lawshield Digital Sales Platform (DSP)

 

---

   

## Website Details

  **Live URL:** [https://dsp.lawshield.co.uk/](https://dsp.lawshield.co.uk/) **UAT URL:** [https://dsp.connexus-test.co.uk/](https://dsp.connexus-test.co.uk/)    .NET Framework VB.NET ASP.NET Web Forms HTML CSS Bootstrap JavaScript jQuery Entity Framework 6   

---

 

The Lawshield Digital Sales Platform (DSP) is a web application that provides the ability for insurance brokers to sell Lawshield's ancillary product set alongside their own mainstream insurance products. These ancillary products include:

 

- Legal Protection for: 

- Motor
- Family
- Equestrian
- Park Homes and Static Caravans
- Home Emergency
- Keycare
- Excess Waiver
- Breakdown Cover
- Landlord Protection for: 

- Home Emergency
- Legal Expenses
- Rent Guarantee

 

DSP can only be accessed via a login provided to individual users at brokers who have business agreements with Lawshield for the sale of these ancillary products.

 

## Integrations

 

The DSP web application is integrated heavily with **OpenGI****Tranasctor v6**, hosted internally at Connexus which is used for quoting and inception of ancillary insurance policies. Transactor is also responsible for the user accounts and product/scheme permissions in DSP to ensure only brokers with written agreement to do so have the ability to sell particular products via DSP when they log in.

 

## Further Reading

 

Further details about technologies, architecture and insurance products can be found in other areas of the Knowledgebase. Some important areas are:

 

- [DSP - Architecture](/archived/indivual-articles-archived/dsp/dsp-architecture/)
- [Lawshield DSP (B2B) Insurance Products](/insurance-products/)