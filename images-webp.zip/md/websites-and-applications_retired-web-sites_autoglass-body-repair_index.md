[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Autoglass Body Repair

 

---

   

## Website Details

  **Live URL:** [https://autoglassbodyrepair.lawshield.co.uk/](https://autoglassbodyrepair.lawshield.co.uk/) **UAT URL:** []()    .NET Framework C# ASP.NET MVC Entity Framework 6 HTML CSS Bootstrap JavaScript jQuery AngularJS   

---

 

This is a now-defunct website for Autoglass Body Repair