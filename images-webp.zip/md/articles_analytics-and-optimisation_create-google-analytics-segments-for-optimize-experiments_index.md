[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Create Google Analytics segments for Optimize experiments

 

---

 

## Introduction

 

A **segment** is a subset of GA data. Segments could for example be used to only report on users from a certain location, or those using a certain device, but how we are going to use them is to compare the control with a variant in Google Optimize.

 

This then enables a GA report, e.g. Conversions -> Goals -> Overviews, to compare data gathered from the control and variant. Note that unfortunately the Funnel Visualisation does not support segments.

 

In order to do so, within the report:

 

1. Click on **Add Segment** at the top of the Overview panel
2. Uncheck **All Users**
3. Check the **control** and **variant** segments in that order
4. Click **Apply**

 

This will then show two sets of data alongside each other so the control and variant can be compared.

 

## Setting up GA Segments from within Google Optimize

 

1. Click on the required Container within the required Account
2. Click on the Experiment in the Running panel, note that the Experiment must be running
3. Click on the **Details** tab
4. Click on the ellipsis next to the **Original** in the Targeting and variants -> Manage variants panel
5. Select Create Segment in Analytics
6. This loads Google Analytics
7. Change the suffix of the name from Original to **Control**
8. **Save**
9. Back in Optimize, click on the ellipsis next to the **Variant** in the Targeting and variants -> Manage variants panel
10. Select Create Segment in Analytics
11. This loads Google Analytics
12. **Save**