[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Family Select Legal Cover F&L

    **Underwriter:** Financial & Legal Insurance Company Limited **Net Premium:** £2.29     **UAT Scheme Table Id:** 1559 **UAT Scheme File Name:** 43I6V0A9.wpd  

---

  **Live Scheme Table Id:** 1520 **Live Scheme File Name:** 43ISB7A9.wpd    

---

 

## Product

 

- [Family Select Legal Expenses](/insurance-products/lawshield-dsp-b2b/family-select-legal-expenses/)

 

---

 

## Scheme Description

 

No rating logic required for the Family Select scheme. There is simply a DateDiff operation ensuring that policy start dates are on or after 1st January 2021 (when the scheme started).

 

---