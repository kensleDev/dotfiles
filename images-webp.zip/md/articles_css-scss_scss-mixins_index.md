[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# SCSS Mixins

 

---

 

Mixins allow blocks of CSS rules to be re-used 

 

For example: 

 

*@mixin example-mixin {*

 

*padding:10px;*

 

*margin:15px;*

 

*background-color: green;*

 

*color: red;*

 

*}*

 

  

 

To use this mixin is as simple as: 

 

*h1 {*

 

*@include example-mixin;*

 

*}*

 

  

 

This will apply the 4 rules to the h1 selector. 

 

Mixins can be use with or without parameters 

 

The example above did not include any parameters. The following uses a $size parameter: 

 

  

 

*@mixin font-size($size) {*

 

*font-size: $size;*

 

*}*

 

  

 

Used as follows 

 

  

 

*h1 {*

 

*@include example-mixin(2em);*

 

*}*

 

  

 

Mixin parameters can be optional 

 

In the following example, $size is required, but $radius is optional as a default value has been included.  

 

 *@mixin square($size, $radius: 0) {*

 

*width: $size;*

 

*height: $size;*

 

*@if $radius != 0 {*

 

*border-radius: $radius;*

 

*}*

 

*}*

 

  

 

Mixin parameters can be named or positional 

 

Consider the following mixin that provides a positioning helper: 

 

*@mixin position($type,$top:null,$left:null) {*

 

*position: $type;*

 

*top: $top;*

 

*left: $left;*

 

*}*

 

  

 

This can be called with named parameters: 

 

*.heroImage {*

 

*@include position($type:absolute, $top:20px, $left: 15px)*

 

*}*

 

 

 

Or with the parameters passed in the required order: 

 

*.heroImage {*

 

*@include position(absolute, 20px, 15px)*

 

*}*

 

Or a mixture: 

 

*.heroImage {*

 

*@include position(absolute, $top:20px, $left: 15px)*

 

*}*

 

Mixin parameters can be a list 

 

Note the ellipses on the $selectors parameter. This allows any number of extra parameters to be included. 

 

The selectors are then iterated over and the given rules applied 

 

 

 

*@mixin order($height, $selectors...) {*

 

*@for $i from 0 to length($selectors) {*

 

*#{nth($selectors, $i + 1)} {*

 

*position: absolute;*

 

*height: $height;*

 

*margin-top: $i * $height;*

 

*}*

 

*}*

 

*}*

 

 

 

In use 

 

 *@include**order(150px, "input.name", "input.address", "input.zip");*

 

  

 

When transpiled, the following CSS is rendered: 

 

  

 

*input.name {*

 

*position: absolute;*

 

*height: 150px;*

 

*margin-top: 0px;*

 

*}*

 

***input.address {*

 

*position: absolute;*

 

*height: 150px;*

 

*margin-top: 150px;*

 

*}*

 

***input.zip {*

 

*position: absolute;*

 

*height: 150px;*

 

*margin-top: 300px;*

 

*}*

 

**Worked Example**

 

Within the ConnexusCdn project a mixin is used to create the checkerboard effect on the image cards.  

 

 

 

*@mixin checkers($size: 20px, $contrast: 0.47) {*

 

*$check-color: rgba(#000, $contrast);*

 

*$angle: 45deg;*

 

*$transparency: 25%;*

 

  *background-image: linear-gradient($angle, $check-color $transparency, transparent $transparency), linear-gradient(-$angle, $check-color $transparency, transparent $transparency), linear-gradient($angle, transparent 3 * $transparency, $check-color 3 * $transparency), linear-gradient(-$angle, transparent 3 * $transparency, $check-color 3 * $transparency);*

 

*background-size: $size $size;*

 

*background-position: 0 0, 0 $size/2, $size/2 -1 * $size/2, -1 * $size/20;*

 

*}*

 

  

 

Called in stylesheet as follows: 
  

 

 *.flip-card-front {***

 

*@include checkers(10px,0.27);*

 

*}*

 

But could also be called without params. In this case the default values will be applied, i.e. 

 

*.flip-card-front {*

 

*@include checkers;*

 

*}*

 

For this particular mixin, the use of parameters could be helpful within media queries. On a small screen, you may want the check pattern to be larger and smaller for larger screens.