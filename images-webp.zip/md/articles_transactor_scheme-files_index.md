[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme Files

 

---

 

The Transactor scheme file language is a scripting language that exists to define underwriting criteria in code. The underwriting criteria defines the premium and whether or not the risk is an acceptable risk or should be referred or declined.

 

## Basic Example

 

Park Homes and Static Caravans is a simple scheme that has no decline or referral criteria and a single price without any options:

 

**Park Homes and Static Caravans**

 

```
{Header}Header
{SchemeName}Park Homes and Static Caravans Legal Protection
{Underwriter}Inter Partner Assistance SA (IPA)  which is fully owned by the AXA Assistance Group
{End Header}End Header
{Remark}Park Homes and Static Caravans Legal Protection
{Remark}***************************** - Default Output Variables Start - ***********************
{Equation}Equation
{TypeOutput}NetPremium%
{Operator=}=
{TypeConstant}2.75
{End Equation}End Equation

{Equation}Equation
{TypeOutput}GrossPremium%
{Operator=}=
{TypeConstant}0
{End Equation}End Equation

{Equation}Equation
{TypeOutput}IPT%
{Operator=}=
{TypeConstant}0
{End Equation}End Equation

{Remark}***************************** - Default Output Variables End - ***********************

{Remark}********** lawshield commisson
{Equation}Equation
	{TypeOutput}PARTNERCOMMPERCENT%
	{Operator=}=
	{TypeConstant}0
{End Equation}End Equation

{Remark}***************** default subagent commission - 0
{Equation}Equation
	{TypeOutput}SUBAGENTCOMMPERCENT%
	{Operator=}=
	{TypeConstant}0
{End Equation}End Equation

{End Product}End Product
```

 

The first four lines are standard in any scheme file and are always wrapped in a {header}.

 

- **SchemeName** is the name of the Line of Business (LOB) and will be provided in the output when a quote is retrieved.
- **Underwriter** is the name of the insurer from the SYSTEM_INSURER database table.

 

Both of these parameters are set when the scheme is created.

 

What follows are the generic **outputs** that Transactor needs in order to calculate the premium. These are defined as **Equations** with a default *constant* value.

 

Next are any additional **outputs** that are used to define further details such as agent and subagent *commissions*, as in this example. Again these are defined as **Equations**.

 

Finally, there is the {End Product} which tells Transactor that it has reached the end of the scheme file.

 

## Scheme File Details

 

### Operators

 

Scheme files can use a number of operators within **Equations** to create or update values stored in **Outputs** or **Workfields** (see below):

 

```
// Equals operator
{Operator=}=

// Not Equal
{Operator<>}<>

// Plus operator
{Operator+}+

// Minus operator
{Operator-}-

// Division operator
{Operator/}/

// Multiplier
{Operator*}*

// Greater than
{Operator>}>

// Greater than or equal to
{Operator>=}>=

// Less than
{Operator<}<

// Less than or equal to
{Operator<=}<=
```

 

### Types

 

Scheme files can define **Outputs** and **Workfields** as several data types including *string*, *constant* and *boolean*:

 

```
// A string
{TypeString}Hello World

// Constants (Numerics)
{TypeConstant}0

// Boolean
{TypeBoolean}True
{TypeBoolean}False
```

 

### Workfields

 

A **Workfield** defines a *variable* that can be used during processing in a scheme file. In order to hint at the type of data stored in the **Workfield**, you must use one of the following symbols after the variable name declaration:

 

```
// String - $
{TypeWorkfield}MyString$

// Number - %
{TypeWorkfield}MyNumber%

// Boolean - ?
{TypeWorkfield}MyBoolean?

// Date - ^
{TypeWorkfield}MyDate^

// Currency - @
{TypeWorkfield}MyCurrency@
```

 

### Outputs

 

As discussed earlier, Transactor is built to expect certain **Outputs** from a scheme file. These are similar to a **Workfield** in that you declare an output and use a symbol to denote the data type:

 

```
{TypeOutput}MyStringOutput$
```

 

### Equations

 

**Equations** are used for multiple purposes:

 

- Defining **Outputs** and **Workfields**
- Updating **Outputs** and **Workfields**
- Collecting risk data from Transactor database tables

 

They usually take the form of:

 

- **Output** or **Workfield** name
- **Operator** and
- **Value**

 

In the example below, we establish a new *numeric* **Workfield** called "MyWorkfield" and set its value to 0:

 

```
// Here we will set the value of MyWorkfield which is of type number to the value 0
{Equation}Equation
    {TypeWorkfield}MyWorkfield%
    {Operator=}=
    {TypeConstant}0
{End Equation}End Equation
```

 

### If Conditionals

 

Boolean logic is defined by outlining the {Truth} condition, or the condition under which we should continue with the logic defined within the If operation until we reach the {End If} statement. Again this can use **Outputs** or **Workfields** along with **Operators** to determine the "Truth", which is then immediately followed by the logic to execute under truthy conditions:

 

```
{If}If
	{Truth}Truth
	    {TypeWorkfield}MyWorkfield%
	    {Operator=}=
	    {TypeConstant}0
	{End Truth}End Truth
	// Your business logic to execute under 'truthy' conditions
{End If}End If
```

 

If statements can be nested if you need to determine the truth via multiple conditions. However, there are no "else" statements; you will need to reverse the truth logic in another if statement to implement an else condition.

 

### For Loops

 

Loops can be defined to iterate over certain risk data, such as the *Client* or *Policy Details*. These are simply denoted with a {For Each} statement which is closed by an associated {End For} statement. All of the business logic contained within will be executed for each iteration of the loop:

 

```
{For Each}Client
    {For Each}Policy_Details
		// Your business logic to be executed for each iteration of the loop
		// which in this case is for each Policy of each Client
    {End For}End For
{End For}End For
```

 

As shown above, for loops can be nested if you need to iterate over child elements.

 

### Date Comparison

 

Comparing strings, numbers and booleans can be done with basic If conditions as shown above. However, comparing dates requires the use of a specific comparison operation known as {DateDiff}.

 

Before using the DateDiff operation, you may need to have the dates you want to compare defined in two date **Workfields** using the ^ type indicator.

 

The DateDiff operation works by returning the difference between the two dates. This is based on a third parameter indicating the granularity at the *day*, *month* or *year* level using "d", "m", or "yyyy" respectively. The result is defined as a **Workfield** of type number (%) using the equals **Operator**.

 

The order in which you provide your two dates will determine in which way they are compared, and thus the sign of the output (+/-). You can then use an **If** operation to determine if the difference between the two dates satisfies any conditions you may wish to apply.

 

A full example of the use of the date comparison logic is shown below:

 

```
{Equation}Equation
	{TypeWorkfield}TEMP_DATE^
	{Operator=}=
	{TypeString}01/07/2018
{End Equation}End Equation

{DateDiff}DateDiff
	{TypeWorkfield}Difference%
	{Operator=}=
	{TypeWorkfield}TEMP_DATE^
	{TypeQuestion}Client.Policy_Details.Policy_Start_Date
	{TypeString}d
	{TypeBoolean}true
{End DateDiff}End DateDiff

{If}If
	{Truth}Truth
	    {TypeWorkfield}Difference%
	    {Operator>}>
	    {TypeConstant}0
	{End Truth}End Truth
	// Your business logic to execute under 'truthy' conditions
{End If}End If
```

 

## Getting Risk Data

 

It is necessary to use the **For Loop** statement to loop through the *Client*, *Policy Details* or custom *Screen* to be able to access the risk data for the policy being quoted.

 

To retrieve data held in the *Client* you must be looping through the Client. To retrieve data held in the *Policy Details* you must be looping through the Client *and* Policy Details. To retrieve data held in a custom *Screen* (USER_ table) you must be looping through the Client, the Policy Details *and* the Screen:

 

```
{For Each}Client
    {For Each}Policy_Details
                {Remark} Read from the Policy Start Date
		{TypeWorkfield}TEMP_DATE^
                {Operator=}=
		{TypeQuestion}Client.Policy_Details.Policy_Start_Date

                {Remark} Read from the Subagent Id in the Motor Elite Extra Screen
                {For Each}UO_MOTOREX_SCREEN01
                     {TypeWorkfield}SubagentId%
                     {Operator=}=
                     {TypeQuestion}Client.Policy_Details.UO_MOTOREX_SCREEN01.UQ_MOTOREX_SCREEN01_SUBAGENT_ID
                {End For}End For
    {End For}End For
{End For}End For
```

 

## Rating Tables

 

Rating tables are SQL database tables that are used in administrating more complex rating criteria, such as those seen for Extended Warranty where the rating is dependant on a range of different factors. They avoid the need for heavy nesting of **If** and **For Loops** within the scheme file itself by allowing you to write a structured *query* based on data held in **Outputs** or **Workfields**.

 

Queries to rating tables start with the {ApplyTable} and end with the {End Table} statement. This should be immediately followed by the {TableNoInputs} statement defining the number of parameters to be supplied, and the {TableName} statement, obviously defining the name of the rating table to query:

 

```
{ApplyTable}Table
    {TableNoInputs}9
    {TableName}RATE_MY_RATE
    // further query logic goes here
{End Table}End Table
```

 

Following the {TableName} statement, you can define the parameters you want to supply to the query as {TableInput} statements. These are similar to the **Equation** syntax; defining the name of the input and using an **Operator** with a hard-coded value, or an **Output** or **Workfield**:

 

```
{Remark} Subscription type
{TableInput}SUBSCRIPTION_TYPE_ID
{Operator=}=
{TypeWorkfield}SUBSCRIPTION_TYPE_ID$
```

 

Finally, you can define the number of outputs and the column names of those outputs to be selected by the query using the {TableNoOutputs} and {TableOutput} statements. A table output must define the **Type** of output using the relevant symbol (see above):

 

```
{TableNoOutputs}8
{TableOutput}PREMIUM%
{TableOutput}TPA_FEE_OPTEVEN%
{TableOutput}TPA_FEE_CONNEXUS%
{TableOutput}VWFS_UK_COMM%
{TableOutput}VW_VERS_ADMIN%
{TableOutput}FULFILLMENT_FEE%
{TableOutput}LIBTECH_ID$
{TableOutput}LIBTECH_VERSION$
```

 

It is common in most scheme files at Connexus for the table outputs to be written to **Workfields** after the query in order that all subsequent logic is working with a common syntax.

 

## Decline and Referral

 

Scheme files can use the {Decline} and {Refer} statements in order to have a scheme file *decline* or *refer* instead of providing a premium. Note that it is important to distinguish the two:

 

- **Decline** will decline to quote completely and not provide a premium
- **Refer** can result in a premium being returned, but with referral conditions

 

```
// Decline
{Decline}Decline
	{TypeString}Unacceptable Risk
{End Decline}End Decline

// Refer
{Refer}Refer
	{TypeString}Refer to Insurer
{End Refer}End refer
```

 

## Premium Breakdown

 

The premium breakdown, visible in TCAS from the *Policy Summary* screen, allows us to represent the constituent parts that make up the Gross premium the customer will pay. For example, there may be agent or subagent commissions, specific loading factors (e.g. age or postcode-based) or discounts applied etc.

 

An entry in the premium breakdown is defined with the {Narrative}Breakdown statement:

 

```
{Narrative}Breakdown
	{TypeString}My message :::
	{Operator&}&
	{TypeOutput}MyOutput%
{End Narrative}End Narrative
```

 

The syntax here can be a little difficult to understand. It relates to the four *columns* displayed on-screen in the premium breakdown dialog and separation of the data that appears in each column is driven by the use of the colon ":" symbol. In the example above, we're adding a hard-coded message to the first column ("My message"), nothing in the second or third columns, and an output to the final column ("MyOutput%").

 

For more complex scenarios the narrative requires the use of multiple {TypeString}, {Operator&}& and hard-coded values, **Outputs** or **Workfields** to present data across all four columns, remembering that the colon ":" denotes the column separator.

 

In the following example, we are outputting underwriter discount details. The four pieces of information are:

 

- Text representing the discount applied
- The percentage discount
- The monetary discount amount
- The new "base premium" following the discount

 

```
{Narrative}Breakdown
    {TypeWorkfield}SALE_UW_BREAKDOWNTEXT$
    {Operator&}&
    {TypeString}:
    {Operator&}&
    {TypeWorkfield}SALE_UW_SHOWPERCENTTEXT$
    {Operator&}&
    {TypeString}:
    {Operator&}&
    {TypeWorkfield}SALE_UW_SHOWVALUETEXT$
    {Operator&}&
    {TypeString}:
    {Operator&}&
    {TypeWorkfield}BASE_PREMIUM%
{End Narrative}End Narrative
```

 

## Creating and Updating Scheme Files

 

The *correct* way to create or update a Transactor scheme file is through the **TES Product Modeller** tool, which is accessible via the **TES Tool Suite** under *Product Modelling*. This tool creates syntactically correct code and correctly references risk data fields from wizards for the various features shown above.

 

Additionally, this tool then allows you to correctly promote your new or updated scheme file into Transactor for use against a scheme defined in the Relationship Manager.

 

However, it is feasible to make small amendments or fixes to scheme files directly in the files themselves. They are typically located on the relevant Transactor application server at *D:\TCAS\Schemefiles*. Be warned; updates saved to these files are **effective immediately**.

 

## DSP Motor Elite Extra Scheme File

 

As an example; the complete Motor Elite (UKG) scheme file for DSP is represented below:

 

```
{Header}Header
{SchemeName}Motor Elite Extra
{Underwriter}UK General Insurance on behalf of Ageas Insurance Ltd
{End Header}End Header

{Remark}***************************** - Default Output Variables Start - ***********************
{Remark}*************************** NetPremium% is defaulted to hatchback ***********************
{Equation}Equation
{TypeOutput}NetPremium%
{Operator=}=
{TypeConstant}0.55
{End Equation}End Equation

{Equation}Equation
{TypeOutput}GrossPremium%
{Operator=}=
{TypeConstant}0
{End Equation}End Equation

{Equation}Equation
{TypeOutput}BASE_PREMIUM%
{Operator=}=
{TypeConstant}0
{End Equation}End Equation

{Equation}Equation
{TypeOutput}IPT%
{Operator=}=
{TypeConstant}0
{End Equation}End Equation

{Remark}***************************** - Default Output Variables End - ***********************

{Remark}**************************************************************************************
{Remark}WORKFIELDS
{Remark}*************************************************************************************

{Equation}Equation
{TypeOutput}LAW_COMMISSION$
{Operator=}=
{TypeConstant}0
{End Equation}End Equation

{Equation}Equation
{TypeOutput}BROKER_COMMISSION$
{Operator=}=
{TypeConstant}0
{End Equation}End Equation

{Equation}Equation
{TypeOutput}HIREVEHICLEID%
{Operator=}=
{TypeConstant}2
{End Equation}End Equation

{Remark}*********This is the commission*******

{Remark}*********This is sub agents commission*******
{Equation}Equation
{TypeOutput}SUBAGENTCOMMPERCENT%
{Operator=}=
{TypeConstant}0
{End Equation}End Equation

{Equation}Equation
{TypeOutput}PARTNERCOMMPERCENT%
{Operator=}=
{TypeConstant}0
{End Equation}End Equation

{Equation}Equation
{TypeWorkfield}HIREVEHICLE%
{Operator=}=
{TypeConstant}1
{End Equation}End Equation

{Narrative}Breakdown
	{TypeString}Buy In rate :::
	{Operator&}&
	{TypeOutput}NetPremium%
{End Narrative}End Narrative

{Narrative}Breakdown
	{TypeString}Lawshield Commisssion :::
	{Operator&}&
	{TypeOutput}PARTNERCOMMPERCENT%
{End Narrative}End Narrative

{Narrative}Breakdown
	{TypeString}Subagent Commisssion :::
	{Operator&}&
	{TypeOutput}SUBAGENTCOMMPERCENT%
{End Narrative}End Narrative

{For Each}Client
	{For Each}Policy_Details

		{Remark}**************************************
		{Remark}Decline Policy if this scheme has expired
		{Remark}**************************************
		{Equation}Equation
			{TypeWorkfield}TEMP_DATE^
			{Operator=}=
			{TypeString}01/07/2018
		{End Equation}End Equation
	
		{DateDiff}DateDiff
			{TypeWorkfield}CURRENT_DAY%
			{Operator=}=
			{TypeWorkfield}TEMP_DATE^
			{TypeQuestion}Client.Policy_Details.Policy_Start_Date
			{TypeString}d
			{TypeBoolean}true
		{End DateDiff}End DateDiff
		
		{If}If
			{Truth}Truth
			{TypeWorkfield}CURRENT_DAY%
			{Operator>=}>=
			{TypeConstant}0
			{End Truth}End Truth
				{Decline}Decline
					{TypeString}This scheme is no longer available for policies starting on or after 01/07/2018
				{End Decline}End Decline
		{End If}End If
		
		{For Each}UO_MOTOREX_SCREEN01			
			{If}If
				{Truth}Truth
					{TypeQuestion}Client.Policy_Details.UO_MOTOREX_SCREEN01.UQ_MOTOREX_SCREEN01_subagent
					{Operator=}=
					{TypeConstant}15
				{End Truth}End Truth
				{Decline}Decline
					{TypeString}This scheme is not available for Antur
				{End Decline}End Decline
			{End If}End If
			
			{Remark}**************************************
			{Remark}Quick Quote functionality
			{Remark}**************************************			
			{Equation}Equation
				{TypeWorkfield}HIREVEHICLE_ID%
				{Operator=}=
				{TypeQuestion}Client.Policy_Details.UO_MOTOREX_SCREEN01.UQ_MOTOREX_SCREEN01_HIREVEHICLE
			{End Equation}End Equation
			
			{If}If
				{Truth}Truth
					{TypeWorkfield}HIREVEHICLE_ID%
					{Operator<>}<>
					{TypeConstant}0
				{End Truth}End Truth
				
				{If}If
					{Truth}Truth
						{TypeWorkfield}HIREVEHICLE_ID%
						{Operator<>}<>
						{TypeConstant}2
					{End Truth}End Truth
					{Decline}Decline
						{TypeString}This scheme is only available for Hatchback Hire Vehicles
					{End Decline}End Decline
				{End If}End If
			{End If}End If
		{End For}End For		
	{End For}End For
{End For}End For
{End Product}End Product
```