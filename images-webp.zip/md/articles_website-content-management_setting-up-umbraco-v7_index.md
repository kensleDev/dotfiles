[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Setting up Umbraco V7

 

---

 

## Getting started

 Create a new database in SSMS endsuring that the user has permission to create tables and stored procedures  In Visual Studio, create a new ASP.Net Web Application (.Net Framework) Select Empty and ensure all checkboxes to create folders and core references are unchecked  Install the Umbraco CMS back office along with all its dependencies into the UI project: 

```
Install-Package UmbracoCms -Version 7.15.6
```

  If the Umbraco API is required in a separate project then it needs installing in that project: 

```
Install-Package UmbracoCms.Core -Version 7.15.6
```

  Run the project and enter your name, email address and password when prompted Select Customize Select Database type = Microsoft SQL Server Enter the server, database name and login credentials  This will setup the database and open the Umbraco back office page At this point running the solution will show the Umbraco holding page     

## Output DLLs

 By default Umbraco is configured to generate DLLs on the fly, this should be changed to physically output the DLL: In the web.config, change the following value to LiveDll:  

```
<add key="Umbraco.ModelsBuilder.ModelsMode" value="PureLive" />
```

       

## Language Configuration

  In the Settings tab: 

- Click the ellipsis next to Languages and select Create
- Choose English (United Kingdom) [en-gb]
- Click the ellipsis next to Languages -> English (United States) and Delete

  

## Setup TinyMCE Stylesheet

  In the Settings tab: 

- Click the ellipsis next to Stylesheets and select Create
- Enter TinyMce for the name and click Create

  

## Setting up some Content

  

### Create an Image Composition Media Type

  In the Settings tab:  

- Expand Media Types and delete the default media types; these are composition types
- Click the ellipsis against Media Types and create a new Folder; enter Compositions as the folder name
- Click the ellipsis against Media Types -> Compositions and create a New Media Type; enter Image as the name
- Click Add new tab and enter Image Properties as the name
- Add properties: 

- Click Add property and enter: 

- Name = umbracoWidth; this creates an alias which is the actual name used in the C# code
- Description (optional) = The width of the image
- Click Add editor and in the modal: 

- Select the Reuse tab (otherwise a new editor is created for each use)
- Select Label
- (can choose whether the field is mandatory and enter validation but not here)
- Submit
- Click Add property and enter: 

- Name = umbracoHeight
- Description (optional) = The height of the image
- Click Add editor and in the modal: 

- Select the Reuse tab
- Select Label
- Submit
- Click Add property and enter: 

- Name = umbracoBytes
- Description (optional) = The size of the image file
- Click Add editor and in the modal: 

- Select the Reuse tab
- Select Label
- Submit
- Click Add property and enter: 

- Name = umbracoExtension
- Description (optional) = The type of image file
- Click Add editor and in the modal: 

- Select the Reuse tab
- Select Label
- Submit
- Relabel the properties Width, Height, File Size and File Type respectively; the existing text can just be overwritten. These labels are used in the back office
- Click the Reorder hyperlink in the top right (otherwise inherited tabs will come first in subclasses) and: 

- Enter 10 in the numeric selector next to the tab
- Click the I am done reordering hyperlink
- Click Save

  

## Create a Folder Composition

 This is optional in Umbraco but is something we do as it restricts the types of image that can be allowed in a folder   In the Settings tab:   

- Click the ellipsis against Media Types -> Compositions and create a New Media Type; enter Folder as the name
- Click the image and change to icon-folder-open black
- Click Add new tab and enter Contents as the name
- Click Add property and enter:
 

- Name = Contents
- Click Add editor and in the modal: 

- Select the Reuse tab
- Select List View - Media
- Submit
- Save

   

## Add LinkPicker and Archetype

 Install UmbracoLinkPicker and Archetype via Nuget In the Developer tab: 

- Click the ellipsis against Data Types and select New Data Type
- Name = Link Picker
- Select Link Picker from the Property editor dropdown
- Save

 Should also be in Packages -> Installed but isn't!!!   

## Create a Banner Image Media Type

 In the Settings tab:  

- Click the ellipsis against Media Types and create a New Media Type; enter Banner Image as the name
- Click the image and change to icon-picture green
- Click Add new tab and: 

- Enter Banner Image as the name
- Select the Compositions hyperlink in the top right
- Check Image
- Submit
- Click Add property and enter: 

- Name = umbracoFile
- Click Add editor and in the modal: 

- Select the Available Editors tab
- Select Image Cropper and in the dialog: 

- Change name to Banner Image - Image Cropper
- Click Add New Crop and enter: 

- Alias = Desktop
- Width = 1110
- Height = 500
- Save Crop, Cancel, Submit
- Check Field is mandatory
- Submit
- Click Add another tab and:
 

- Enter Caption as the name
- Add properties: 

- Click Add property and enter: 

- Name = captionTitle;
- Click Add editor and in the modal:
- - Select the Reuse tab
- Select Ricktext editror
- Check Field is mandatory
- Submit
- (should also have Caption Icon but can't do yet as not defined)
- Click Add property and enter: 

- Name = captionAdditionalText
- Click Add editor and in the modal:
 

- Select the Reuse tab
- Select Textstring
- Submit
- Click Add property and enter: 

- Name = Calls To Action
- Click Add editor and in the modal:
 

- Select the Available Editors tab
- Select Archetype and in the modal:
 

- Name = Archetype - Call to Action
- Label = Call To Action
- Alias = callToAction
- Enter properties: 

- Label = Call to Action Link
- DataType = Link Picker
- Uncheck Required
- Click + to add another property: 

- Label = Call to Action Button Text
- DataType = Textstring
- Check Required
- Click + to add another property:
 

- Label = Call to Action New Window
- DataType = True/false
- Uncheck Required
- Submit
- *The following property needs setting up in IE; a bug in Chrome and Firefox duplicates the hash sign*
- Click Add property and enter: 

- Name = Caption Colour
- Click Add editor and in the modal:
- - Select the Available Editors tab
- Select Color Picker
- Name = Caption - Colour Picker
- Check Include Labels 

- Click on the Color dropdown and replace the colour with #00afac
- Enter Aqua as the label
- Repeat the above two steps for all brand colours
- Submit

 Click Add property and enter: 

- Name = Caption Position
- Click Add editor and in the modal:
- - Select the Available Editors tab
- Select Radio button list
- Name = Caption Position - Radio button list
- Enter Left in the Add prevalue textbox and click Add
- Enter Right in the Add prevalue textbox and click Add
- Submit
- Check Field is mandatory
- Submit
- Save

  

## Create a Banner Image Folder

  This is optional in Umbraco but is something we do as it restricts the types of image that can be allowed in a folder   In the Settings tab:   

- Click the ellipsis against Media Types and create a New Media Type; enter Banner Image Folder as the name
- Click the image and change to icon-folder-open green
- Click the Compositions hyperlink and check Folder
- Submit
- Click on the Permissions icon
- Check Allow as Root
- Click Add child under Allowed child node types
- Select Banner Image
- Save

     

## Add a Banner Image

 In the Media tab: 

- Click the ellipsis against Media and Create Item; select Banner Image Folder
- Name = Banner Images
- Save
- Click the ellipsis against Banner Images and click Banner Image (NB Umbraco would allow drag & drop but would create an image, not a banner image)
- Name = Car Insurance Home Page Banner
- Select the Banner Image tab 

- Click to upload in the file uploader and browse to the image
- Drag the dot on the image to change the focal point of the crop
- Can click on an individual crop anhd drag the image around to scale it
- Select the Caption tab
 

- Name = Car Insurance
- Caption Additional Text = Benefit from our 3 year fixed price commitment
- Calls To Action = Call To Action
- Click on Call To Action to expand: 

- Call to Action Link = /
- Call to Action Button Text = Find out more
- Check Call to Action New Window
- Click Aqua under Color Picker
- Select Left for Caption Position
- Save

   

## Create a Composition Document Type

 This is a shareable property representing a list of document types     In the Settings tab:  

- Click the ellipsis against Document Types and create a new Folder; enter Compositions as the folder name
- Click the ellipsis against DocumentTypes -> Compositions and create a Document Type without a template; enter Banner Composition as the name
- Click Add new tab and enter Banner Images as the name
- Click Add property: 

- Name = Banner Images
- Add editor and choose Multinode treepicker 

- Name = Banner Images - Multinode Treepicker
- Node type = Media
- Click Choose and select Banner Images
- Minimum number of items = 1
- Submit
- Submit
- Save

     

## Create a Base Page Document Type

 In the Settings tab:   

- Click the ellipsis against Document Types and create a Document Type without a template; enter Base Page as the name
- Click Add new tab and: 

- Enter Navigation as the name
- Click Add property and enter:
- - Name = Main Navigation Text
- Click Add editor and in the modal: 

- Select the Reuse tab
- Select Textstring
- Submit
- Click Add another tab and:
 

- Enter SEO as the name
- Click Add property and enter:
 

- Name = seo Title
- Click Add editor and in the modal: 

- Select the Reuse tab
- Select Textstring
- Submit
- Click Add property and enter:
 

- Name = seo Keywords
- Click Add editor and in the modal: 

- Select the Reuse tab
- Select Textstring
- Submit
- Click Add property and enter:
 

- Name = seo Description
- Click Add editor and in the modal: 

- Select the Reuse tab
- Select Textarea
- Submit
- Save

        

## Create a Home Page Document Type

 In the Settings tab:   

- Click the ellipsis against Document Types -> Base Page and create a Document Type; enter Home Page as the name
- Click the Compositions hyperlink, check Banner Composition and Submit
- Click on the Permissions icon
- Check Allow as Root
- Save

  

## Add Content

 In the Content tab: 

- Click the ellipsis against Content and create an item Home Page
- Name = Home
- In the Banner Images tab: 

- Click Add and select Car Insurance Home Page Banner
- Submit

    

## Add Markup

  In Visual Studio, add a Layout.cshtml and ViewStart.cshtml referencing this layout page. Umbraco content can be added as per the following example:  

```
<img src="@(Umbraco.TypedMedia(Model.Content.BannerImages.First().Id).GetCropUrl("Desktop"))" />
```

     

## Publishing

 Select the content to publish in the Content tab and click Publish  Publish generates the following in the C# project: 

- Umbraco.Web.PublishedContentModels.dll in the bin folder
- Models in the App_Data folder
- Media folders with thumbnails
- Views

  Umbraco aliases are the property names in C#  The Umbraco.Web.PublishedContentModels.dll needs to be referenced in the project and added to source control The media folder and generated Razor view(s) should also be included in the project