[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Rules for Extended Warranty

 

---

 

3.1.1 Vehicles eligible for Extended Warranty
The Extended Warranty is eligible for motor vehicles that fulfil the following criteria:
• All motor vehicles of the brands “**VW PC”, “Audi”, “Seat”, “Cupra” and “Skoda” with less than 100.000 miles** at the date of application (incl. applications in case of renew-als)
• **“VW CV” with the models: Caddy (incl. Caddy Life / Caddy Maxi Life), Transporter (incl. Transporter Shuttle models), T5 / T6, Amarok, LT, Crafter, Caravelle and Cali-fornia with less than 120.000 miles** at the date of application (incl. applications in case of renewals)
• Factory-fitted motor vehicles powered by gasoline, diesel, hybrids, electric or gas fuelled
• Vehicles registered in the United Kingdom (means England, Scotland, Wales and Northern Ireland)
• Vehicles used by private individual or business named on the Confirmation of Cover who is not a motor trader, garage, business or individual dealing in the buying or selling of motor vehicles.

 

3.1.4 Start date and exceedances for Extended Warranty
• The “**Day 1**”-tariff is **applicable for vehicles that are still covered by a current warranty** (manufacturer, approved used or extended warranty) **at the day of subscription**. If the current warranty is still valid, **the Extended Warranty starts at the end date of the cur-rent warranty + 1 calendar day.**
**If the current warranty has expired since less than 30 calendar days**, the risk shall be subscribed in the “**Day 1**”-tariff provided no claim has occurred since expiry of the previous warranty. In such cases, the Extended Warranty (means the insurance coverage) starts at the **subscription date + 1 calendar day**. If the current warranty has expired since more than 30 calendar days, the subscription shall be rejected in the “Day 1”-tariff.
• The “**Lapsed**”-tariff is applicable for vehicles with a **lapsed** manufacturer, approved used or **extended warranty (means: the vehicle is not covered by any warranty at the day of subscription).** These vehicles need to fulfil a waiting period before the **insurance coverage starts**. The waiting period is selectable by the customer between **a minimum of 30 calendar days and a maximum of 60 calendar days.** Accordingly **the earliest start date of the insurance coverage is the date of subscription + 30 calendar days, the latest start date of the insurance coverage is the date of subscription + 60 calendar days, depending on the selected waiting period.**
• The ”**Day 1**”-tariff is also applicable for **vehicles between 2-3 years old, where the factory cover mileage limit of 60.000 has been exceeded by max. 2.500 miles. If the mileage limit has exceeded by more than 2.500 miles, the “Lapsed”-tariff is applicable.**

 

 

 

****