[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Connexus Policy Validator API

 

---

   

## Website Details

  **Live URL:** [https://policy-validator-api.connexus.co.uk/](https://policy-validator-api.connexus.co.uk/) **UAT URL:** [https://policy-validator-api.connexus-test.co.uk/](https://policy-validator-api.connexus-test.co.uk/)    C# ASP.NET MVC Core .NET Core   

---

 

This is a REST API that ProClaim uses to validate that insurance policies exist before allowing claims to be established.

 

**Add Healthcheck**

 

In order for this API to be monitored in site24/7 a wwwroot folder was added in the root of the solution. The healthcheck.html file was added into this folder.

 

In Startup.cs, in the configuration, AddStatic() was added to allow the the healthcheck.html file to be served.

 

Future API's will need this, or an endpoint that will serve the healthcheck.html file. The load balancer issues this command

 

```
send "GET /healthcheck.html
```

 

 

 

**How to test in UAT**

 

*1, Using postman create a new POST request*

 

[https://policy-validator-api.connexus-test.co.uk/api/Validator](https://policy-validator-api.connexus-test.co.uk/api/Validator)

 

*2, Add a new Header :*

 

KEY - authKey,

 

VALUE - webuser|K4WKTHm+LDXyA3uqhB6eeB3kzGRPM7tfdvDcM3b7KeI=

 

DESCRIPTION - Authorization Key

 

*3, Create a body*

 

select raw and JSON

  { "policyNumber": "31300485", "firstName": "John ", "lastName": "Punch", "registrationNumber": "07D1668" }   *4, Auth is set to "No Auth"*   **How to test Locally**  *1, Run the solution in VS*  *2, Create a new request in Postman*  duplicate the request and change the URL to   

*https://localhost:44374/api/Validator   ( might need to alter the port number)*

 

*How to test Live*

 

As above but with the URL:

 

[https://policy-validator-api.connexus.co.uk/api/Validator](https://policy-validator-api.connexus.co.uk/api/Validator) 

 

 

 

Note that all environment should show the swagger page for this API.