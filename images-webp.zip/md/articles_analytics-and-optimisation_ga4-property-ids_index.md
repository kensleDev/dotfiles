[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# GA4 Property IDs

 

---

 

## UAT

 

| GA4 PROPERTY NAME | PROPERTY ID | Measurement ID |
| --- | --- | --- |
| Insure with Audi - GA4 | 381960455 | G-18PZ49MJM4 |
| Insure with SEAT - GA4 | 382618108 | G-J803SV59S2 |
| Insure with Skoda - GA4 | 382399498 | G-WKDFTMY4VP |
| Insure with Volkswagen - GA4 | 382624120 | G-N1FP7EXRF8 |
| Insure with VWCV - GA4 | 382617429 | G-YK71TJ9ZZ6 |
|  |  |  |
|  |  |  |
|  |  |  |
|  |  |  |

 

## Live

 

| GA4 PROPERTY NAME | PROPERTY ID | Measurement ID |
| --- | --- | --- |
| LIVE Insure with Audi - GA4 | 381983898 | G-LQ4T4HLED0 |
| LIVE Insure with SEAT - GA4 | 382413637 | G-LDSD1MHT3P |
| LIVE Insure with Skoda - GA4 | 382629390 | G-3K3PE9SMRG |
| LIVE Insure with Volkswagen - GA4 | 382619347 | G-CWPJTZ1VE2 |
| LIVE Insure With VWCV - GA4 | 382611322 | G-TPBBV0CC45 |
|  |  |  |
|  |  |  |