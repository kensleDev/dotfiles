[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Hi-Vis - Architecture

 

---

 

## Introduction

 

The technology used in Hi-Vis comprises:

 

- Microsoft .NET Framework 4.7.2
- ASP.NET Web API
- ASP.Net Identity Core
- Entity Framework 6
- ReactJS (version 16.9.0) implemented in Typescript
- React Router DOM
- React Bootstrap
- React Transition Group
- React Dropzone
- React Table
- Babel Polyfill
- SCSS
- Bootstrap 4
- RestSharp
- Microsoft SQL Server
- MS Test
- Moq

 

## Application Architecture

 

The website has the following projects:

 

- **HiVis** - the front-end project, entirely written in ReactJS
- **HiVis.Api** - the Web API back end
- **HiVis.Common** - common models, enums, app settings and constants used by other layers
- **HiVis.Dal** - data access layer implemented with Entity Framework, and repositories
- **HiVis.Identity** - implementation of *JWT* using *ASP.Net Identity*
- **HiVis.Services** - major service-layer implementations
- **HiVis.UnitTests** - MS Test unit testing project

 

These projects are source controlled in an Azure DevOps "Project"; **Justify**, which was a name Hi-Vis was briefly known by, the DevOps project was renamed and never renamed back. This project has a master 'trunk' code line, plus 'branches' which have been used for work in progress.

 

#### Integrations

 

The website integrates with one external system:

 

- **Cazana** - for looking up vehicle details and images by registration plate

 

#### Running the site locally

 

Unlike other modern websites at Connexus, the UI and API are two separate projects and must be started as such. Maybe once the project comes back on the roadmap this could be changed to use the .Net SPA framework, but currently must be started as follows:

 

- The API is started by running the solution from Visual Studio
- The UI is configured to run from *Task Runner Explorer* by selecting **start**, however this always serves up the directory rather than the site, so instead needs running as follows: 

- A **HiVis** website needs setting up in local IIS pointing at **C:\C:\CDS\Justify\Trunk\HiVis\Scripts\dist**
- Select **dev** from *Task Runner Explorer*; this builds a dev release
- Navigate to **http://hivis.local**

 

#### State

 

Global state is managed via the React Context API; local state is usually managed by hooks, although some components are class-based. The reason for the discrepancy is that the entire system was originally going to be class-based but there was a problem with passing the context to the service layer, such a problem didn't exist with hooks and therefore parts of the system that access the context were changed to functional components.

 

As there is no MVC layer and therefore no session, data that needs to be passwd between the UI and API is held in local storage.

 

#### React Plugins

 

##### React Router DOM

 

This is the most popular router for React. However there are a couple of additional things to bear in mind:

 

- The implementation of routing in **index.tsx** may seem overly complicated but the reason behind this is that the components fade in and out, this is not possible with CSS transitions as the router removes components from the DOM with no lifecycle hooks to subscribe to, and so **React Transition Group** is used to handle the animation, and this is the syntax required to implement routing within React Transition Group.
- Some of the routes render a **PrivateRoute** component; this is a *Higher Order Component* (*HOC*) which redirects to the login screen if the user is not logged in, and returns to the current page if the user attempts to access a screen which they are not authorised to do via roles.

 

Further documentation can be found [here](https://reactrouter.com/web/guides/quick-start).

 

##### React Bootstrap

 

This is a React implementation of Bootstrap 4 and was still in Beta at the time of development; if I had it to do over again I would use **ReactStrap** instead.

 

Further documentation can be found [here](https://react-bootstrap.github.io/).

 

##### React Transition Group

 

This provides HOCs to implement transitions, these require setting up in the CSS but as explained above what we are trying to achieve here can't be done with a simple CSS transition. 

 

Further documentaion can be found [here](https://www.npmjs.com/package/react-transition-group).

 

##### React Dropzone

 

This is a React implementation of *Dropzone* which is used on the file upload pages to allow drag-and-drop.

 

Further documentation can be found [here](https://github.com/react-dropzone/react-dropzone).

 

##### React Table

 

This is a fully-featured table allowing sorting and paging which is used to display the users table on the administrator dashboard.

 

Further documentation can be found [here](https://www.npmjs.com/package/react-table).