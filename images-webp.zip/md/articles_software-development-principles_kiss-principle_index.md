[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# KISS Principle

 

---

 

- **K** keep
- **I** it
- **S** simple
- **S** stupid

 

Speaks for itself

 

As developers, we should prefer the idea of proving something works before building it up into something more architectural, and indeed, if there is even a need to do so. We can have insights into how things might be used, but that doesn't mean now is the time to implement those changes.

 

This keeps our codebase much smaller and cleaner and opens us up to possible migration of code, or expansion in the future. So as long as we are keeping some separation of layers, and access is always through an interface, then integration into existing projects should be a lot easier. But the art of KISS is not to do too much too soon.