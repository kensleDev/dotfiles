[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Cazana Component - Architecture

 

---

 

## Introduction

 

The technology used in the component comprises:

 

- Microsoft .NET; two different versions using one of the following: 

- Microsoft .NET Framework 4.7.2
- Microsoft .NET Standard 2.1
- RestSharp
- MS Test
- Moq

 

## Application Architecture

 

There are two versions of the component, one written in .Net Framework and one ported to .Net Standard

 

### .Net Framework

 

The component has the following projects:

 

- **ConnexusComponents.Cazana** - the component
- **ConnexusComponents.Cazana.Tests** - MS Test unit testing project

 

These projects are source controlled in an Azure DevOps "Project"; **ConnexusComponents.Cazana**, under *ConnexusComponents*.

 

### .Net Standard

 

The component has the following projects:

 

- **Cds.Components.Cazana** - the component
- **Cds.Components.Cazana.Tests** - MS Test unit testing project

 

These projects are source controlled in an Azure DevOps "Project"; **Cds.Components.Cazana**, under *ConnexusComponents.Core*.

 

#### Integrations

 

The website integrates with one external system:

 

- **Cazana** - for looking up vehicle details and images by registration plate