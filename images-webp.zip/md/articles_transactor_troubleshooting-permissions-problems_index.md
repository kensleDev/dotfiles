[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Troubleshooting Permissions Problems

 

---

 

In TES Tools Suite:
Check the Visibility for the document pack, eg VELO310 - Renewal Acceptance Pack - Letter - Email; all options should be in the Visible column

 

Check that the pack has an end date in the future under Manage -> Documents and also its templates under Manage -> Templates, for example:
VELO007 - Renewal Acceptance Letter
VELO111 - Renewal Acceptance Email
VELO201 - Velosure Terms of Business
VELO002 - Cycle Insurance Policy Schedule
VELO010 - Statement of Fact
VELO202 - Velosure Insurance Product Information Document (IPID)
VELO203 - Velosure Demands and Needs Statement

 

In TCAS, try and send the emails myself but first check that I am OK to send to the client

 

Check the Event Viewer on the server

 

Ask the user to exit TCAS and log back in again