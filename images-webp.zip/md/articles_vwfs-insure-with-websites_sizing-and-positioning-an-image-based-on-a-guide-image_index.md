[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Sizing and Positioning an Image Based on a Guide Image

 

---

 

VWFS often provide images for the websites which are an unsuitable size. To resize the image based on an existing image from the website (a guide image), do the following in Gimp:

 

Drag in image to resize
Drag in guide image
Image -> Fit canvas to layers
Select the target layer
Layer -> Scale Layer
Ensure width and height are linked
Change Width or Height so layer being modified is at least the same size as the guide so we trim whitespace rather than add it in
Make both layers visible
Ensure guide layer is selected
Select All (CTRL-A)
Select target layer
Cut & paste
RMC on target layer & delete
Edit -> Paste as -> New layer
Select around image
Cut & paste
Click on tab indicator in top left corner
Use arrows to align vertically
Layer -> Scale layer
Change px dropdown to %
Guess a figure
Click anywhere inside image to deselect
Delete guide layer