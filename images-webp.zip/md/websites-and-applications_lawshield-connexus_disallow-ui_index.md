[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Disallow UI

 

---

   

## Website Details

  **Live URL:** [http://disallowui.connexus.rackspace/](http://disallowui.connexus.rackspace/) **UAT URL:** [N/A](N/A)    ReactJS   

---

 

#### Summary

 

The Disallow UI is a react JS front end to the [Disallow API](/websites-and-applications/lawshield-connexus/disallow-api/) It is an internal website with unique logins managed within the website detailed below. 

 

The website supports adding, amending and reviewing users that have be flagged as abusing / misusing our websites.

 

The website requires a note for when you add a new user or amending a current user, the user who added or amended as well as the note is added to the database, so we can easily audit each record 

 

There are also some admin features (available only to users with the admin role) these features are simply adding, viewing and editing users who have access to the system.