[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Motor Elite Trade with Claims Management AmTrust

    **Underwriter:** AmTrust Europe Limited **Net Premium:** £75.89     **UAT Scheme Table Id:** 1552 **UAT Scheme File Name:** 43526IB9.wpd  

---

  **Live Scheme Table Id:** 1512 **Live Scheme File Name:** 4358JKA7.wpd    

---

 

## Product

 

- [Motor Elite](/insurance-products/lawshield-dsp-b2b/motor-elite/)

 

---

 

## Scheme Description

 

The Motor Elite AmTrust **Product** has a number of different scheme files; some for variations in cover types, others are specific to particular brokers.

 

The **Motor Elite Fleet Trade with Claims Management AmTrust** scheme is currently only available to **Towergate Antur** brokers.

 

### Scheme Validity

 

There is a DateDiff operation ensuring that policy start dates are on or after 1st June 2020 when the scheme started.

 

### Risk Data

 

We then retrieve the **Number of Vehicles** to insure from the Motor Elite AmTrust Details screen, along with the **Subagent Id** (DSP variant) and **Policy Type Id** which dictates which of the Motor Elite schemes quote or decline.

 

### Towergate Antur Broker Checks

 

The scheme checks the **Subagent Id** = 15 to ensure only Towergate Antur brokers receive premiums from this scheme. It declines in all other cases.

 

### Risk Data Validation

 

The scheme checks that the **Policy Type Id** = 5, indicating "Trade Vehicles with Claims Management", and declines in all other cases.

 

---