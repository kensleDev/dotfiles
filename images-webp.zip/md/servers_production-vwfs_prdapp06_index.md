[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# PRDAPP06

 

---

 

## Server Details

  **Server Type:** Transactor **IP Address:** 192.168.105.115  

---

 

This server is a NEW **Transactor v6 Application Server** for VWFS products and will host all Transactor v6 applications and services, including:

 

- TCAS
- TES Tool Suite
- Relationship Manager
- TES Screen Builder
- Relationship Manager Service
- Document Service (incl. MSMQ etc.)
- TES PCEFT Server

 

 

 

---

 

## Insurance Products

 

- [VWFS Extended Warranty](/insurance-products/volkswagen-financial-services-vwfs/vwfs-extended-warranty/)
- [VWFS Ensurance](/insurance-products/volkswagen-financial-services-vwfs/vwfs-ensurance/)
- [VWFS Standalone MOT](/insurance-products/volkswagen-financial-services-vwfs/vwfs-standalone-mot/)
- [VWFS Approved Used MOT](/insurance-products/volkswagen-financial-services-vwfs/vwfs-approved-used-mot/)
- [VWFS Approved Used Keycare](/insurance-products/volkswagen-financial-services-vwfs/vwfs-approved-used-keycare/)