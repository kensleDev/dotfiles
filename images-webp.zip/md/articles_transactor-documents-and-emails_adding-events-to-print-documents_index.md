[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Adding Events to Print Documents

 

---

 

Note that this is just raw notes copied and pasted from Adrian Fleming's Sticky Notes and could do with revisiting:

 

Note 1

 

SELECT TOP 10 * FROM SYSTEM_EVENT e
JOIN SYSTEM_EVENT_LINK l ON e.EVENT_ID = l.EVENT_ID
JOIN LIST_PRODUCT_TYPE pt ON pt.PRODUCT_TYPE_ID = l.PRODUCTTYPE_ID
WHERE EVENT_DESCRIPTION LIKE 'Default NB Quote Accepted%'
--AND p.NAME = 'Lawshield Pedal Cycle'

 

Add Event
Event Type = Print Document
Choose event
Choose document pack
Output Destination = Email Direct (DOCUMENT_DESTINATION = 4)
Email Address = Other
Other Addres = FIXED_EMAIL_DESTINATION eg sales@velosure.co.uk
From Address = FROM_EMAIL eg [enquiries@velosure.co.uk](mailto:enquiries@velosure.co.uk)

 

 

 

Note 2

 

SELECT TOP 100 * FROM SYSTEM_EVENT_DOCUMENT_LINK
WHERE DOCUMENT_ID = 198

 

SELECT TOP 100 * FROM SYSTEM_EVENT_LINK
WHERE EVENT_ID = 2098

 

TES
Diary -> Events/Triggers
Expand Partner -> (eg) Volkswagen Ensurance

 

Click on Scheme Events
Click Add Event
Select Print Document and click Next
Select the event and click Next
Select the document pack and change the Output Destination to Email to Queue and click Next
Check Client, enter From Address and click Next