[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Access the Academy Training

 

---

 

Log in to the server ‘acturis-dev-01’ in RDC Manager
using CNX2 and local windows PW

Use Edge browser and navigate to
[https://support.acturis.com/absorbsinglesignon/sso](https://support.acturis.com/absorbsinglesignon/sso)

 

Then log in with given details

and the Registration key : 1F5320B0-D528-42C9-B932-410B40A5A9A9