[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Working with ASP.Net MVC, ReactJS and TypeScript

 

---

 

## Pre-Requisites

 

Node & npm

 

## Initialisation

 

Create a new ASP.Net MVC project using the Empty template but with Add folders and core references for MVC checked

 

## Setup NPM scripts to build dev and production versions with Webpack

 

Create a package.json file in the root of the project as follows:

 

#### File Name: package.json

 

```
{
    "version": "1.0.0",
    "name": "asp.net",
    "private": true,
    "scripts": {
        "dev": "webpack --mode development --watch",
        "build": "webpack"
    },
    "devDependencies": {}
}
```

 

## Configure TypeScript

 

Create a tsconfig.json file in the root of the project as follows:

 

#### File Name: tsconfig.json

 

```
{
  "compilerOptions": {
    "outDir": "./Scripts/",
    "sourceMap": true,
    "noImplicitAny": true,
    "module": "commonjs",
    "target": "es5",
    "jsx": "react"
  },
  "exclude": [
    "node_modules",
    "wwwroot"
  ]
}
```

 

To explain:

 

- The output directory is the Scripts folder which is where the TypeScript source will be written
- sourceMap will write a .js.map file for each transpiled .js file
- Types must be specified; if a type is "any" then this must be explicitly specified
- Use the CommonJS module format (used for imports)
- The transpiled JavaScript is ES5 (Babel is not required therefore)
- "jsx": "react" allows JSX to be written in a TypeScript file with the extension .tsx
- The node_modules and wwwroot folders are to be excluded from transpilation

 

## Configure Webpack

 

Create a webpack.config.js file in the root of the project as follows:

 

#### File Name: webpack.config.js

 

```
"use strict";
 
var path = require("path");
var WebpackNotifierPlugin = require("webpack-notifier");
var BrowserSyncPlugin = require("browser-sync-webpack-plugin");
 
module.exports = {
  entry: {
    p1: "./Scripts/src/index.tsx"
  },
  output: {
    path: path.resolve(__dirname, "./Scripts/dist/Home/React"),
    filename: "[name].entry.bundle.js"
  },
 
  // Enable sourcemaps for debugging webpack's output.
  devtool: "source-map",
 
  resolve: {
    // Add '.ts' and '.tsx' as resolvable extensions.
    extensions: [".webpack.js", ".web.js", ".ts", ".tsx", ".js"]
  },
 
  module: {
    rules: [
        {
          enforce: "pre",
          test: /\.js$/,
          loader: "source-map-loader"
        },
        // All files with a '.ts' or '.tsx' extension will be handled by 'ts-loader'.
        {
          test: /\.tsx?$/,
          loader: "ts-loader"
        }
    ]
  },

  externals: {
      'react': 'React',
      'react-dom': 'ReactDOM'
  },

  plugins: [new WebpackNotifierPlugin(), new BrowserSyncPlugin()]
}
```

 

To explain:

 

- path is the NodeJS path module which is used to resolve the output path; NB this could have been written as path: dirname + "/Scripts/dist/Home/React"
- webpack-notifier is a Webpack plugin that uses node-notifier (using SnoreToast) to notify the user of the build status
- browser-sync-webpack-plugin enables BrowserSync to be used if Webpack is started in watch mode
- module.exports: 

- entry defines the entry points. This can be a string or as in this example an object which allows a separate entry point to be specified per HTML document
- output defines the path and filename, the latter in this example suffixes the entry point's property name with "entry.bundle.js"
- devtool: "source-map" will output a .js.map file for each transpiled .js file
- the resolve extensions are an array of extensions which will be used to resolve imports where no extension is specified; specifying this option overwrites the default array so the values from the default need to be included in this array; this example adds ".ts" and ".tsx"
- module.rules is a list of handlers; this example is specifying a regex that picks up .ts and .tsx files and uses ts-loader to compile them, and a pre-loader for .js files which runs source-map-loader
- externals specifies to use external version of React and ReactDOM. This tells webpack to expect global variables on the window object rather than loading npm modules
- plugins specifies a new instance of the two Webpack plugins defined at the top of the script

 

## Install the NPM packages required in the dev environment

 

If Webpack and TypeScript are not already installed globally, do so:

 

npm install -g webpack typescript

 

Install the following via NPM:

 

- The React library (react & react-dom)
- The TypeScript compiler (typescript) and Webpack TypeScript runner (ts-loader)
- The sourcemap loader (source-map-loader)
- The TypeScript type definitions for React & React DOM (@types/react @types/react-dom)
- BrowserSync and its Webpack plugin (browser-sync & browser-sync-webpack-plugin)
- Webpack and its CLI (webpack & webpack-cli)
- Webpack notifier (webpack-notifier)

 

No idea why typescript and webpack need installing even though they are installed globally! Creating symbolic links with npm link doesn't work so this has to be done!

 

npm install --save-dev react react-dom typescript ts-loader source-map-loader @types/react @types/react-dom browser-sync browser-sync-webpack-plugin webpack webpack-cli webpack-notifier

 

## Download React and add to the layout page

 

The exports section in the webpack.config.js prevents React from being bundled with our JavaScript. Therefore the files [https://unpkg.com/react@16.8.3/umd/react.development.js](https://unpkg.com/react@16.8.3/umd/react.development.js) and [https://unpkg.com/react-dom@16.8.3/umd/react-dom.development.js](https://unpkg.com/react-dom@16.8.3/umd/react-dom.development.js) need to be downloaded to the project's Scripts folder, included in the project, and added to Layout.cshtml before the RenderSection scripts. Note that it HAS to be the umd version, not the cjs version

 

## Setup the MVC objects

 

- Add a HomeController
- Add a RenderSection for scripts to the _Layout.cshtml if it isn't already there
- Add a view:

 

#### File Name: Index.cshtml

 

```
<div id="body"></div>
 
@section Scripts
{
    <script src="~/Scripts/dist/Home/React/p1.entry.bundle.js"></script>
}
```

 

## Add BrowserSync support

 

When running Webpack in dev mode, BrowserSync will prompt to copy the following snippet into your website, just before the closing </body> tag so may as well do it now in the

 

```
<script id="__bs_script__">//<![CDATA[document.write("<script async src='http://HOST:3000/browser-sync/browser-sync-client.js?v=2.26.3'><\/script>".replace("HOST", location.hostname));//]]></script>
```

 

## Write some React

 

Add a new folder ~/Scripts/src/components and add a new file

 

#### File Name: people.tsx

 

```
import * as React from "react";
 
export interface IPerson {
    id: number;
    name: string;
    dob: Date;
    age: number;
}
 
export interface IPeopleProps {
    people: Array<IPerson>
}
 
export class People extends React.Component<IPeopleProps> {
    render() {
        return (
            <table className="table table-striped">
                <tbody>
                    <tr>
                        <th>Name</th>
                        <th>DOB</th>
                        <th>Age</th>
                    </tr>
                    {this.props.people.map(person => <tr key={person.id}>
                        <td>{person.name}</td>
                        <td>{person.dob.toDateString()}</td>
                        <td>{person.age}</td>
                    </tr>)}
                </tbody>
            </table>
        );
    }
}
```

 

It would appear that the component's <T> cannot be an array as there is no property that can be set in the render statement below, so the props object is a wrapper which just has one property whose type is the required array.

 

Add a new file in ~/Scripts/src/

 

#### File Name: index.tsx

 

```
import * as React from "react";
import * as ReactDOM from "react-dom";
import { People, IPerson } from "./components/people";
 
const peopleArray: Array<IPerson> = [
    {
        id: 1,
        name: 'John Doe',
        dob: new Date(1977, 7, 4),
        age: 41
    },
    {
        id: 2,
        name: 'Jane Doe',
        dob: new Date(1974, 6, 6),
        age: 44
    }
];
 
ReactDOM.render(
    <div>
        <People people={peopleArray} />
    </div>,
    document.getElementById("body")
);
```

 

## Run the app

 

- Install the NPM Task Runner and run the Custom dev task (or npm run dev from the command line)
- Run the MVC app