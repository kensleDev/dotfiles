[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Adding a new project to a dev & prod server

 

---

 

### Configuring domains

 

IT will add your website to the DNS after creating a ticket. This is done as so: 

 

- Go into 123Reg > Control Panel > Choose your website from Domains dropdown > Manage
- Choose Manage DNS > Advanced DNS > Focus on Type A
- Update first entries to point to Live server
- Add staging site with dev server

 

 

 

### Setting up a brand new project on a development server

 

#### Creating a new config file for a project

 

The domain is now configured to point to the correct server; however, the server does not know which website to load when a user visits that domain. To do this, we need to first create a folder for the website on the server followed by a configuration file for domain.

 

- On Apache server, navigate:

 

```
cd /etc/apache2/sites-available
```

 

- Copy and paste a previous file used and adapt for this new site, e.g:

 

```
sudo cp officialclaimsassist.co.uk.conf portalclaimsline.co.uk.conf
```

 

- Check the file again with ls -la and portalclaimsline.co.uk.conf will be there
- Edit the file:

 

```
sudo nano portalclaimsline.co.uk.conf
```

 

It should look somewhat like this: 

 

<VirtualHost *:80>

 

 ServerName staging.officialclaimsassist.co.uk

 

 DocumentRoot /var/www/oca/htdocs

 

</VirtualHost>

 

 

 

- **ServerName**: will be matched against the URL that the user is visiting
- **ServerAlias**: can be added to specify other domains that need to point to the same location
- **DocumentRoot**: The files that will be loaded for the specified domains.

 

**Note: when pointing to a Larvel installation, remember to target the public folder (e.g. /var/www/portalclaimsline.co.uk/htdocs/public)**

 

- Ctrl X, Y and Enter to save

 

 

 

#### Creating project in /var/www

 

```
Cd /var/www
```

 

Create a folder for the website -

 

```
sudo mkdir website-name
```

 

Navigate into the new folder and create a logs folder -

 

```
sudo mkdir logs
```

 

Add the htdocs file –

 

```
sudo mkdir htdocs
```

 

```
cd htdocs
```

 

Create a test index.html with

 

```
sudo nano index.html
```

 

Fill with basic html

 

Check if it is now in htdocs

 

In /etc/apache2/sites-enabled and the websites .conf file, you need to tell it where to log things into your log file, add these:

 

```
CustomLog /var/www/klslaw/logs/site-access.log vhost-combined
```

 

```
ErrorLog /var/www/klslaw/logs/site-error.log
```

 

Test (sudo apachectl configtest) and reload (sudo service apache2 reload) as you changed the .conf file

 

The error logs can be viewed with - nano site-error.log

 

- - site-access.log will contain information about each request to the site
- site-error.log will contain specific information about any server-side errors that occur during a request (i.e. 500 errors)

 

 

 

#### Activate the conf file

 

Go to sites-enabled – this contains the activated sites

 

```
cd /etc/apache2/sites-enabled
```

 

```
ls -la
```

 

ls -la shows that all activated sites are linked with the sites-available counterparts

 

Activate your new site with:

 

```
sudo a2ensite portalclaimsline.co.uk.conf
```

 

Before reloading, **ALWAYS RUN ERROR CHECKER** –

 

```
sudo apachectl configtest
```

 

If mistakes appear, edit the sites-available file. (FYI: can edit .conf file in either sites-enabled or sites-available. The one in sites-enabled links to the one in sites-available)

 

Once error free, reload Apache2 –

 

```
sudo systemctl reload apache2
```

 

or

 

```
sudo service apache2 reload
```

 

If it does nothing, that’s it worked.

 

You can now check the website URL on your browser and your HTML file contents should appear.

 

 

 

#### Setting up on DevOps

 

1. Create a new project, giving a name and short description
2. Go to the project Repo
3. Clone to your computer using the HTTPS, or the ‘clone in VSCode’ option and select repo location e.g. laragon/www
4. Create another index.html in VS Code
5. Initial commit to master
6. Back in DevOps, go to Branches
7. Create dev branch and make sure dev is default & compare branch
8. Go back to your Azure server

 

 

 

#### Connecting VS Code & DevOps project to Server

 

Go to

 

```
/var/www/*websiteName*
```

 

Remove htdocs – sudo rm -r htdocs/

 

**WARNING: Always double check that the folder/path that you’re removing is correct - it will not stop you from deleting the wrong thing, including the whole server!). To be safe, you can specify the absolute path to file/folder to remove:**

 

```
sudo rm -r /var/www/<WEBSITE>/htdocs
```

 

Take DevOps clone URL and

 

```
sudo git clone URL
```

 

and check contents

 

There will now be a file called after your website e.g. Portal%20Claims%20Line

 

Change this files name to htdocs –

 

```
sudo mv Portal%20Claims%20Line/ htdocs
```

 

Update permissions and ownership for the newly created htdocs folder:

 

```
sudo chmod 775 -R ./htdocs
```

 

```
sudo chown www-data:www-data -R ./htdocs
```

 

You should now be able to see all your files from var/www/websiteName

 

Cd into htdocs

 

Update .env file

 

 

 

### Putting a new project on a live server

 

No need to change anything on the DNS as it is already set up to point to Azure Live.

 

Create a pull request on DevOps to put dev into master

 

Using Apache live server, 

 

```
cd /etc/apache2/sites-available
```

 

Create a new .conf file for your project e.g.

 

```
sudo nano portalclaimsline.co.uk.conf
```

 

Put the Private IP of the server next to :portnumber

 

# Website (non-ssl)

 

<VirtualHost 172.25.194.196:80> 

 

 ServerAlias officialclaimsassist.co.uk

 

 DocumentRoot /var/www/officialclaimsassist.co.uk/htdocs/public

 

 CustomLog /var/www/officialclaimsassist.co.uk/logs/site-access.log vhost-combined

 

 ErrorLog /var/www/officialclaimsassist.co.uk/logs/site-error.log

 

 </VirtualHost>

 

 

 

# Website (ssl)

 

<VirtualHost 172.25.194.196:443>

 

 ServerName www.officialclaimsassist.co.uk

 

 ServerAlias officialclaimsassist.co.uk

 

 DocumentRoot /var/www/officialclaimsassist.co.uk/htdocs/public

 

</VirtualHost>

 

 

 

Exit out and navigate to project folder: 

 

```
cd /var/www
```

 

Create a folder for the website -

 

```
sudo mkdir officialclaimsassist.co.uk
```

 

Navigate into the new folder and create a logs folder -

 

```
sudo mkdir logs
```

 

Take DevOps clone URL and sudo git clone URL and check contents

 

There will now be a file called after your website e.g. Portal%20Claims%20Line

 

Change this files name to htdocs –

 

```
sudo mv Portal%20Claims%20Line/ htdocs
```

 

Update permissions and ownership for the newly created project folder:

 

```
sudo chmod 775 -R ./htdocs
```

 

```
sudo chown www-data:www-data -R ./htdocs
```

 

You should now be able to see all your files from var/www/websiteName

 

Update .env file

 

Run Composer in the htdocs: 

 

```
composer install
```

 

Then test & reload .conf file:

 

```
sudo apachectl configtest
```

 

```
sudo service apache2 reload
```

 

Activate the project -

 

```
sudo a2ensite portalclaimsline.co.uk.conf
```

 

If you need to deactivate it:

 

```
sudo a2dissite <site>
```

 

Test again and reload as you changed the .conf file.

 

Add SSL cert to the project. Look at *Renewing SSL Certs (Apache*) for more info

 

Cd into htdocs

 

Check git with:

 

```
sudo git status
```

 

```
sudo git checkout master
```

 

```
sudo git status
```

 

Once checked out to master branch, double check with another status command to double check it's on master.

 

If there’s a bunch of extra files you can:

 

```
sudo git stash
```

 

```
git status again
```

 

It should now say ‘nothing to commit.’

 

 

 

### Creating a user on Linux

 

```
sudo useradd testaccount
```

 

To create a test account and password - 

 

```
sudo passwd testaccount
```

 

To delete an account –

 

```
sudo userdel testaccount
```

 

 

 

#### Things I got stuck on and fixed

 

###### Error: user dev: authentication failure for "/": Password Mismatch

 

Check the .conf file to ensure it has the correct path to the project. Then in the file run either: 

 

```
composer install
```

 

```
composer update
```

 

 

 

###### After pulling latest onto the server, I get a 500 error.

 

Check error logs

 

Check the path in the website.conf – I had an error for having a / at the end of the server name.

 

 

 

###### Rolling back to the last commit you made

 

```
git reset --hard master@{1}
```