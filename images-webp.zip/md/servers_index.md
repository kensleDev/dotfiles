[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Servers

 

---

   

#### Production - VWFS

 

---

 

- ** [PRDAPP03 (192.168.105.107)](/servers/production-vwfs/prdapp03/) - Transactor v7 Application Server (Porsche)
- ** [PRDAPP06 (192.168.105.115)](/servers/production-vwfs/prdapp06/) - Transactor v6 Application Server (VW)
- ** [PRDWEB1 (192.168.104.178)](/servers/production-vwfs/prdweb1/) - VWFS Web Server (NEW W2019)
- ** [PRDWEB2 (192.168.104.177)](/servers/production-vwfs/prdweb2/) - VWFS Web Server (NEW W2019)

   

#### Production - Lawshield

 

---

 

- ** [PRDAPP7 (192.168.104.74)](/servers/production-lawshield/prdapp7/) - Transactor v6 Application Server (DSP)
- ** [PRDAPP05 (192.168.104.217)](/servers/production-lawshield/prdapp05/) - Transactor v6 Application Server (Velosure/Carbon)
- ** [PRDWEB05 (192.168.104.4)](/servers/production-lawshield/prdweb05/) - Lawshield Web Server
- ** [PRDWEB06 (192.168.104.218)](/servers/production-lawshield/prdweb06/) - Lawshield Web Server

   

#### Production - Database

 

---

 

- ** [PRDSQL1 (192.168.100.101)](/servers/production-database/prdsql1/) - SQL Server Database (Velosure/Carbon/DSP/VWFS/Porsche)
- ** [PRDSQL2 (192.168.100.102)](/servers/production-database/prdsql2/) - SQL Server Database (Velosure/Carbon/DSP/VWFS/Porsche)

   

#### Development/UAT

 

---

 

- ** [DEVWEB01 (192.168.204.217)](/servers/development-uat/devweb01/) - UAT Web Server
- ** [DEVSQL02 (192.168.200.113)](/servers/development-uat/devsql02/) - SQL Server Database

   

#### Development/UAT - VWFS

 

---

 

- ** [DEVAPP03 (192.168.204.112)](/servers/development-uat-vwfs/devapp03/) - Transactor v6 Application Server (VW)
- ** [DEVAPP5 (192.168.204.180)](/servers/development-uat-vwfs/devapp5/) - Transactor v7 Application Server (Porsche)

   

#### Development/UAT - Lawshield

 

---

 

- ** [DEVAPP1 (192.168.204.75)](/servers/development-uat-lawshield/devapp1/) - Transactor v6 Application Server (DSP)
- ** [DEVAPP02 (192.168.204.114)](/servers/development-uat-lawshield/devapp02/) - Transactor v6 Application Server (Velosure/Carbon)

   

#### Production - Marketing Aug 2023

 

---

 

- ** [PRD-UBUNTU-20.04 (51.145.114.15)](/servers/production-marketing-aug-2023/prd-ubuntu-20-04/) - Used for current live websites on PHP 7x and Ubuntu 20.04.3
- ** [PRD-LINUX-VM01 (52.151.76.213)](/servers/production-marketing-aug-2023/prd-linux-vm01/) - Used for older live websites on PHP 7x.
- ** [PRD-LINUX-VM02 (52.151.118.104)](/servers/production-marketing-aug-2023/prd-linux-vm02/) - Hosts CMS's for KLS, Specters & OYB.