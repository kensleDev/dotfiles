[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - VWFS Extended Warranty

 

---

 

This product is for the Audi, SEAT, SKODA, Volkswagen and Volkswagen Commercial Vehicles brands to offer Extended Warranty following the standard Manufacturer's or Approved Used warranty.

 

## Product Details

  **Product Reference:** VWFS **Product Type Id:** 663  

---

 

## Schemes

 

- [VW Extended Warranty](/insurance-products/volkswagen-financial-services-vwfs/vwfs-extended-warranty/vw-extended-warranty/)

 

---

 

## Associated Articles

 

- [VWFS Extended Warranty - Eligibility Criteria](/articles/vwfs-extended-warranty/ew-eligibility-criteria/)
- [VWFS Extended Warranty - Rating Criteria](/articles/vwfs-extended-warranty/ew-rating-criteria/)
- [VWFS Extended Warranty Rating Tables + how to update rates](/articles/vwfs-extended-warranty/ew-warranty-rating-tables-importing-new-rates/)