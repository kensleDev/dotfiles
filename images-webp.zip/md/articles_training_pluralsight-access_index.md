[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Pluralsight access

 

---

 

Connexus have an account with pluralsight, where you will find many useful training courses.

 

[www.pluralsight.com](https://app.pluralsight.com/id)
Login as Skills ...
development@connexus.co.uk
R3dDr4g0n8