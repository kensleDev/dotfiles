[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Setup Google Analytics

 

---

 

## Introduction

 

Google Analytics (GA) is an application available on the Google platform that tracks and reports website traffic, allowing monitoring of user behaviour, platform etc. to aid improving website quality etc.

 

Examples of the things that can be monitored are:

 

- Number of users visiting the website on a given day
- What operating systems they are using
- What browsers they are using
- Mobile screen resolutions
- New vs returning visitors
- Goals, for example some of VWFS's goals are Ensurance Purchase, Extended Warranty Purpose and Repair Tracker Lookup
- Goal funnel, ie how many users dropped out at each step of a journey and where they went to next

 

You can log in to our [Google Analytics](https://analytics.google.com/) setup with: [connexdigi@gmail.com](mailto:connexdigi@gmail.com) (Recovery email: [websitesupport@connexus.co.uk)](mailto:websitesupport@connexus.co.uk)

 

## GA Accounts

 

When setting up GA for the first time for a new customer, website or application, it may be necessary to create a new **Account**. Accounts are placeholders for all data associated with a high-level entity such as an entire customer; for example, we have an account for all websites and applications we manage for **VWFS**.

 

### Existing Account

 

It is likely that a valid account already exists for the website or application you are implementing in GA; it is important to check before creating a new account.

 

### New Account

 

You can follow the below steps to create a new account:

 

1. Click the **Admin gear icon** in the bottom left
2. Click **Create Account**
3. Enter the **Account name**, e.g. "VWFS" (doesn't need to be the same as the Account Name in GTM)
4. Leave the defaults Google products & services unchecked, and Benchmarking, Technical support & Account specialists checked
5. Click **Next**
6. Continue with configuring a Property by following the instructions below

 

## GA Properties

 

**Properties** are placeholders that uniquely identify an individual website or application. They are configured with a unique *code* that is used to ensure data for that website or application is always associated with the correct **Property** in GA.

 

### Creating a new Property

 

If you have identified an existing **Account** to use for integrating your website or application, you can create a new **Property** as follows:

 

1. If creating a property against an existing container then click the **Admin** gear icon in the bottom left, select the required account from the Account dropdown and click **Create property**; if a new account is being created then GA automatically moves to the create property step
2. Enter the **Property name**, e.g. "Insure with Skoda" (doesn't need to be the same as the Container Name in GTM)
3. Ensure "United Kingdom" is selected in the **Reporting time zone** dropdown
4. Ensure "British Pound (GBP £)" is selected in the **Currency** dropdown
5. Click **Show Advanced Options**
6. Turn **Create a Universal Analytics property** on; by default GA only creates a GA4 property which we are currently not using and is not compatible with Optimize
7. Enter the website URL without the https://
8. Select **Create a Universal Analytics property only**
9. Click **Next**
10. Select the **Industry category** = Finance from the dropdown
11. Select the **Business size**
12. Check **Measure customer engagement with my site or app**
13. Click **Create**
14. If prompted, accept the Google Analytics Terms of Service Agreement

 

This creates a default view called All Web Site Data

 

## Adding Google Analytics to a website or application

 

The Javascript code necessary to integrate your website or application with GA can be accessed at any time from the **Admin** screen, selecting your **Account** and **Property** under "Tracking Info" -> "Tracking Code". For GA there is one code block required for the <head /> tag.

 

This segment must sit as in the <head> following the GTM segment. At Connexus this code block is usually separated into partial views in MVC solutions or separate components in SPA-driven websites. It may also be conditionally rendered by the website for privacy reasons such as GDPR cookie acceptance.

 

**Note:** if the code already exists in the source, only the unique "GA-" code needs to be updated in the relevant place.

 

## Environment Switching

 

As mentioned above it is necessary to configure separate GA **Properties** for each environment a website resides in. This means each environment has its own, unique **Property** *code* required in the HTML. We are steadily implementing storage of the unique *code* in AppSettings -> GoogleAnalyticsKey in the web.config file; this has already been completed for Insure with Audi.

 

## Example: adding Google Analytics to a VWFS InsureWith website

 

The VWFS "Insure with" websites hold the GA Javascript code blocks in a separate partial view:

 

- **/Views/Shared/_googleTagManager.cshtml**

 

## GA Views

 

**Views** are a subset of a GA Property that can have its own unique configuration settings. You can create multiple **Views** for a Property and configure each **view** to show a different subset of data for the property.

 

### Creating an additional view for UAT

 

Although the website URL is held against the property, it is not necessary to create separate properties for live and UAT as views can override this URL and therefore we use the default All Web Site Data view for live and create an additional view for UAT as follows:

 

1. Click the **Admin** gear icon in the bottom left
2. Ensure the correct **Account** and **Property** are selected from the relevant dropdowns
3. Click **Create View**
4. Enter the **Reporting View Name** = "UAT"
5. **Create View**
6. Select **View Settings**
7. Set the **website's URL**
8. Select "British Pound (GBP £)" from the **Currency** displayed as dropdown (this is automatic for the default view but defaults to "US Dollar" for additional views)
9. **Save**