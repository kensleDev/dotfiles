[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# VWFS Insurance Portal

 

---

   

## Website Details

  **Live URL:** [https://www.vwfsinsuranceportal.co.uk/](https://www.vwfsinsuranceportal.co.uk/) **UAT URL:** [https://vwfsinsuranceportal.connexus-test.co.uk/](https://vwfsinsuranceportal.connexus-test.co.uk/)    .NET Framework C# ASP.NET MVC HTML CSS Bootstrap JavaScript jQuery   

---

 

The VWFS Insurance Portal is a website offering information about VWFS insurance products to dealerships in the Volkswagen Group. It is intended to only be accessed by employees of Volkswagen Group dealerships and provides information and documentation relating to all insurance products and offers available to owners of Volkswagen Group vehicles.

 

## Content Management

 

The VWFS Insurance Portal website is integrated with the **Umbraco Content Management System (CMS)**. This provides a platform for the management and maintenance of the majority of the text, graphics and documentation available to users of the website.