[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# IIS - URL Rewrites and "Vanity" URLs

 

---

 

## URL Rewrites

 

For the VWFS websites, we have implemented **IIS URL Rewriting** for multiple purposes:

 

1. Ensuring 'old' URLs still work from previous incarnations of websites
2. Applying 'Vanity' URLs to each site for redirection to pages within the sites

 

This configuration can be implemented through the IIS UI by selecting the relevant **Site** and opening the **URL Rewrite** module from the centre pane:

 

![](../images-webp/image_21.webp)

 

Ultimately the configuration is written into the **web.config** file of the site you are modifying:

 

![](../images-webp/image_22.webp)

 

### Old URLs

 

For old URLs, this requires a *URL Rewrite Rule* and a *Rewrite Map* for mapping 'old' URLs to 'new' ones.

 

#### URL Rewrite Rule

 

The URL Rewrite Rule uses regular expressions to match on the entire URL, but uses the *Rewrite Map* as the condition(s) for matching:

 

![](../images-webp/image_23.webp)

 

#### Rewrite Map

 

The URL Rewrite Map provides a mapping between 'old' and 'new' URLs which are used for conditional matching in the *URL Rewrite Rule*:

 

![](../images-webp/image_24.webp)

 

### Vanity URLs

 

Vanity URLs are normally used in marketing to provide a more user-friendly entry point to a section of a website. the VWFS websites have multiple URLs which are redirected to various sections of the site:

 

- [insurewithvolkswagen.co.uk](http://insurewithvolkswagen.co.uk/) - navigates to the **home page**
- [volkswagen-extendedwarranty.co.uk](http://volkswagen-extendedwarranty.co.uk/) - navigates to the **/extended-warranty page**
- [volkswagen-ensurance.co.uk](http://volkswagen-ensurance.co.uk/) - navigates to the **/ensurance page**

 

These are handled with *URL Rewrite Rules* that don't require a *URL Rewrite Map* entry:

 

![]()![](../images-webp/image_25.webp)