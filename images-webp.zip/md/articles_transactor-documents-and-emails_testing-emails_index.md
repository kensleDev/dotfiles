[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Testing Emails

 

---

 

## Identifying a policy in SSMS

 

Connect to DEV_CNX_TGSL (192.168.200.106)
Connect to the 395747_LawShield database
Load and run the query \\db2003b\CompanyData\Connexus Digital\Web Development\Documentation\Transactor\Advanced Transactor Training\Scripts\TCAS_Find_Policy_By_Make_And_Email
Copy the policy number
Need to choose a policy number beginning EWC for extended warranty, add AND POLICY_STATUS_ID = '3AJPUL66' to ensure the policy is live

 

## Sending an email from Transactor

  Client -> Enquiry Search by Policy/Quote Number, paste policy number and click Search Highlight the client and click Policies in the Client Select modal Highlight the policy and click View in the Client Select modal OK on the Diary Listings modal   Click Documents in the User Summary modal Check the documents to send, ensuring it is just the emails, not letters Click Email and OK in the Email Selection modal The emails have been sent when the Email button is no longer greyed out  To test letters, click Screen rather than Email  

## The script

 

```
-- ### EXTENDED WARRANTY ###SELECT TOP 10 *FROM CUSTOMER_POLICY_DETAILS cpdJOIN USER_VW_VEHDETS v ON v.POLICY_DETAILS_ID = cpd.POLICY_DETAILS_IDJOIN CUSTOMER_POLICY_LINK cpl ON cpl.POLICY_DETAILS_ID = cpd.POLICY_DETAILS_IDJOIN CUSTOMER_INSURED_PARTY cip ON cpl.INSURED_PARTY_ID = cip.INSURED_PARTY_IDWHERE cpd.POLICYENDDATE > GETDATE()AND v.MAKE = 'AUDI'AND cip.EMAIL = 'a.fleming@connexus.co.uk'AND POLICY_STATUS_ID = '3AJPUL66'AND cpd.POLICYNUMBER LIKE 'EWC%'ORDER BY cpd.POLICYENDDATE DESC-- ### ENSURANCE ###SELECT TOP 10 *FROM CUSTOMER_POLICY_DETAILS cpdJOIN USER_VW001_VW001 v ON v.POLICY_DETAILS_ID = cpd.POLICY_DETAILS_IDJOIN CUSTOMER_POLICY_LINK cpl ON cpl.POLICY_DETAILS_ID = cpd.POLICY_DETAILS_IDJOIN CUSTOMER_INSURED_PARTY cip ON cpl.INSURED_PARTY_ID = cip.INSURED_PARTY_IDWHERE cpd.POLICYENDDATE > GETDATE()AND v.VEHICLEMAKE = 'AUDI'AND cip.EMAIL = 'a.fleming@connexus.co.uk'AND POLICY_STATUS_ID = '3AJPUL66'ORDER BY cpd.POLICYENDDATE DESC
```