[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Insure with Porsche

 

---

   

## Website Details

  **Live URL:** [https://www.insurewithporsche.co.uk/](https://www.insurewithporsche.co.uk/) **UAT URL:** [https://uat.insurewithporsche.co.uk/](https://uat.insurewithporsche.co.uk/)    .NET Framework C# ASP.NET MVC Entity Framework 6 HTML CSS Bootstrap JavaScript jQuery AngularJS Redis   

---

 

Insure with Porsche is a public, customer-facing insurance quote-and-buy website for Volkswagen Financial Services (VWFS) motor insurance products. The website provides information and quote-and-buy functionality relating to:

 

- Annual Car Insurance
- 5-Day Drive Away Car Insurance

 

## Content Management

 

The Insure with Porsche website is integrated with the **Umbraco Content Management System (CMS)**. This provides a platform for the management and maintenance of the majority of the text, graphics and documentation available to customers on the website.

 

## Integrations

 

The Insure with Porsche website integrates with several third-party services hosted both internally at Connexus and externally:

 

- **OpenGI Transactor v7** - internal, used for quoting and inception of insurance policies
- **FastCode Database** - internal, used for address lookups
- **Carweb** - external, used to look up vehicle details from a VRM
- **BottomLine** - external, used to validate a customers' bank account details
- **2SMS** - external, used for sending SMS text messages
- **Sanctions Check** - external, used to perform fraud and money laundering checks

 

## Further Reading

 

Further details about technologies, architecture and insurance products can be found in other areas of the Knowledgebase:

 

- [Insure with Websites - Architecture](/articles/vwfs-insure-with-websites/vwfs-websites-architecture/)
- [Porsche OMR Motor (Annual)](/insurance-products/volkswagen-financial-services-vwfs/porsche-omr-motor-annual/)
- [Porsche OMR Motor (5-day Drive Away)](/insurance-products/volkswagen-financial-services-vwfs/porsche-omr-motor-5-day-drive-away/)