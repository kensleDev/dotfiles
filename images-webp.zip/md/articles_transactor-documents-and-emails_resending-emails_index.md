[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Resending Emails

 

---

 

This is to do with resending emails that were not received and are not in SYSTEM_EVENT_QUEUE.

 

Note that this is very rough; Ian Tabron was working out what to do and Adrian Fleming was taking notes, but there is a lot I don't understand; this document would need fixing up if this ever has to be done again.

 

SELECT * FROM SYSTEM_EVENT_QUEUE

 

TRAN_TYPE = INVITED, TRAN_OPERATOR = SYSTEM; automated renewal emails
list_action_log_type
system_diary_document_link join customer_diary_module

 

connexus.USER_VW_EW_MONITOR_TRANS_AND_MISSING_DOCS
system_dm_archive_document

 

POLICY_DETAILS_ID NVARCHAR(32), HISTORY_ID INT

 

-- Identify the event ID for VWCV EW DDI Policy Incepted (Internet) & VWCV EW Policy Incepted (Internet)
SELECT * FROM SYSTEM_EVENT WHERE EVENT_NAME LIKE 'vw%ew%' AND Deleted = 0

 

-- Identify the Direct Debit plan ID; on live this is 2F46F23C0F8C43AAA0022AFFC0EABBC8
SELECT * FROM RM_PAYMENT_PLAN

 

INSERT INTO @Requeue
SELECT POLICY_DETAILS_ID, HISTORY_ID, CASE WHEN PAYMENT_PLAN_ID = '2F46F23C0F8C43AAA0022AFFC0EABBC8' THEN 3068 ELSE 3069 END AS EVENT_ID
FROM CUSTOMER_POLICY_DETAILS
WHERE POLICY_NUMBER IN (/*...*/)
AND POLICY_STATUS_ID = '3AJPUL66' -- Incepted policies
AND SP_EW_Vehicle_Can_Renew

 

INSERT INTO SYSTEM_EVENT_QUEUE
(EVENT_ID, POLICY_DETAILS_ID, HISTORY_ID, EVENT_PROCESSED, ERROR)
SELECT EVENT_ID, POLICY_DETAILS_ID, HISTORY_ID0, ''
FROM @Requeue