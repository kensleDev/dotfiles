[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Landlord Rent Guarantee

 

---

 

Landlord Rent Guarantee covers rent arrears owed by tenant(s) under the tenancy agreement(s). Claims payments will be made when one full month’s rent is in arrears after the deduction of the £250 excess. Cover can be taken out for 6 or 12 months to suit the tenancy agreement(s).

 

## Product Details

  **Product Reference:** LLRENTG2 **Product Type Id:** 681  

---

 

## Schemes

 

- [Landlord Rent Guarantee v2](/insurance-products/lawshield-dsp-b2b/landlord-rent-guarantee/landlord-rent-guarantee-v2/)

 

---