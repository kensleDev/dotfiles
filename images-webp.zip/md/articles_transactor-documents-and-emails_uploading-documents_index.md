[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Uploading Documents

 

---

 

Copy the files onto the server; create a new folder if required but don't put them in the same folder as the wtf files

 

Latest suggested method from OGI

 

When creating new versions of the document:

 

1. Any version that will no longer be used should be expired with a date set in the past.steps: 
1. Select the document you want to expire.
2. Click on Expire.
3. Choose an expire date in the past (typically 1–2 days before today).

 

This ensures that outdated versions are properly closed off before a new one takes effect. The new version of the document will then begin on the date the previous one expired.

 

![](https://servicedesk.opengi.co.uk/servicedesk/customershim/secure/attachment/804257/804257_image-2025-08-27-14-02-02-998.png?fromIssue=466934)![](https://servicedesk.opengi.co.uk/servicedesk/customershim/secure/attachment/804257/804257_image-2025-08-27-14-02-02-998.png?fromIssue=466934)![](../images-webp/image_53.webp)

 

![](https://servicedesk.opengi.co.uk/servicedesk/customershim/secure/attachment/804257/804257_image-2025-08-27-14-02-02-998.png?fromIssue=466934)

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

Tools Suite -> Document Manager -> Configuration
Templates
Select template, 
Expire
Set **end date** and time = t+10 mins, overwrite the date and time
Expire
Select template again
Update
Browse to file (PDF needs to be selected as Ecomail attachment *.*)
Enter end date = today in 2099, end time = 09:00
Update

 

## Adding a New Document

 

Firstly add the template:
Manage -> Templates
Add Temp
Browse to the file
Add a description
Enter end date = today in 2099, end time = 09:00
Check Email Body Template if the document is an email
Save

 

Then add the document:
Manage -> Documents
Add Doc
Add a Name and Description (usually the same)
Add, choose the template and Select
Enter end date = today in 2099, end time = 09:00
Create

 

Finally make the document visible:
Visibility
Select Agent = Volkswagen Financial Services, or Volkswagen Ensurance
Select Product = Volkswagen Extended Warranty, or Volkswagen Ensurance
Select Scheme = VW Extended Warranty, or Volkswagen Ensurance
Add, choose the document and Select
Click > to move all the Not Visible options to Visible
Save

 

## Troubleshooting

 

When trying to upload a template, an error message is thrown; A template file already exists for this document, the file has already been promoted. Please update the version of the template if changes have been made.

 

Find the conflicting template file in D:/TCAS/Documents/Templates and delete it