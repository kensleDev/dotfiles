[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Motor Elite AmTrust

    **Underwriter:** AmTrust Europe Limited **Net Premium:** £5.00     **UAT Scheme Table Id:** 1545 **UAT Scheme File Name:** 432OQBE0.wpd  

---

  **Live Scheme Table Id:** 1506 **Live Scheme File Name:** 4358IVC5.wpd    

---

 

## Product

 

- [Motor Elite](/insurance-products/lawshield-dsp-b2b/motor-elite/)

 

---

 

## Scheme Description

 

The Motor Elite AmTrust **Product** has a number of different scheme files; some for variations in cover types, others are specific to particular brokers.

 

### Scheme Validity

 

There is a DateDiff operation ensuring that policy start dates are on or after 1st June 2020 when the scheme started.

 

### Risk Data

 

We then retrieve the **Number of Vehicles** to insure from the Motor Elite AmTrust Details screen, along with the **Subagent Id** (DSP variant) and **Policy Type Id** which dictates which of the Motor Elite schemes quote or decline.

 

This scheme checks that the **Policy Type Id** = 1, indicating "Personal and Commercial Vehicles", and declines in all other cases.

 

### Broker-Specific Logic

 

#### Classic Insurance Brokers

 

The scheme checks that the **Subagent Id** = 19 (Classic Insurance Brokers) as they have broker-specific schemes for Motor Elite AmTrust. It declines in the case where the broker is Classic.

 

#### Net Premium Variations

 

There then follows a series of checks against specific **Subagent Ids** to vary the **Net Premium** where these brokers have special terms applied:

 

- Surrey Independent (9)
- Stanmore (22)
- Oakwood Insurance (10)
- Millin Insurance Brokers (30)
- Regent Insurance Brokers (31)

 

In all of these cases, the **Net Premium** is reduced to £4.00.

 

### Premium Calculation

 

Finally, the **Net Premium** is multiplied by the **Number of Vehicles** to determine the premium before commissions.

 

---