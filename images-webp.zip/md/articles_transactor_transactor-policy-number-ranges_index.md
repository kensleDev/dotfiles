[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Transactor policy number ranges

 

---

 

Transactor holds lists of policy number ranges which are periodically provided by insurers, eg:

 

```
Highway Car Insurance EDIPrefix: EHighway Car range: 0225050 - 0225549LV= Broker – Clear 12.5Clear Car prefix: 712Clear Car range: 0225550 - 0226049
```

 

Note that there are usually an IPN (insurer policy number) and PN (policy number, ie broker, ie us). These can be different but should really be kept the same so do so

 

Login to the Lawshield server DEVRDP01 (192.168.204.109)

 

Run Relationship Manager; the T icon in the bottom left corner brings up the menu.

 

To find the outbound range, go into Schemes and find the scheme eg Highway Car Insurance EDI
RMC -> Edit
Note the Range Group dropdown, in this case Highway Car
Close

 

Note that if the Range Group does not exist it must be added in Outbound Ranges and then set in the dropdown in Schemes, but assume it exists for now...

 

Go into Outbound Ranges and highlight the range, in this case Highway Car
RMC -> Edit
Can check schemes here in the Schemes tab
Can RMC -> Expire the IPN and PN, but when the new one is activated this gives the option to expire the old one which is preferred
RMC -> Add
Select Type = Policy Number from the dropdown
Enter the Range, eg 0225050 to 0225549 in the above example, note that it strips the leading zeroes which are required
Enter the Prefix, eg 712 in the above example
Enter the Length, eg 10 in the above example as this will left-pad the range with zeroes. The length should be that of the prefix plus the range including leading zeroes
Enter the Warning Limit = 250 so Transactor warns us when it gets to within 250 of the upper range
Save
On UAT, RMC -> Activate, but do this first thing in the morning before office hours on live

 

 

 

Repeat the Add for LV= Broker in the above example

 

In V6 this makes a pending change so to activate these go into System -> Promote
Select the Change Type as Major or Minor
Enter a Reason, e.g. Replaced policy number ranges for Highway and LV= Motor
In V7 it appears that changes are promoted automatically

 

Promoting changes will kick everyone out of TCAS and can cause issues on the websites with sessions dropping, which is why this should be done out of hours