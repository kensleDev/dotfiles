[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Create .pfx using OpenSSL

 

---

 

*This article was written by Andrew Garvey in 2019 who no longer works for Connexus.*

 

#### Create .pfx using OpenSSL

 

2 files to generate a .pfx

 

1. .pem (-----BEGIN CERTIFICATE-----)
2. .key (-----BEGIN PRIVATE KEY-----)

 

In OpenSSL you need to transfer the separately saved private key into a PFX (PKCS#12) file. You can do so with the following command:

 

```
openssl pkcs12 -export -in specters.pem -inkey specters.key -out specters.pfx
```

 

After the password, with which the certificate will be secured, has been specified, a file output.pfx will be created in the address book, in which you currently are - choose the name according to the command above.

 

---

 

## Convert PFX to separate .key and .crt file

 

In this article I’m going to show you the commands you need to convert your .PFX Certificate file to a separate certificate and keyfile. This article can come in handy when you need to import your certificates on devices like Cisco routers/loadbalancers etc. where you probably need to import the certificates and keyfiles in plain text (unencrypted). My tool of choice (but there might be others) is OpenSSL for Windows, which can be downloaded here

 

So after you installed OpenSSL you can start it from it’s Bin folder. I’d like to put OpenSSL\Bin in my path so I can start it from any folder. Fire up a command prompt and cd to the folder that contains your .pfx file. First type the first command to extract the private key:

 

```
openssl pkcs12 -in [yourfile.pfx] -nocerts -out [keyfile-encrypted.key]
```

 

What this command does is extract the private key from the .pfx file. Once entered you need to type in the importpassword of the .pfx file. This is the password that you used to protect your keypair when you created your .pfx file. If you cannot remember it anymore you can just throw your .pfx file away, cause you won’t be able to import it again, anywhere!. Once you entered the import password OpenSSL requests you to type in another password, twice!. This new password will protect your .key file.

 

**Now let’s extract the certificate:**

 

```
openssl pkcs12 -in [yourfile.pfx] -clcerts -nokeys -out [certificate.crt]
```

 

**Just press enter and your certificate appears.**

 

Now as I mentioned in the intro of this article you sometimes need to have an unencrypted .key file to import on some devices. I probably don’t need to mention that you should be carefully. If you store your unencrypted keypair somewhere on an unsafe location anyone can have a go with it and impersonate for instance a website or a person of your company. So always be extra careful when it comes to private keys! Just throw the unencrypted keyfile away when you’re done with it, saving just the encrypted one.

 

**The command:**

 

```
openssl rsa -in [keyfile-encrypted.key] -out [keyfile-decrypted.key]
```

 

Again you need to enter an import password. This time you need to enter the new password that you created in step 1. After that you’re done. You **decrypted **your private key. In the folder you ran OpenSSL from you’ll find the certifcate (.crt) and the two private keys (encrypted and unencrypted).

 

In some cases you might be forced to convert your private key to PEM format. You can do so with the following command:

 

```
openssl rsa -in [keyfile-encrypted.key] -outform PEM -out [keyfile-encrypted-pem.key]
```