[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Keycare

    **Underwriter:** Ageas Insurance Limited **Net Premium:** £4.00     **UAT Scheme Table Id:** 1372 **UAT Scheme File Name:** 3QPUO2N9.wpd  

---

  **Live Scheme Table Id:** 1372 **Live Scheme File Name:** 3QPUO2N9.wpd    

---

 

## Product

 

- [Keycare](/insurance-products/lawshield-dsp-b2b/keycare/)

 

---

 

## Scheme Description

 

No rating logic required for the Keycare scheme - just a flat underwriter net rate.

 

---