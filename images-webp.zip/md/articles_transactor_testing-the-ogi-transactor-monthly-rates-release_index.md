[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Testing the OGI/Transactor monthly rates release

 

---

 

**Overview**

 

Each month, Transactor/OGI install updated rates for the Lawshield (Carbon/Velosure) Transactor environment.

 

This release contains the latest premiums/underwriting from insurers, and will come from "TGSL Underwriting Releases" email.

 

We need to test it and authorise the deployment (which OGI complete) in to both UAT and Live.

 

Note that this only applies to the Lawshield/Carbon/Velosure environment.

 

**Steps**

 

1). If OGI are requesting UAT release, authorise the release in to the UAT as long as there is nothing going on in the UAT environment that may be affected, or prevent them from installation. Sometimes OGI install this to UAT immediately, and will tell us as much in the email. 

 

2). Test the underwriting release works as expected. If unsure, you can always check the Live environment for the prior release to see how it behaves. If you find any issues, errors etc, respond and let OGI know so they can resolve or advise. To test:

 

 

 

- In TCAS, create a prospect on the Open Market Motor line of business. See below to save time.
- I have created a prospect already that you can use to save you creating one, however you have to run a script prior to picking this up in Transactor.
- ![](../images-webp/image_39.webp)
- Run the script on the Lawshield UAT or Live database (TGSL_Lawshield_UAT or TGSL_Lawshield): "\\192.168.30.18\CompanyData\Connexus Digital\Web Development\Transactor Scripts - useful\Quote Guarantee - set to new date.sql"
- The script will automatically update the quote guarantee dates, start and end date of all the above prospects to 1 month in advance, and the end date 1 year after that, less 1 day.
- It doesn't matter which one you pick. Once the script is run, load up one of the prospects and do a quote, making sure the inception date has defaulted to the month you are testing.
- ![](../images-webp/image_40.webp)
- You will see a panel of schemes. At the time of testing, this is how it looks, although it is subject to change. Check the schemes quote - you may need to adjust the risk to quote some schemes, based upon the decline reason:
- ![](../images-webp/image_41.webp)If you click the Conditions button, it will show a lot of information returned from the highlighted scheme. We are interested in the top, highlighted, line showing the Scheme Effective Date. This should match the month you quoted. If it does not, then something is wrong with the install from OGI, or the scheme has legitimately not been updated - this should be reflected in the release notes from OGI. Note the Decline on LV is because the scheme is no longer available for new business. ** Check ALL schemes **
- ![](../images-webp/image_42.webp)

 

 

 

4). Once you are happy the release works as expected, reply to OGI and let them know so the release can be installed to the Live environment at a mutually agreed date/time; they will let you know when they can install.

 

3). Once OGI confirm this is installed to Live, repeat Step 2 to test the release in Live. Note the Live install should be out of office hours.