[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Required elements/steps

 

---

 

For the 5 branded InsureWithSites (Audi/SEAT/SKODA/VW/VWCV) please ensure you do the following when setting up a local copy...

 

**Host file**

 

Ensure host files have the following values
127.0.0.1 insurewithporsche.local
127.0.0.1 insurewithaudi.local
127.0.0.1 insurewithseat.local
127.0.0.1 insurewithskoda.local
127.0.0.1 insurewithvolkswagen.local
127.0.0.1 insurewithvwcv.local
127.0.0.1 velosure.local
127.0.0.1 slides.web.local
127.0.0.1 LoanCarInsurance.local
127.0.0.1 cmacore.local
127.0.0.1 dsp.local
127.0.0.1 intranet.local
192.168.30.84 con-tfs-01
127.0.0.1 local.fnol.co.uk
127.0.0.1 chubb.fnol.co.uk
127.0.0.1 connexus.fnol.co.uk
127.0.0.1 velosure.fnol.co.uk
127.0.0.1 proclaim.local
127.0.0.1 VelosureAPI.local
127.0.0.1 toby.fnol.co.uk
127.0.0.1 history.local
127.0.0.1 knowledgebase.local

 

**IIS**

 

Add a new website with the host name matching one of the ones from the host file above. 

 

Add '{ComputerName}\IIS_IUSRS' with full permissions to the project folder containing the web.config.

 

Add the Url Rewrite package ([https://www.iis.net/downloads/microsoft/url-rewrite](https://www.iis.net/downloads/microsoft/url-rewrite))

 

**InsureWithShared**

 

Each brand has a branch within this project. Each branch will need building first as well as the trunk.

 

**On a fresh laptop**

 

In 'Turn on Windows Features' ensure the IIS Application Development option is ticked.

 

The Visual studio install may need the MVC package installing.

 

Add the Url Rewrite package ([https://www.iis.net/downloads/microsoft/url-rewrite](https://www.iis.net/downloads/microsoft/url-rewrite))

The following windows features need to be turned on 

 

![](../images-webp/image_2.webp)

 

 

 

**SEAT**Seat uses SCSS so you'll need to install the WebCompiler extension for visual studio and compile the files mentioned in the compilerconfig.json file 

 

**Typescript**

 

Typescript v2.3 is required. The required package is available in the software folder in the Connexus Digital (\\192.168.30.18\CompanyData\Connexus Digital\Web Development\Software) folder. 

 

*Dumb Stuff that helps in desperation*

 

Lots of Clean/ rebuild cycles....

 

Removing and reinstalling certain packages in Nuget eg. Entity Framework, Roslyn compiler (Microsoft.CodeDom.Providers.DotNetCompilerPlatform) ....

 

Adding a copy of the PublishedPages.dll umbraco files into the main project bin.

 

 

 

 

 

**Mel's Notes**

 

1. Open Visual Studio as admin.
2. Connect VS to your @connexusinsurance.onmicrosoft.com account and have permission to access the projects you are setting up.
3. In C:\, create a folder called CDS.
4. In VS, the project folders should appear after connecting to your Microsoft account.

 

![](../images-webp/image_3.webp)

 

- Map the project to your CDS folder, as below:

 

![](../images-webp/image_4.webp)

 

- Right click the project folder on the left, select Get Latest Version. A folder should appear in the CDS folder where you mapped it.
- Do this for the InsureWith-Shared folder.
- In the InsureWith-Shared folder, go into the sub-folder of the specific brand you are setting up.
- Double click the solution file to open it.
- Once loaded, at solution level right click and Restore NuGet Packages. Then Build.
- Leave InsureWith-Shared and go into the specific brand project folder you are setting up.
- Right click Trunk and Get Latest Version.
- In ISS, add the website to the list of websites. You may have to exit and reload VS after.
- In the brand solution, Build.
- You may need to right-click and Set as Startup Project.
- Press play button as Local IIS (Google Chrome)
- If it complains about Typescript, go to Properties of solution InsureWithBrand folder and change to 2.3 on leftside tab.
- The website will start up on Google.

 

 

 

**InsureWithSeat**

 

1. With SEAT, you may have an issue with the CSS rendering.
2. Go to the Extension tab and Manage Extensions.
3. Download Web Complier 2022
4. For each folder marked with Sass, right click > Web Complier > re-compile it.

 

 

 

**If there are missing images, you may need to pull the latest images from the server.**

 

1. Go into Remote Desktop Connection Manager
2. Log into DEVWEB01. You may need to ask IT for Rackspace log in.
3. In VS code go into the Media file. Expand it. Look at the last file name in this e.g. 1250.
4. Back in DEVWEB01, find the same Media file. It could be located somewhere like: C:\inetpub\VWFS\InsureWithSEAT-UAT\v2.83\Media
5. Copy whatever media files come after 1250 to get new files.
6. Paste into media file of explorer CDS.
7. Refresh at the top of Solution Explorer.