[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# DEVSQL02

 

---

 

## Server Details

  **Server Type:** Database **IP Address:** 192.168.200.113  

---

 

This database server hosts one instance of **Microsoft SQL Server** which contains all *UAT* databases:

 

- **582499_LawshieldVW_UAT** - NEW VWFS Transactor v6
- **TGSL_Lawshield_UAT** - NEW Lawshield Transactor v6 (Velosure etc.)
- **version7_WA02** - NEW Porsche Transactor v7
- **WA02_Configuration** - Porsche Transactor v7 "Configuration"
- **WA02_ServiceUsage** - Porsche Transactor v7 logging
- **FastCode** - address lookup database
- **CHUBB_MLE** - Chubb Motor Legal Expenses policy database
- **CmaCore_UAT** - main database for CMA Core web application
- **ConnexusConfig_UAT** - configuration for all Connexus UAT websites and applications
- **ConnexusKnowledgebase_UAT** -
- **HiVis_UAT** - main database for Hi-Vis web application
- **InsureWithAudiUmbraco_UAT** - UmbracoCMS database for Insure with Audi UAT
- **InsureWithSeatUmbraco_UAT** - UmbracoCMS database for Insure with SEAT UAT
- **InsureWithSkodaUmbraco_UAT** - UmbracoCMS database for Insure with SKODA UAT
- **InsureWithVolkswagenUmbraco_UAT** - UmbracoCMS database for Insure with Volkswagen UAT
- **InsureWithVWCVUmbraco_UAT** - UmbracoCMS database for Insure with VWCV UAT
- **LoanCarInsuranceUmbraco_UAT** - UmbracoCMS database for Loan Car Insurance UAT
- **VWFSInsurancePortalUmbraco_UAT** - UmbracoCMS database for VWFS Insurance Portal UAT
- **VWFSMarketing_UAT** - our "VMS" database, holds Manufacturer and Approved Used Warranty policies
- **VISInsureWith_UAT** - VW-approved Paint & Body centres
- **vwfs-central_UAT** - now defunct; used to hold a 'cache' of Ensurance policies

 

Connections to this database server should be made with the following server/hosts:

 

- 192.168.200.113

 

 

 

---