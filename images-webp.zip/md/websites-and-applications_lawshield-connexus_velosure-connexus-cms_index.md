[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Velosure (Connexus) CMS

 

---

   

## Website Details

  **Live URL:** [http://velosure-cms.connexus.rackspace/](http://velosure-cms.connexus.rackspace/) **UAT URL:** [N/A](N/A)    .NET Core 6 ASP.NET MVC Core HTML CSS C#   

---

 

### Summary

 

This website is a front end application using MVC to manage Articles and FAQs for Velosure.

 

To make the content writing easier / more user friendly we have added a content editor using [tinyMce](https://www.tiny.cloud/).

 

All the CRUD operations for this application are handled by the [Velosure API](/websites-and-applications/lawshield-connexus/velosure-api/), leaving this application to be a lot more lightweight and have basically zero dependency outside that of the API.

 

##### Features

 

The ability to create / edit articles with fully supported SEO functionality, that are automatically pulled into Velosure based on whether or not the status of the article is set to Live, the status can be set to testing / Archived if they need to be taken off Velosure to be edited or just removed, this all happens in real time so no downtime / deploys required.

 

 

 

The ability to create / edit FAQs much the same as articles just a bit simpler and no SEO required.