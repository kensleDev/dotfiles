[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# CMA Core - Architecture

 

---

 

## Introduction

 

As a prerequisite for Tier 1 certification, Connexus Medical Appointments (CMA) required a system for managing the availability of doctors and patient appointment allocation.

 

The technology used in this website comprises:

 

- Microsoft .NET Framework 4.6.2
- ASP.NET MVC 5
- ASP.NET Web API
- ASP.NET Identity
- Entity Framework 6
- jQuery and AngularJS (version 1) implemented in Typescript
- SCSS
- Bootstrap
- Microsoft SQL Server
- RestSharp
- MS Test
- Moq

 

## Application Architecture

 

The website consists of the following projects:

 

- **CmaCore** - front-end project including both MVC and WebAPI controllers
- **CmaCore.Common** - common models, enums, app settings and constants used by other layers
- **CmaCore.Dal** - data access layer implemented with Entity Framework
- **CmaCore.Identity** - ASP.Net Identity classes
- **CmaCore.Proclaim.Common** - models and validation shared between *Proclaim* and other layers
- **CmaCore.Proclaim.Services** - services and models specific to *Proclaim* integration, provides a SOAP web service to be consumed by Proclaim
- **CmaCore.Services** - major service-layer implementations
- **CmaCore.UnitTests** - MS Test unit testing project for the service layer

 

In addition, the following two projects still exist in the solution but are deprecated as a decision was made to create medical experts and venues via Proclaim rather than importing from CSV.

 

- **CmaCore.DataImport** - import medical experts and venues from CSV
- **CmaCore.DataImport.Services** - services to import medical experts and venues from CSV

 

And the following project which was never finished due to difficulties integrating Jasmine with AngularJS:

 

- **CmaCore.Scripts.UnitTests** - unit testing project for front-end business logic

 

These projects are source controlled in an Azure DevOps "Project"; **CMACore**. This project has a master 'trunk' code line, plus 'branches' for work in progress.

 

#### Integrations

 

The website has several integrations with both internal and external systems:

 

- **Proclaim** - for creation of medical experts, venues and appointments
- **AFD** - for searching address details by postcode
- **Google Maps** - for finding the latitude & longitude of the patient and venues

 

#### Third party plugins

 

The calendar on the medical expert dashboard is implemented using **Angular Bootstrap Calendar**. Further documentation can be found [here](https://github.com/mattlewis92/angular-bootstrap-calendar).