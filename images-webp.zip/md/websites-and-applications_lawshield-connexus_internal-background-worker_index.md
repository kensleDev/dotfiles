[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Internal Background Worker

 

---

   

## Website Details

  **Live URL:** [Configured as a windows service on PRDWeb 05](Configured as a windows service on PRDWeb 05) **UAT URL:** [No UAT environment exists](No UAT environment exists )    C# .NET Core 6   

---

 

#### Summary

 

This application is a dot net 6 background worker, that uses [a nuget package called Cronos](https://www.nuget.org/packages/Cronos) to run on a particular schedule using a [Cron expression](https://cronexpressiontogo.com/).

 

This application is currently setup on PRDWeb 05 as a windows service (called Log Reporter) that runs every morning at 9am, getting the last 24 hours worth of warning and error logs from [the central logging service](/websites-and-applications/lawshield-connexus/central-logging-api/) and the Aggregator API and then builds a request to sent to [the Email API](/websites-and-applications/lawshield-connexus/email-api/) emailing the development team email with that summary.

 

#### Testing

 

In the program.cs for this application we have used the UseWindowsService() extension method, to allow this application to run as one, to test this application locally, you can remove the method call and debug as as a normal console app, the cron expression used to determined when the application runs lives in the app settings.