[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Bomgar Access details

 

---

 

# Bomgar Access details

 

Username: Transactor-User1, Password: HjaNG9Mt@0408
Username: Transactor-User2, Password: gxJAkZNW1@0408

 

 

 

Bomgar should be installed on all servers so Open GI / Transactor can access our servers. If not, Open GI need to provide an installer so we can install it. Raise a Open GI ticket for the installer, and then raise a ticket for internal IT to do the install.