[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Policy Validator - Architecture

 

---

 

## Introduction

 

The purpose of the API is to return Chubb policy data via an endpoint which can be consumed by Proclaim.

 

The technology used in the API comprises:

 

- Microsoft .NET Core 3.1
- Microsoft .NET Standard 2.0
- ASP.NET MVC Core
- Entity Framework Core
- Microsoft SQL Server

 

## Application Architecture

 

The website has the following projects:

 

- **ConnexusPolicyValidator** - the API
- **ConnexusPolicyValidator.Common** - common models used by the API and service-layer
- **ConnexusPolicyValidator.Data** - DAL using Entity Framework Core
- **ConnexusPolicyValidator.Services** - currently only handles authorisation

 

There is an additional project which only exists to handle Entity Framework Core:

 

- **ConnexusPolicyValidator.DummyCore** - dummy project

 

These projects are source controlled in an Azure DevOps "Project"; **ConnexusPolicyValidator**, under C*onnexus*. This project has a master 'trunk' code line.

 

#### Integrations

 

The website integrates with one internal system:

 

- **Proclaim** - for creation and retrieval of claim data