[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Card Payments

 

---

 

**Overview**

 

Card Payments are handled through the [Global Pay SDK](https://developer.globalpay.com/net) with essentially just wraps around both the Ecom and GP-API routes. The core function used is the Payment Capture as described by the [Take Card Payments](https://developer.globalpay.com/sdk/card-payments) docs. Due to requirements however, we have to implement 3D Secure to allow the user to validate the transaction with their bank. This uses the SDK to return the functionality as described in the [3D Secure Documentation](https://developer.globalpay.com/sdk/3DS2). As noted below, this is not that detailed, and you have to go to the [Ecom 3DS Docs](https://developer.globalpay.com/ecommerce/3d-secure-version2/browser-authentication#hpp) in order to fully understand the 3D Secure workflow. This is used in conjunction with the Global Pay 3DS JS as explained in the 3DS Checks section.

 

**3DS Checks**

 

3DS takes the credit card info to check enrollment in the 3D Secure scheme. All cards in the UK should now be enrolled in 3DS 2.2 and as such, we are failing any card that does not meet these requirements. 

 

If Enrollment is valid the GP API will to away to the Card Providers bank and request an authorization link 

 

the Authorisation link needs to be a page redirect or an IFrame, it will send a call on completion to an API end point of your choice, which must return some sort of HTML/Script content to continue. ([See Docs for Responses](/See%20Docs for Responses))

 

In our case, we are sending the request back to *api/ChallengeNotification*****Which is returning information using [window.postMessage](https://developer.mozilla.org/en-US/docs/Web/API/Window/postMessage)

 

**Authorization Workflow**

 

****

 

 

 

**Workflow**

 

Our API is a single call to */api/ProcessCard*

 

this call relies on the transactionID being present at the root level of the request object in order to bypass check enrolment and actually take the payment. In the current version of the *api/ChallengeNotification* that we are using will save the order ref against the transactionID within the database, this is used at the point of "Has Auth ID" to check if the order was authorised in the last 5 minutes, if so it will attempt to process the payment. 

 

![](/media/zjdlyemz/api-workflow.webp)

 

**Debugging**

 

Notes: 

 

Test cards for card payments can be found here: [https://developer.globalpay.com/resources/test-card-numbers](https://developer.globalpay.com/resources/test-card-numbers)

 

Payments done on the GPAPI (aka, the route we take) at present do not appear in the dev dashboard.