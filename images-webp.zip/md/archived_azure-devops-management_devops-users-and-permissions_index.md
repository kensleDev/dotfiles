[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# DevOps - Users and Permissions

 

---

 

Azure DevOps is integrated with the full Azure platform which provides an Azure **Active Directory** (AD) container for managing permissions to Azure resources, including DevOps.

 

## User Management in Azure

 

Creating a new user for DevOps requires the creation of a new user in the Azure AD container. This can be completed on the Azure Portal at: [https://portal.azure.com/](https://portal.azure.com/). Your credentials for the Azure Portal are, unsurprisingly, the same as your Azure DevOps credentials; using your **@connexusinsurance.onmicrosoft.com** username.

 

Users are managed by navigating to the **Azure Active Directory** section and selecting **Users** from the menu on the left.

 

New users must be configured with a username containing the Azure AD domain: @connexusinsurance.onmicrosoft.com. Please see existing user configurations for examples on how to complete the configuration of a new user.

 

## User Management in Azure DevOps

 

Users that already exist in the Azure AD domain can be added to Azure DevOps through its own users and permissions management. This is accessed via the **Organisation Settings** section of DevOps, or directly at: [https://connexusdigitalsolutions.visualstudio.com/_settings/users](https://connexusdigitalsolutions.visualstudio.com/_settings/users)

 

### New Users

 

Multiple new users requiring the same permissions can be added at the same time by selecting the **Add users** button at the top-right.

 

**Users** - starting to type the name(s) of the new user(s) will find the user from the Azure AD domain. 

 

**Access level** - has several options:

 

- **Basic** - a 'standard' access level, usually for *contributors* to projects (i.e. developers)
- **Basic + Test Plans** - adds Test Plans to the 'standard' access level - for *testers*
- **Stakeholder** - a 'read only' access level for other stakeholders to a project (e.g. managers)
- **Visual Studio Subscriber** - used for *contributors* that have their own Visual Studio or MSDN subscription

 

**Add to projects** - allows you to select the individual projects the new user(s) should have access to. By default, users are added to the relevant *Teams* or *Groups* based on their **Access level**

 

**NOTE:** it is important to un-check the **Send email invites** option. Users don't have access to a mailbox at the email address configured as their Azure AD username, and so won't be able to receive an email invitation.

 

### Managing Existing Users

 

You can manage the access level, projects and project-level permissions for a user by clicking the ellipsis (...) on the user account in Azure DevOps and selecting **Manage user**. From here you can select which projects a user has access to, and their level of access from the following options:

 

- **Project Readers** - provides read-only access to the project and work items etc.
- **Project Contributors** - allows the user to commit source code and create/update work items etc.
- **Project Administrators** - allows the user to manage users, permissions, source code branches etc.

 

Sometimes you will see users with **Custom** permissions in this dialog. This usually means that specific permissions to certain resources or activities, for example, source code branching, have been granted from within the project *Teams* or *Permissions* management directly.

 

## Further Reading

 

Microsoft has extensive documentation on all aspects of Azure DevOps. For further information about Users, Access and Security Permissions in Azure DevOps see here: [https://docs.microsoft.com/en-us/azure/devops/organizations/security/about-permissions?view=azure-devops&tabs=preview-page](https://docs.microsoft.com/en-us/azure/devops/organizations/security/about-permissions?view=azure-devops&tabs=preview-page)