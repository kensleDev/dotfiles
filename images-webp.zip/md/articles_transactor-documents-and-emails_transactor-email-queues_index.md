[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Transactor Email Queues

 

---

 

When diagnosing issues with Transactor emails and the Document server, it can be useful to see if there are any issues in the queue inside Transactor itself.

 

To check if emails are stuck in the email queues you can run this SQL query on the relevant database:

 

```
/* View count of all events in the queue - documents & emails */SELECT count(*) as 'Documents in Queue' FROM SYSTEM_EVENT_QUEUE q with (nolock)/* View all events in the queue - documents & emails */SELECT cpd.POLICYNUMBER, cpd.QUOTEGUARANTEEDATE, cpd.CREATEDDATE, cip.EMAIL, q.*, 'se>>>' as delim1, se.*FROM SYSTEM_EVENT_QUEUE q with (nolock)inner join SYSTEM_EVENT se on q.EVENT_ID = se.EVENT_IDinner join CUSTOMER_POLICY_DETAILS CPD on q.POLICY_DETAILS_ID = CPD.POLICY_DETAILS_ID and q.history_id= CPD.history_idinner join customer_policy_link as CPL on CPD.POLICY_DETAILS_ID=CPL.POLICY_DETAILS_ID and CPD.HISTORY_ID=CPL.POLICY_DETAILS_HISTORY_IDinner join CUSTOMER_INSURED_PARTY as CIP on CPL.INSURED_PARTY_ID=CIP.INSURED_PARTY_ID and CPL.INSURED_PARTY_HISTORY_ID=CIP.HISTORY_IDinner join CUSTOMER_CLIENT_ADDRESS as CCA on CCA.INSURED_PARTY_ID=CIP.INSURED_PARTY_ID and CCA.HISTORY_ID=CIP.HISTORY_IDORDER BY EVENT_QUEUE_ID
```

 

The renewal process runs at 6am

 

## Check for errors in the event log

 

On the application server:

 

1. Run **Event Viewer**
2. Expand **Windows Logs** -> **Application**
3. Check a few instances of **TCAS_Document_Server**; you should see Getting Events and Finished Processing the Events in the General tab
4. Check a few instances of **TES_MSMQ_SERVER**; you should see a temp folder where pdf files are generated

 

## Check the Message Queueing and Document Server services

 

On the application server:

 

1. Run **Services**
2. Check that **Message Queueing (MSMQ), TES MSMQ Trigger** and **Document Server (TCAS_Document_Server)** are running. They should be set to automatic and running.
3. Try restarting these services

 

## Aspose.dll PDF Converter errors in Event Viewer

 

If you see errors in Event Viewer regarding Aspose.dll PDF Converter, the dll's are probably missing from the Windows assembly. Simply install them and restart the services mentioned above.

 

![](../images-webp/image_54.webp)

 

## 

 

## Check the registry setting on the App Server

 

When configuring Velosure LIVE, it was found that the registry setting for HKLM\SOFTWARE\WOW6432Node\TGSL\TCAS\MSMQ - "Server" being set to the IP address of the APP server did not work and emails failed to send. The setting had to be changed to the server name of the APP Server (or use "localhost"), and emails then worked correctly.

 

As per screenshot:

 

![](../images-webp/image_56.webp)

 

## Check for blank 'error_name' in the database, as blanks can cause a 'There was no Error Email Name set' error

 

On the SQL Server server:

 

1. Run the below query
2. ```
select * from system_dm_email_link where error_name = ''
```
3. If the query returns results, run the below to populate the missing fields:
4. ```
update system_dm_email_link
set ERROR_NAME = 'Error - Email failed to Send', ERROR_ADDRESS = 'development@connexus.co.uk'
where error_name = ''
```

 

## Check the message queue

 

The message queue in Windows can be accessed in Computer Management as follows:

 

![](../images-webp/image_57.webp)

 

## Check the TES_MSMQ configuration and logs

 

Compare with other UAT/Live environments for correct settings in the TES_MSMQ_Trigger.exe.config file.

 

![](../images-webp/image_58.webp)

 

 

 

Check the logs (*.txt files). In a working environment, you will see entries for each email being sent.

 

![](../images-webp/image_59.webp)

 

## Check permissions on the TCAS folder

 

Compare Security Settings / Permissions with a working environment, and ensure they are the same.

 

## Try a different version of TES_MSMQ

 

When migrating across UAT environments, emails were not sending after checking all the above. This was fixed by copying the Live server "C:\Program Files (x86)\Transactor\TES_MSMQ" folder to the UAT folder, after creating a backup on the UAT server.

 

![](../images-webp/image_60.webp)

 

 

 

## Try a different username to run the service

 

When migrating across UAT environments, emails were not sending after checking all the above. This was fixed by changing the user running the service 'Document Server' from local system to Transactor-User1@connexus.rackspace. It would seem that permissions of the default user were not adequate to run the service.

 

## If triggered diary events are not sending emails

 

We had this issue where emails were saending correctly from TCAS, but not from Triggered Diary Events.

 

The Transactor Document Service requires the following folder to exist, ensure it exists:

 

C:\Windows\SysWOW64\config\systemprofile\**Desktop**

 

A temporary workaround for this issue is to run the Document Server application on a logged in session, which then processes them without the service and works as if TCAS is loaded.

 

## Email the User

 

Something along the lines of:

 

We have had a look at the message queue which was empty and the document server seems to be processing document packs. We have therefore restarted the document services as a precautionary measure, could you please let us know if the problem persists.

 

## Checking Transactor SQL

 

```
-- Get make of policies that didn't receive documentsselect distinct MAKEfrom CUSTOMER_POLICY_DETAILS cpdjoin USER_VW_VEHDETS uvd ON cpd.POLICY_DETAILS_ID = uvd.POLICY_DETAILS_IDwhere POLICYNUMBER in('EWC185613', 'EWC185612', 'EWC185609', 'EWC185605', 'EWC185601', 'EWC185597', 'EWC185596', 'EWC185595', 'EWC185593', 'EWC185590', 'EWC185589', 'EWC185582', 'EWC185579', 'EWC185572', 'EWC185570', 'EWC185569', 'EWC185562', 'EWC185560', 'EWC185552', 'EWC185550', 'EWC185548', 'EWC185547', 'EWC185545', 'EWC185540')-- Get any other Volkswagen policies incepted this weekselect top 1000 CREATEDDATE, *from CUSTOMER_POLICY_DETAILS cpdjoin USER_VW_VEHDETS uvd ON cpd.POLICY_DETAILS_ID = uvd.POLICY_DETAILS_IDwhere CREATEDDATE >= '2020-09-28 00:00:00.000'and POLICY_STATUS_ID = '3AJPUL66' -- Incepted policiesand POLICYNUMBER not in('EWC185613', 'EWC185612', 'EWC185609', 'EWC185605', 'EWC185601', 'EWC185597', 'EWC185596', 'EWC185595', 'EWC185593', 'EWC185590', 'EWC185589', 'EWC185582', 'EWC185579', 'EWC185572', 'EWC185570', 'EWC185569', 'EWC185562', 'EWC185560', 'EWC185552', 'EWC185550', 'EWC185548', 'EWC185547', 'EWC185545', 'EWC185540')and MAKE = 'VOLKSWAGEN'order by 1-- See if policies that didn't receive documents were created on the same day or around the same timeselect CREATEDBY, CREATEDDATEfrom CUSTOMER_POLICY_DETAILS cpdjoin USER_VW_VEHDETS uvd ON cpd.POLICY_DETAILS_ID = uvd.POLICY_DETAILS_IDwhere POLICYNUMBER in('EWC185613', 'EWC185612', 'EWC185609', 'EWC185605', 'EWC185601', 'EWC185597', 'EWC185596', 'EWC185595', 'EWC185593', 'EWC185590', 'EWC185589', 'EWC185582', 'EWC185579', 'EWC185572', 'EWC185570', 'EWC185569', 'EWC185562', 'EWC185560', 'EWC185552', 'EWC185550', 'EWC185548', 'EWC185547', 'EWC185545', 'EWC185540')order by CREATEDDATE
```