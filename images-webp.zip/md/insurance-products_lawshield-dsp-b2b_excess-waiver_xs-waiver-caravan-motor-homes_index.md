[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - XS Waiver - Caravan & Motor Homes

    **Underwriter:** Inter Partner Assistance SA (IPA) which is fully owned by the AXA Assistance Group **Net Premium:** £0.00     **UAT Scheme Table Id:** 1357 **UAT Scheme File Name:** 3QB2N8H1.wpd  

---

  **Live Scheme Table Id:** 1357 **Live Scheme File Name:** 3QB2N8H1.wpd    

---

 

## Product

 

- [Excess Waiver](/insurance-products/lawshield-dsp-b2b/excess-waiver/)

 

---

 

## Scheme Description

 

Each Excess Waiver scheme identifies a **Base****Premium** based on the **Level of Indemnity** (i.e. the amount of excess the policy will cover).

 

In some cases, such as Personal Motor, this base premium is then multiplied by the number of vehicles, or properties to be included in the policy.

 

---