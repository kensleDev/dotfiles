[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Getting the Filename of Email Templates

 

---

 

 

 

```
-- Retrieves the filename, template name (FILE_DESCRIPTION) and version for Audi EW email templates-- The original file extension is prefixed with a ¬ symbol-- After this is another ¬ symbol, the version number and the .wtf extension-- Ensurance documents are excluded from the document name-- FILE_TYPE = 5 means email (1 is a Word document)-- The expiry date will be in the future, and current convention is to expire at 09:00 on today's date in 2099-- Previously this had been 2050, so excclude theseSELECT TOP 100f.FILE_NAME,f.FILE_DESCRIPTION,MAX(f.FILE_VERSION_ID)FROM SYSTEM_DM_FILE fJOIN SYSTEM_DM_FILE_LINK x ON f.FILE_ID = x.FILE_IDJOIN SYSTEM_DM_DOCUMENT d ON x.DOCUMENT_ID = d.DOCUMENT_IDWHERE f.FILE_NAME LIKE '%audi%'AND d.DOCUMENT_NAME NOT LIKE '%Ensurance%'AND f.FILE_TYPE = 5AND f.EXPIRY_DATE > '2051-01-01'AND d.EXPIRY_DATE > GETDATE()GROUP BY f.FILE_NAME, f.FILE_DESCRIPTIONORDER BY f.FILE_NAME
```