[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# GDPR data removal request

 

---

 

When a customer requests for their data to be removed from all locations per-GDPR guidelines, we need to ensure that we follow a convention for correctly anonymising policies in Transactor and VMS.

 

## Places to look

 

### Transactor

 

Depending on the type of policies the customer holds, you will need to update tables and fields such as:

 

- CUSTOMER_INSURED_PARTY 

- FORENAME
- SURNAME
- EMAIL
- USER_VW001_VW001 

- EMAIL
- PHONE
- USER_VW_CLIENTDT 

- FIRSTNAME
- SURNAME
- MOBILE
- RETEMAIL
- EMAIL

 

### VMS

 

All customer personal details for VMS are held in the following table:

 

- Warranty

 

**NOTE:** These are not exhaustive lists; please double-check that you have updated all necessary tables to completely remove the customer's personal details.

 

## New details to use

 

For consistency, you should use the following as replacement personal details:

 

- **Forename**: a
- **Surname**: GDPR
- **Email**: a@GDPR.com
- **Phone**: [empty string]