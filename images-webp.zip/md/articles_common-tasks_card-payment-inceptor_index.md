[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Card Payment Inceptor

 

---

 

**!! NEVER RUN THIS ON A LIVE SERVER !!**

 

This tool will intercept card payments made and spoof the return making the calling site believe that payment was successful.  

 

For the duration of the testing period you will need to remain logged in to the server. Logging off will kill the interceptor instance. 

 

 

 

![](../images-webp/image_76.webp)

 

![](../images-webp/image_77.webp)

 

If this is already running, there will be an icon in the tray. Double clicking that will re-open the dialog box. 

 

Card payments intercepted will show in this dialog area.