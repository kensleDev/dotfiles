[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# DEVAPP02

 

---

 

## Server Details

  **Server Type:** Transactor **IP Address:** 192.168.204.114  

---

 

This server is a NEW development and test **Transactor v6 Application Server** for Lawshield B2C products and will host all Transactor v6 applications and services, including:

 

- TCAS
- TES Tool Suite
- Relationship Manager
- TES Screen Builder
- Relationship Manager Service
- Document Service (incl. MSMQ etc.)
- TES PCEFT Server

 

 

 

---

 

## Insurance Products

 

- [Lawshield Pedal Cycle (Velosure)](/insurance-products/lawshield-b2c/lawshield-pedal-cycle-velosure/)