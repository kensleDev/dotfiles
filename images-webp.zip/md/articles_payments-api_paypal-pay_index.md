[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Paypal Pay - Setup and Test

 

---

 

**Paypal**

 

Paypal is a direct connection to PayPal’s services and does not require our API. The API connection to ConnexusPayments is entirely so we can log the transaction and OrderID for later.

 

We use this to bypass the need for the JS Files

 

[https://paypal.github.io/react-paypal-js/?path=/docs/example-paypalbuttons--default](https://paypal.github.io/react-paypal-js/?path=/docs/example-paypalbuttons--default)

 

Paypal site docs here:

 

[https://developer.paypal.com/sdk/js/configuration/](https://developer.paypal.com/sdk/js/configuration/)

 

**UAT Testing**

 

use the set up sandbox account -

 

Username: [sb-47asc319868174@personal.example.com](mailto:sb-47asc319868174@personal.example.com)

 

password: 0V8BtEv>

 

Confirm payment through the sandbox test site [https://www.sandbox.paypal.com/](https://www.sandbox.paypal.com/) logging in with the above credentials