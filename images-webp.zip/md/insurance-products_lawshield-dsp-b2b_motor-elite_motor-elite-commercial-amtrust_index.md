[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Motor Elite Commercial AmTrust

    **Underwriter:** AmTrust Europe Limited **Net Premium:** £5.00     **UAT Scheme Table Id:** 1547 **UAT Scheme File Name:** 4351V224.wpd  

---

  **Live Scheme Table Id:** 1508 **Live Scheme File Name:** 4358J849.wpd    

---

 

## Product

 

- [Motor Elite](/insurance-products/lawshield-dsp-b2b/motor-elite/)

 

---

 

## Scheme Description

 

The Motor Elite AmTrust **Product** has a number of different scheme files; some for variations in cover types, others are specific to particular brokers.

 

The **Motor Elite Commercial AmTrust** scheme is currently only available to **Towergate** brokers.

 

### Scheme Validity

 

There is a DateDiff operation ensuring that policy start dates are on or after 1st June 2020 when the scheme started.

 

### Risk Data

 

We then retrieve the **Number of Vehicles** to insure from the Motor Elite AmTrust Details screen, along with the **Subagent Id** (DSP variant) and **Policy Type Id** which dictates which of the Motor Elite schemes quote or decline.

 

### Towergate Broker Checks

 

The scheme checks for **Towergate**-based **Subagent Ids** to ensure only Towergate brokers receive premiums from this scheme. It declines in all other cases.

 

### Premium Calculation

 

This scheme checks that the **Policy Type Id** = 2, indicating "Personal and Commercial Vehicles", and declines in all other cases.

 

Finally, the **Net Premium** is multiplied by the **Number of Vehicles** to determine the premium before commissions.

 

---