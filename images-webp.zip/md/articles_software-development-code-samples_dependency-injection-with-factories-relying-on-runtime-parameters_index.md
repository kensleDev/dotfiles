[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Dependency Injection with Factories Relying on Runtime Parameters

 

---

 

In the construction of the Connexus Report Viewer, as part of the white labelling exercise it was determined that the site could not only support login / authentication from Proclaim users but could also be expanded to authenticate using other means depending on the site URL (e.g. Transactor, Identity). That way the same codebase could be used for enabling users to access reports specific to them.

 

To this end the following generic Interfaces were created:

 

```
/// <summary>/// A service interface that will handle authentication from the underlying system/// </summary>/// <typeparam name="T">Generic return type for the model containing user data for the report viewer / session</typeparam>public interface IAuthenticationService<T> where T : IAuthenticationResponse{    /// <summary>    /// Provides the ability to login and then retrieve userdetails    /// </summary>    /// <param name="loginViewModel">The user details submitted to validate from the view</param>ExecResponse<T> AuthenticateAndGetUserDetails(LoginViewModel loginViewModel);}
```

 

```
/// <summary>/// Interface for data gathered from systems at point of authentication/// To pass through to the report viewer/// </summary>public interface IAuthenticationResponse{    /// <summary>    /// The UserId to send to the report viewer    /// </summary>    string UserId { get; set; }}
```

 

The concrete implementation of these interfaces would be specific to the underlying system, with a factory taking in the baseUrl, resolving this with configuration data and then producing the correct authentication service (from AuthenticationServiceFactory.cs):

 

The challenge here was to set up the factory correctly in the DependencyInjectionConfig.cs so that there was no need to use any Dependency Injection code elsewhere in the application, however the base URL was at the time retrieved from the Controllers (Request.Url.Host)

 

The main thing to bear in mind here is that **the value of any parameters are only resolved in runtime at the point they are called, as interfaces are only injected at the point they are interacted with**.

 

To illustrate, here was the solution from DependencyInjectionConfig.cs:

 

```
builder.RegisterType<AuthenticationServiceFactory>().As<IAuthenticationServiceFactory>().SingleInstance();
```

 

```
builder.Register((CTX) => GetAuthenticationServiceInstance(CTX.Resolve<IAuthenticationServiceFactory>()));
```

 

```
/// <summary>/// Initialise a new instance of <see cref="IAuthenticationService{T}"/> where T is <see cref="IAuthenticationResponse"/> dynamically/// using the given instance of <see cref="IAuthenticationServiceFactory"/> based on the current URL/// </summary>/// <param name="authenticationServiceFactory">An instance of <see cref="IAuthenticationServiceFactory"/> /// to use for creating the appropriate <see cref="IAuthenticationService{T}"/></param>private static IAuthenticationService<IAuthenticationResponse> GetAuthenticationServiceInstance(IAuthenticationServiceFactory authenticationServiceFactory){    return authenticationServiceFactory.GetAuthInstance(HttpContext.Current.Request.Url.Host);}
```

 

The HttpContext.Current.Request.Url.Host at the point of registration will not hold a value, however, at the point that GetAuthInstance is called on IAuthenticationServiceFactory, it will hold the baseUrl. Hence the controller does not even need to take in the factory, it can now just accept an IAuthenticationService (from LoginController.cs):

 

```
public LoginController(IBrandingService brandingService,                       IAuthenticationService<IAuthenticationResponse> authenticationService,                       ExceptionHelper exceptionHelper) : base(brandingService){    _authenticationService = authenticationService;    _exceptionHelper = exceptionHelper;}
```

 

This is because when the authentication service is used later on in the Controller, the DI must first resolve the interface. As per the registrations, it will resolve it by calling the IAuthenticationServiceFactory method GetAuthInstance, the value of the parameter at the time it is called being the current URL the request has come from. Hence the resolution is correct and dynamic using parameters.