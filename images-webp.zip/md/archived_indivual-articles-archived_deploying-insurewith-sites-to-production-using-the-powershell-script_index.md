[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Deploying InsureWith Sites to Production using the PowerShell Script

 

---

 

## Introduction

 

In the UAT environment there are only single instances of each brands' ‘InsureWith’ site.

 

In the production environments there are three instances that all must be kept in sync. These three instances bridge two load balanced servers;

 

- PRODWEB03(192.168.105.105)
- PRODWEB04(192.168.105.106)

 

*PRODWEB03 has an additional instance, the ‘admin’ version.* This instance helps to mask the fact that the site is powered by Umbraco and provides a way to access the umbraco portal. In addition, when media files (images, pdf’s etc) are added, it is this instance of the site (more specifically, it’s ‘Media’ folder) that holds the updates. 

 

See the Article "Why Production InsureWith Sites have an Admin Instance" for a guide to the configuration.

 

## Preparing to deploy

 

The following steps can be done in advance of the planned deployment time which will will be scheduled in an agreed time period.

 

1. 1. Via IIS on UAT server, explore the insureWith Site and zip up the files. *EXCLUDE the following*

 

1. *web.config*
2. *Scripts/Connexus/Env.js*
3. *config folder*
4. *Media folder, unless a CMS freeze has been agreed and new media added by CNX*
2. Connect the required server using RD manager – PRODWEB03
3. Paste .zip on desktop
4. Open IIS on server and right click the required site. Browse to this folder using explorer
5. Create a new folder with the new version number and unpack the zip there

 

1. Copy the following from a previous version and paste into new folder:

 

1. web.config
2. *Scripts/Connexus/Env.js*
3. config folder
4. Media folder*, unless a CMS freeze has been agreed and new media added by CNX*
6. In whitespace of new folder in explorer, right click properties
7. In security tab, click **Edit** then **Add**
8. Click Locations – set this to root (first option)
9. Enter the user ‘Iusr’ then click check names – click ok
10. Make sure this new user (IUSR) has ‘full control’ ticked
11. Repeat 9 -16 for the ‘admin’ version of the site. Notes that web.config, Scripts/Connexus/Env.js + config folders needs to be copied from the previous ADMIN version.
12. Repeat steps 7-17 on the server PRODWEB04
13. Create a list of sites to be deployed, their current version number and target (post-deployment) version number which will be cross-referenced during the final deployment.

 

 

 

## Final Deployment

 

The following steps can only take place during scheduled Out-of-Hours session. Note that if no CMS/Media changes have been made, some steps can be omitted.

 

##### Schedule Maintenance

 

Use the website 24/7 to schedule enough working time to complete the task. Note that the finish time can be adjusted. LINK HERE TO ARTICLE

 

##### Website Bindings

 

The script is run firstly on PRDWEB03 and then on PRDWEB04 as follows:

 

1. Open a PowerShell script with elevated (administrator) privileges
2. **cd /deployment**
3. Ensure the contents of the **brands.txt** file are as expected, e.g. for a full deployment of all InsureWith sites: 

- audi,InsureWithAudi
- seat,InsureWithSeat
- skoda,InsureWithSkoda
- volkswagen,InsureWithVolkswagen
- vwcv,InsureWithVWCV
4. Allow the script to be run although it is not digitally signed: 

- **Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass**
5. For a full deployment of all websites in the brands.txt file: 

- **deploy -brand all**
6. Or for a deployment of an individual website, e.g.: 

- **deploy -brand audi**
7. Ensure that there are no errors (in red) in the PowerShell window
8. Cross-reference the version numbers in the PowerShell output against those noted in the prepping stage above

 

##### Updating the Umbraco Media

 

If the task has involved updating the CMS data there are further tasks to keep the media in sync;

 

1. Use RedGate SQL Data Compare to copy UAT database to the live database
2. Copy the media folder from each brand UAT media folder to the Live brand media folder
3. Update the DFS settings to sync PRODWEB03 and PRODWEB04 media folders

 

Each of these are detailed below.

 

**1 Redgate Compare**

 

1. Open RedGate SQL Data Compare 13 software
2. Select UAT as the source site, the target will be Live;![](../images-webp/image_5.webp)

 

 3. Click 'Compare now'

 

 4. Click DEPLOY to commit

 

 5. Do this for each brand if required

 

**2-****Copy the media folder**

 

1. Use RDM to open the UAT server DEVWEB01 (192.168.204.217)
2. Use IIS to locate the Admin site for the required brand
3. Zip up the contents of the media folder and copy the zip to local desktop. *Ignore the config file in the media folder*
4. Place this on the desktop of PRODWEB03
5. Use IIS to locate the admin site media folder and unzip the content here after creating a backup

 

**3-****Update the DFS settings**

 

If possible this should be completed last.

 

*[please visit the connexus group drive for a video demonstrating this process here-*

 

*\\db2003b\CompanyData\Connexus Digital\Web Development\Knowledgebase\Videos]*

 

PRODWEB04 InsureWith sites have a link the media folder in the ‘admin’ site on PRODWEB03.

 

This link is managed by the *DFS* server operation which effectively watches and mirrors the media folder.

 

*Note all of the tasks for this take place on PRODWEB03*

 

 

 

1. *Open Windows Server on PRODWEB03*

 

```

```

 

 2. Click DFS Management from Tools Menu

 

 3. Choose Replication from Left menu

 

```

```

 

 4. Select the brand

 

```

```

 

 5. Click the Replicated folder tab

 

 6. Delete the 'Media' entry

 

```

```

 

 7. Add a new replicated Folder from the left menu

 

 8. Select PRODWEB03 as the primary Member

 

```

```

 

 9. Click next then browse for the media folder (admin version) by clicking Add

 

```

```

 

 10. Click ok, then next to set up the ‘slave’ path (will be on PRODWEB04)

 

```

```

 

 11. Click Edit

 

 12. Click Enable then browse for the local source folder on PRODWEB04

 

```

```

 

 13. Clicking ok and next gives you a summary page

 

```

```

 

 14. Click Create. Click OK when shown the replication Delay dialog

 

 15. We can force the replication to happen without delay by opening ‘Services’ (still on PRODWEB03) and selecting the ‘DFS Replication’ service. Right click this and select ‘Restart’

 

```

```

 

This will be needed to be done for each brand/site.

 

##### Finally

 

1. Use the checklist to check for obvious issues: "\\192.168.30.18\CompanyData\Connexus Digital\Web Development\Release Checklist.xlsx"
2. Remove any unneeded zip files
3. the 24/7 site will show the status of the sites after the maintaince period has elapsed
4. If a specific feature has been added, test that feature across each site as appropriate