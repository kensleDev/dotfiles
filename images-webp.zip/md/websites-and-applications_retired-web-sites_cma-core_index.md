[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# CMA Core

 

---

   

## Website Details

  **Live URL:** [https://core.connexusmedicalappointments.co.uk/](https://core.connexusmedicalappointments.co.uk/) **UAT URL:** [https://core.connexus-test.co.uk/](https://core.connexus-test.co.uk/)    .NET Framework C# ASP.NET MVC Entity Framework 6 HTML SCSS Bootstrap JavaScript jQuery AngularJS   

---

 

## Introduction

 

Connexus Medical Appointments (CMA) contract medical experts to assess and treat patients referred to them by the claims handling teams at Connexus and Lawshield. A key requirement for MedCo Tier 1 accreditation is that medical experts should be able to view and manage their availability and appointment schedules with CMA via a software-based tool; CORE is designed primarily to satisfy this requirement.

 

CORE also interfaces with Proclaim given that this is the primary claims management tool used by CMA staff. This allows CMA staff to search, book and confirm appointments based on the availability of medical experts defined in CORE by those medical experts.

 

## Technology and Architecture

 

CORE is built on the following technology stack:

 

- .NET Framework 4.6.2 in C#
- ASP.NET MVC 5 and WebAPI
- Entity Framework 6
- AngularJS (version 1)
- HTML 5
- SCSS (CORE was the first project at Connexus to utilise SCSS over CSS)
- SQL Server database

 

CORE adopts the common application architecture used in many Connexus projects:

 

- **CmaCore** 

- ASP.NET MVC 5 and WebAPI web application layer, utilising AngularJS written in Typescript on the client-side
- **CmaCore.Common** 

- Provides common Enumerations, View Models and Infrastructure related utilities
- **CmaCore.Services** 

- The core business-logic layer. Exposes service classes, converters and helper classes as well as implementing the *Unit of Work* design pattern
- **CmaCore.Dal** 

- The core data-access layer. Uses Entity Framework 6 and the *Repository* design pattern
- **CmaCore.Identity** 

- A dedicated ASP.NET Identity layer for handling authentication and authorisation
- **CmaCore.Proclaim.Services** 

- A dedicated business-logic layer for communications with Proclaim
- **CmaCore.Proclaim.Common** 

- Provides common Models and Validation logic for Proclaim-specific functionality

 

### Deprecated Projects and Functionality

 

It was originally intended that CORE itself would be the single source of truth regarding medical experts, availability and booked appointments. In order to facilitate this, it was deemed necessary to perform a large data import from Proclaim into CORE. Two projects were added to the solution:

 

- **CmaCore.DataImport** 

- A console application providing a UI for importing Proclaim data into CORE
- **CmaCore.DataImport.Services** 

- A dedicated business-logic layer implementing the import of Proclaim data into CORE

 

However, it was subsequently determined that the best single source of truth for the process as a whole is Proclaim and not CORE. Therefore these two projects are now deprecated.