[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Equestrian Plan Legal Protection F&L

    **Underwriter:** Financial & Legal Insurance Company Limited **Net Premium:** £0.46     **UAT Scheme Table Id:** 1558 **UAT Scheme File Name:** 43I1PVQ5.wpd  

---

  **Live Scheme Table Id:** 1519 **Live Scheme File Name:** 43ISATS1.wpd    

---

 

## Product

 

- [Equestrian Plan Legal Protection](/insurance-products/lawshield-dsp-b2b/equestrian-plan-legal-protection/)

 

---

 

## Scheme Description

 

Not much rating logic required for the Equestrian Plan scheme.

 

There is a DateDiff operation ensuring that policy start dates are on or after 1st January 2021 (when the scheme started).

 

We then retrieve the **Number of Horses** to insure from the Equestrian Plan Details screen and multiply this by the **Net Premium**.

 

---