[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - VWFS Approved Used MOT

 

---

 

This is a free product offered to customers of Approved Used VWFS brand vehicles for free MOT insurance

 

## Product Details

  **Product Reference:** VWAUMOT **Product Type Id:** 671  

---

 

## Schemes

 

- [VWFS Approved Used MOT Cover](/insurance-products/volkswagen-financial-services-vwfs/vwfs-approved-used-mot/vwfs-approved-used-mot-cover/)

 

---