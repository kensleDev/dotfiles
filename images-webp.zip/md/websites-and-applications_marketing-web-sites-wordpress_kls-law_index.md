[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# KLS Law

 

---

   

## Website Details

  **Live URL:** [https://www.klslaw.co.uk](https://www.klslaw.co.uk) **UAT URL:** [https://kls.connexus-test.co.uk/](https://kls.connexus-test.co.uk/)      

---

 

Also known as KLS, it's very similar to the Specters website, I believe it's aimed more towards industrial/business related claims.

 

| URL | https://www.klslaw.co.uk |
| --- | --- |
| Admin URL | https://cms.klslaw.co.uk/ |
| CMS | Cockpit 0.9.2 |
| PHP version | ~7.2.19 |
| Location | prd-ubuntu-20 |
| Database location | N/A (SQLite hosted with CMS) |
| SSL Cert | From IT on prd-ubuntu-20.04 |
| SSL Expires | September 3, 2023 |