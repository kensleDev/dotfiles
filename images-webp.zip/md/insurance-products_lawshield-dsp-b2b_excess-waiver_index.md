[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Excess Waiver

 

---

 

Excess insurance is a policy that covers the value of any excess amount that customers may be required to pay following an insurance claim. In the event that a customer makes a successful insurance claim, they will receive reimbursement of any excess payment via this excess insurance policy.

 

### Cover Types

 

There are lots of types of cover offered on the Excess Waiver product:

 

- Personal Motor
- Motorcycle
- Driving Instructor
- Commercial Motor/Fleet Single Vehicle
- Caravan & Motor Home
- Commercial Motor
- Fleet - Multiple Vehicles
- Minibus
- Taxi
- Motor Traders
- Business Car
- Fleet & Commercial Combined
- Commercial Combined
- Buildings & Contents
- Motor & Home
- Motor & Home & Travel
- Motor, Home, Travel, Medical & Pet
- Personal Motor & Car Hire
- Tradesman
- Commercial Motor/Fleet Single Vehicle + Hire Car

 

Each of these types of cover has its own scheme file.

 

### Indemnity Levels

 

Excess Waiver offers different indemnity levels for certain products, but the majority use the following levels:

 

- £250
- £300
- £350
- £400
- £500
- £750
- £1,000
- £1,500
- £2,000
- £2,500

 

## Product Details

  **Product Reference:** EXWAIVERDIR **Product Type Id:** 320  

---

 

## Schemes

 

- [XS Waiver - Personal Motor](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-personal-motor/)
- [XS Waiver - Motorcycle](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-motorcycle/)
- [XS Waiver - Driving Instructor](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-driving-instructor/)
- [XS Waiver - Commercial Motor / Fleet Single](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-commercial-motor-fleet-single/)
- [XS Waiver - Caravan & Motor Homes](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-caravan-motor-homes/)
- [XS Waiver - Commercial Motor](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-commercial-motor/)
- [XS Waiver - Fleet Multiple Vehicles](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-fleet-multiple-vehicles/)
- [XS Waiver - Minibus](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-minibus/)
- [XS Waiver - Taxi](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-taxi/)
- [XS Waiver - Motor Traders](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-motor-traders/)
- [XS Waiver - Business Car](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-business-car/)
- [XS Waiver - Fleet & Commercial Combined](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-fleet-commercial-combined/)
- [XS Waiver - Commercial Combined](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-commercial-combined/)
- [XS Waiver - Buildings & Contents](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-buildings-contents/)
- [XS Waiver - Motor + Home](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-motor-home/)
- [XS Waiver - Motor + Home + Travel](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-motor-home-travel/)
- [XS Waiver - Motor + Home + Travel + Medical + Pet](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-motor-home-travel-medical-pet/)
- [XS Waiver - Motor and Home - Direct](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-motor-and-home-direct/)
- [XS Waiver - Four Counties Motor + Home](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-four-counties-motor-home/)
- [XS Waiver - Four Counties Commercial Motor](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-four-counties-commercial-motor/)
- [XS Waiver - Four Counties Personal Motor](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-four-counties-personal-motor/)
- [XS Waiver - Personal Motor and Car Hire](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-personal-motor-and-car-hire/)
- [XS Waiver - First Point Personal Motor](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-first-point-personal-motor/)
- [XS Waiver - First Point Building & Contents](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-first-point-building-contents/)
- [XS Waiver - First Point - Fleet Aggregator 20 vehicles or less](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-first-point-fleet-aggregator-20-vehicles-or-less/)
- [XS Waiver - Tradesman](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-tradesman/)
- [XS Waiver - Commercial Motor / Fleet Single - plus hire car](/insurance-products/lawshield-dsp-b2b/excess-waiver/xs-waiver-commercial-motor-fleet-single-plus-hire-car/)

 

---