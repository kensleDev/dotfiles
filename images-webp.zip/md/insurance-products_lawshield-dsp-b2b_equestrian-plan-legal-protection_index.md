[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Equestrian Plan Legal Protection

 

---

 

Equestrian Plan is a comprehensive legal expenses policy designed for horse owners, providing up to £50,000 cover for Legal costs and expenses. Our policy is specifically designed and developed to ensure customers are fully covered should the worst happen.

 

## Product Details

  **Product Reference:** EQUESTRIAN **Product Type Id:** 706  

---

 

## Schemes

 

- [Equestrian Plan Legal Protection F&L](/insurance-products/lawshield-dsp-b2b/equestrian-plan-legal-protection/equestrian-plan-legal-protection-f-l/)

 

---