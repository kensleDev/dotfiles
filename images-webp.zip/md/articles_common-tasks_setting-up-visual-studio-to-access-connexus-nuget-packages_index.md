[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Setting up Visual Studio to Access Connexus Nuget Packages

 

---

 

The source for the Connexus Nuget packages for .Net Framework (CDS) is [https://connexusdigitalsolutions.pkgs.visualstudio.com/_packaging/CDS/nuget/v3/index.json](https://connexusdigitalsolutions.pkgs.visualstudio.com/_packaging/CDS/nuget/v3/index.json)

 

The source for the Connexus Nuget packages for .Net Standard (CDS_NETStandard) is [https://connexusdigitalsolutions.pkgs.visualstudio.com/_packaging/CDS_NETStandard/nuget/v3/index.json](https://connexusdigitalsolutions.pkgs.visualstudio.com/_packaging/CDS_NETStandard/nuget/v3/index.json)

 

The old Connexus Nuget server (Connexus NuGet) was [http://con-tfs01:81/nuget](http://con-tfs01:81/nuget) ; having this enabled is likely to cause errors when trying to install packages from the live servers and so should be disabled.