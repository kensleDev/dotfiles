[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Intro to Servers

 

---

 

### Server list

 

As of July 2023

 

 

 

| Location | Type | IP | Comment |
| --- | --- | --- | --- |
| Azure | Production | 52.151.118.104 | Hosts CMS's for KLS, Specters & OYB. |
| Azure | Production | 52.151.76.213 | Used for older live websites on PHP 7x. Websites migrated to PRD-UBUNTU-20 in 2022 to increase security
Currently hosts Connexus.co.uk and the CRM |
| Azure | PRD-UBUNTU-20 | 51.145.114.15 | Used for current live websites on PHP 7x and Ubuntu 20.04.3
Currently hosts KLS, Specters and OYB |

 

 

 

## Useful information

 

**Website folders** All of the websites are kept in their respective folders in /var/www/.

 

**Apache** Apache is like a giant switchboard, it resolves all of the incoming URL requests to a website folder (and then specific pages within).

 

On a basic level, Apache works like this:

 

- User requests *http://www.velosure.co.uk*. That domain is pointed at our production server, so the user is taken there.
- Apache takes the domain name that they entered and checks all of its config files for any information to do with velosure.co.uk
- It finds an entry for Velosure which tells it to serve the files in /var/www/velosure.co.uk/htdocs

 

 

 

## Useful commands

 

#### Navigate to where websites are stored

 

```
cd /var/www
```

 

#### Navigate to where websites config is stored

 

```
cd /etc/apache2/sites-available
```

 

#### Navigate to where SSL certs are stored

 

```
cd /etc/ssl/certs/2023
```

 

#### Remove a non-empty directory and its content

 

```
sudo rm -r
```

 

#### Remove an empty directory

 

```
sudo rm -d
```

 

#### Rebooting a server when it asks for a restart

  

```
sudo reboot
```

  

#### Connect to a server via SSH

  

```
ssh username@xx.xxx.xxx.xx
```

  

#### Test before Reloading Apache

  

```
sudo apachectl configtest
```

  

#### Reload Apache2

  

```
sudo service apache2 reload
```

  

#### Removing a file

  

```
sudo rm /file/path
```

  

Double check path!

 

#### Restart Apache2

  

```
sudo service apache2 restart
```