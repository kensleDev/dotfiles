[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# HTTP Aggregator Monitor installation and usage

 

---

 

**What is the HTTP Aggregator Monitor**

 

The tool captures the input and output of the configured web services on a Transactor installation, and optionally writes the data to files. This is useful to see what data is being passed to and from Transactor.

 

**Installation**

 

Copy the following file to the Server that you want to run the tool on (usually a TCAS Application Server):

 

"\\192.168.30.18\CompanyData\Connexus Digital\Web Development\Software\Transactor\HTTPMonitor\HTTPMonitor.msi"

 

![](../images-webp/image_43.webp)

 

Run the MSI package on the server to install it. This will install the windows service "Aggregator Monitor":

 

![](../images-webp/image_44.webp)

 

as well as a shortcut on the desktop "AggHTTPViewer":

 

![](../images-webp/image_45.webp)

 

Before enabling the service, it is best to modify the config file ""C:\Program Files (x86)\Transactor Global Solutions\AggHTTPMonitor\AggHTTPService.exe.config"":

 

![](../images-webp/image_46.webp)

 

Modify the config file as follows:

 

![](../images-webp/image_47.webp)

 

Create the folder you specified above, as the tool will not create it. E.g. C:\aggHTTPMonitor

 

As the tool writes a LOT of information out (especially if used in a Live environment), it is easier to write files per day to a folder. Be careful - if you install this, and leave the service on for a number of days in a Live environment, you will eventually fill the hard drive!

 

Also before you run the service, you need to define which web services you want to attach the tool to, as per the following example - add the highlighted line (<add name="HttpModule" type="AggHTTPMonitor.HTTPModule, AggHTTPMonitor, Version=1.1.0.0, Culture=neutral, PublicKeyToken=063f2bc75464ba8c"/>) to the system.web\httpModules section of a web service web.config file - example below uses TES_QuoteWebService:

 

![](../images-webp/image_48.webp)

 

Start the service:

 

![](../images-webp/image_49.webp)

 

Now when you do a quote, you will get output in the configured folder:

 

![](../images-webp/image_50.webp)

 

Hopefully you will find what you are looking for inside the files:

 

A request file

 

A Response file

 

An information file

 

Note that you will need to run an XML tidy up tool on the request and response files to make them readable.

 

In NotePad++, the XMLTools addon 'Pretty print' is a good option, converting the below:

 

![](../images-webp/image_51.webp)

 

to something more readable:

 

![](../images-webp/image_52.webp)

 

You may find that the request/response files contains &gt; and &lt; rather than > and <. Find/replace these before using the Pretty print option.

 

Remember to switch off the service when you have finished using the tool.