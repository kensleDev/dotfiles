[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Setting up an Ubuntu 20.04.3 server

 

---

 

This process has been tested on **Ubuntu 20.04.3**. IT will set up the server with Ubuntu and send you the log in details. Log into the server using the Public IP address. This goes through everything I (Mel) used to flesh out the new Linux server.

 

1. Install **Apache 2**

 

Here is a useful [article](https://www.digitalocean.com/community/tutorials/how-to-install-the-apache-web-server-on-ubuntu-20-04)

  

```
sudo add-apt-repository ppa:ondrej/apache2
sudo apt-get update
sudo apt-get install apache2
```

 

Configure Apache to allow .htaccess overrides located here:

 

```
sudo nano /etc/apache2/apache2.conf
```

 

 Then change:

 

```
<Directory /var/www>
    Options Indexes FollowSymLinks
    AllowOverride All
    Require all granted
</Directory>
```

 

Check that it is the latest version of Apache.

 

#### Install UFW and OpenSSH

 

1. Install **UFW**

  

```
sudo ufw enable
```
2. Install **OpenSSH**

  

```
sudo ufw allow OpenSSH
```

 

#### Install Composer

 

Here is a useful [article](https://www.digitalocean.com/community/tutorials/how-to-install-composer-on-ubuntu-20-04-quickstart)

 

 

 

1. In ~, enter the following commands:

 

```
sudo apt update
```

 

```
sudo apt install php-cli unzip
```

 

```
curl -sS [https://getcomposer.org/installer -o composer-setup.php](https://getcomposer.org/installer%20-o%20composer-setup.php)
```

 

```
HASH=`curl -sS https://composer.github.io/installer.sig`
```

 

```
php -r "if (hash_file('SHA384', '/tmp/composer-setup.php') === '$HASH') { echo 'Installer verified'; } else { echo 'Installer corrupt'; 
unlink('composer-setup.php'); } echo PHP_EOL;"
```

 

2. In /usr/local/bin:

 

```
sudo php composer-setup.php --install-dir=/usr/local/bin --filename=composer
```

 

```
sudo chmod 775 -R ./composer sudo chown www-data:www-data -R ./composer
```

 

### Useful things to install

 

Back in ~, enter:

  

```
sudo usermod -a -G www-data USERNAME
sudo apt-get update 
sudo apt install php-xml
sudo apt-get install php-mbstring 
sudo apt-get install php-curl 
sudo chown -R $USER /home/<username>/.config/composer 
composer global require laravel/installer
sudo a2enmod headers
sudo a2enmod rewrite
sudo apt install php-zip
sudo a2enmod ssl
sudo a2enmod expires
```

  

- Try restarting the server and if there’s still an error with composer install, try:

 

```
sudo service apache2 restart
```

 

- In /var/www/WEBSITE/htdocs, add:

 

```
sudo chown -R $USER composer.lock>
```

  

#### Enable PHP

 

1. ```
sudo apt-get install libapache2-mod-php7.4
```
2. ```
sudo a2enmod php7.4
```

  

 

 

### Issues I faced setting up the servers

 

##### If you need to add different versions of PHP:

 

[https://devanswers.co/run-multiple-php-versions-on-apache/](https://devanswers.co/run-multiple-php-versions-on-apache/)

 

```
sudo apt install libapache2-mod-fcgidsudo apt install software-properties-commonsudo add-apt-repository ppa:ondrej/php sudo apt install php5.6 php5.6-fpmsudo apt install php7.4 php7.4-fpmls /var/run/php/sudo apt install php5.6-mysqlsudo apt install php7.4-mysqlsudo apt install php5.6-curlsudo apt install php7.4-curlsudo a2enmod actions alias proxy_fcgi fcgidsudo a2enconf php5.6-fpmsudo a2enconf php7.4-fpmsudo apt-get install php5-mcrypt
```

 

Update virtual host or htaccess

 

 

 

##### When inner pages don’t upload on the server

 

- Make sure you’ve enabled:

 

```
sudo a2enmod rewrite
```

 

- Is there a .htaccess? If it’s called .htaccess.save, change name to .htaccess

 

- In the conf file you can add this section of code into the Website.conf, if you have no luck with the above:

 

```
# Fixes issue with inner pages not displaying<Directory /var/www/portalclaimsline/htdocs/public>  Options -Indexes +FollowSymLinks  AllowOverride All</Directory>
```

 

##### Portal Claims Line issues

 

```
[RuntimeException] /var/www/portalclaimsline/htdocs/vendor does not exist and could not be created.
```

 

I did all the commands above and it worked the next day.

 

Check that you’ve changed htdocs to www-data

 

##### Cycle Accident issues

 

```
Error: In ProviderRepository.php line 208: Class 'October\Rain\Redis\RedisServiceProvider' not found
```

 

Delete 'October\Rain\Redis\RedisServiceProvider’ from app.php and it should work then.

 

##### Off Your Bike issues

 

Change Laravel/dusk in composer.json to 6.2

 

##### CMA issues

 

- Check that .htaccess is just .htaccess, not .htaccess.save

 

- To use the **PHP function mail()** you have to install it on the server:

 

```
sudo apt-get install sendmail
```

 

After the previous command finishes installing the sendmail package, you need to configure it. You can do that by running the following command, which will configure the mail server:

 

```
sudo sendmailconfig
```

 

You need to choose **Yes** to every question or otherwise configure it as you see fit.

 

##### Specters issues

 

```
The stream or file "/var/www/specters/htdocs/storage/logs/laravel-2021-09-22.log" could not be opened: failed to open stream: Permission denied
```

 

Change permissions to www-data.

 

Or if: 

 

```
Class 'Jralph\Twig\Markdown\Extension' not found
```

 

Then add:

 

```
composer require jralph/twig-markdown
```

 

```
composer require twig/extensions
```

 

##### KLS issues

 

Not responding?

 

Change vendor to www-data and run composer install again. Type Y for discard changes?

 

 

 

If the main contact form doesn’t work, make sure APP_DEBUG is set to false as it will not fire off unless that happens.

 

Vendor doesn’t exist? Exit out of the session and re-enter and try again.

 

 

 

##### Carbon issues

 

The configuration file does not exist.

 

 

 

In /var/www/carbon/htdocs/fuel/application/third_party/MX/Config.php change line 63

 

```
list($path, $file) = Modules::find($file, $_module, 'config/');
```

 

to

 

```
list($path, $file) = Modules::find($file, $_module, 'fuel/config/');
```

 

Is it cos the application/cache file is missing?

 

Add database.php & config.php in app/config – copy Prestige (look at what’s in Prestige’s laragon database)

 

Update SSL Baltimore SSL cert etc.

 

##### Prestige Car Hire issues

 

Add old PHP version to Virtual Host (look at ‘If you need to add different versions of PHP).

 

Mcrypt issue?

 

Add a new Encrypt.php file:

 

[https://github.com/kpushpendra81/exam/blob/master/encrypt.php](https://github.com/kpushpendra81/exam/blob/master/encrypt.php)

 

[https://stackoverflow.com/questions/35798048/php-error-the-encrypt-library-requires-the-mcrypt-extension-in-codeigniter](https://stackoverflow.com/questions/35798048/php-error-the-encrypt-library-requires-the-mcrypt-extension-in-codeigniter)