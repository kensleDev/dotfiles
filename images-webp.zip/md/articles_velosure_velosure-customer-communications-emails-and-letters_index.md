[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Velosure - Customer Communications - Emails and Letters

 

---

 

## Introduction

 

Connexus use the **Transactor** platform to send out customer communications regarding Velosure and the Lawshield Pedal Cycle product.

 

### Emails

 

There are eleven email templates:

 

| Template Name | Purpose |
| --- | --- |
| VELO101 - Final Renewal Reminder Email | A renewal reminder email sent to customers to remind them that their existing policy is soon to lapse |
| VELO102 - Terms of Business Email | An email containing the Terms of Business Document (TOBA) |
| VELO103 - Keyworker Campaign Email | A specialised email sent to Key Workers during COVID-19 lockdowns to inform them of their eligibility for a discount |
| VELO104 - New Business Email | The 'standard' new business Confirmation of Cover (CoC) email |
| VELO105 - Policy Expired Email | An email sent to customers informing them that their existing policy has now lapsed |
| VELO106 - Quotation Email | An email sent to prospective customers with the quotation details they received on the Velosure website |
| VELO107 - Renewal Invitation Email | The 'standard' renewal invitation email |
| VELO108 - Velosure - Anniversary Email - Quote | An email sent to previous customers whose policies have lapsed with a quote |
| VELO109 - Velosure - Anniversary Email - Renewal Lapse | An email sent to previous customers to inform them their policy has lapsed |
| VELO110 - MTA Email | An email sent to customers when a Mid-Term Adjustment (MTA) has been applied to their policy |
| VELO011 - Renewal Acceptance Email | An email sent to customers on the inception of a renewed policy |
| VELO012 - Quote Reminder Email | An email sent to prospective customers to chase online quotations that haven't been incepted as policies |

 

 

 

### Letters

 

There are fifteen letter templates and policy documents:

 

| Template Name | Purpose |
| --- | --- |
| VELO001 - Cycle Insurance MTA Policy Schedule | The policy schedule document sent when Mid-Term Adjustments (MTAs) are applied to a policy |
| VELO002 - Cycle Insurance Policy Schedule | The 'standard' policy schedule document |
| VELO003 - MTA Letter | A covering letter sent to the customer to confirm an MTA |
| VELO004 - NB Inception Letter | A covering letter sent to a customer on the inception of a new policy |
| VELO005 - Renewal 7 Day Reminder Letter | A 7-day renewal reminder letter |
| VELO006 - Renewal 14 Day Reminder Letter | A 14-day renewal reminder letter |
| VELO007 - Renewal Acceptance Letter | A covering letter sent to a customer on the inception of a renewed policy |
| VELO008 - Renewal Invitation - Close Brothers - Letter | The 'standard' renewal invitation letter sent to customers who have paid for their previous policy by Direct Debit |
| VELO009 - Renewal Invitation Schedule | The renewal policy schedule document |
| VELO010 - Statement of Fact | The 'standard' Statement of Fact (SoF) document |
| VELO011 - Velosure - Anniversary Letter - Quote | A letter sent to previous customers whose policies have lapsed with a quote |
| VELO012 - Velosure - Anniversary Letter - Renewal Lapse | A letter send to previous customers to inform them their policy has lapsed |
| VELO013 - Velosure - New Business Letter - 2020 | A covering letter sent to a customer on the inception of a new policy in 2020 |
| VELO014 - Velosure - Terms of Business Agreement | The Lawshield Pedal Cycle Terms of Business Agreement (TOBA) |
| VELO015 - Renewal Invitation - PIF - Letter | The 'standard' renewal invitation letter sent to customers who have paid for their previous policy in full by credit/debit card |

 

 

 

### Document Packs

 

There are twenty-three document packs:

 

| Document Pack Name | Included Templates |
| --- | --- |
| VELO301 - Renewal Invitation Pack - Close Brothers Finance Payment - Email | VELO107, VELO008, VELO009, VELO202, VELO204 |
| VELO302 - 14 Day Renewal Invitation Reminder Email | VELO107, VELO006 |
| VELO303 - 7 Day Renewal Invitation Reminder Email | VELO107, VELO005 |
| VELO304 - Cycle Insurance Quotation Email | VELO106, VELO013 |
| VELO305 - Terms of Business Email | VELO102, VELO201 |
| VELO306 - Policy Expired Email | VELO105 |
| VELO307 - Final Renewal Reminder Email | VELO101 |
| VELO308 - Cycle Insurance Policy Pack - Letter - Email | VELO004, VELO104, VELO201, VELO002, VELO010, VELO202, VELO203 |
| VELO309 - MTA Documentation Pack - Letter - Email | VELO003, VELO110, VELO001 |
| VELO310 - Renewal Acceptance Pack - Letter - Email | VELO007, VELO111, VELO201, VELO002, VELO010, VELO202, VELO203 |
| VELO311 - Anniversary Letter - Quote Letter | VELO011 |
| VELO312 - Anniversary Letter - Renewal Lapse Letter | VELO012 |
| VELO313 - New Business Letter | VELO013 |
| VELO314 - Key Worker Email | VELO103 |
| VELO315 - Website Cycle Insurance Quotation Email | VELO106 |
| VELO316 - Velosure - Anniversary Email - Quote Email | VELO108 |
| VELO317 - Velosure - Anniversary Email - Renewal Lapse | VELO109 |
| VELO318 - Renewal Invitation Pack - Annual Payment in Full - Email | VELO107, VELO015, VELO009, VELO202, VELO204 |
| VELO319 - TM Renewal Invitation Pack - Close Brothers Finance Payment - Email | VELO107, VELO008, VELO009, VELO205, VELO206 |
| VELO320 - TM Cycle Insurance Policy Pack - Letter - Email | VELO004, VELO104, VELO207, VELO002, VELO010, VELO205, VELO203 |
| VELO321 - TM Renewal Acceptance Pack - Letter - Email | VELO007, VELO111, VELO207, VELO002, VELO010, VELO205, VELO203 |
| VELO322 - TM Renewal Invitation Pack - Annual Payment in Full - Email | VELO107, VELO015, VELO009, VELO205, VELO206 |
| VELO323 - TM Terms of Business Email | VELO102, VELO207 |

 

 

 

### Events/Triggers

 

There are nine events/triggers configured to automatically send some of the above document packs:

 

| Event/Trigger Name | Associated Document Pack |
| --- | --- |
| VELO401 – Internet Quote Event | VELO315 |
| VELO402 – Quote Saved Event | VELO304 |
| VELO403 – MTA Event | VELO309 |
| VELO404 – MTA Quote Accepted | VELO309 |
| VELO405 – Renewal Invite – Close Brothers Finance | VELO319 |
| VELO406 – Renewal Invite – Annual Payment in Full | VELO322 |
| VELO407 - Quote Accepted Documents | VELO320 |
| VELO408 – Convert to Policy via Internet | VELO320 |
| VELO409 – Renewal Acceptance Pack | VELO321 |