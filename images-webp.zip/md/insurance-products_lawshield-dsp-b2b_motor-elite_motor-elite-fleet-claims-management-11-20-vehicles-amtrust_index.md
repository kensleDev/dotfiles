[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Motor Elite Fleet Claims Management 11-20 Vehicles AmTrust

    **Underwriter:** AmTrust Europe Limited **Net Premium:** £133.93     **UAT Scheme Table Id:** 1550 **UAT Scheme File Name:** 43524DS6.wpd  

---

  **Live Scheme Table Id:** 1510 **Live Scheme File Name:** 4358JEM9.wpd    

---

 

## Product

 

- [Motor Elite](/insurance-products/lawshield-dsp-b2b/motor-elite/)

 

---

 

## Scheme Description

 

The Motor Elite AmTrust **Product** has a number of different scheme files; some for variations in cover types, others are specific to particular brokers.

 

The **Motor Elite Fleet Claims Management 11-20 Vehicles AmTrust** scheme is currently only available to **Towergate Antur** brokers.

 

### Scheme Validity

 

There is a DateDiff operation ensuring that policy start dates are on or after 1st June 2020 when the scheme started.

 

### Risk Data

 

We then retrieve the **Number of Vehicles** to insure from the Motor Elite AmTrust Details screen, along with the **Subagent Id** (DSP variant) and **Policy Type Id** which dictates which of the Motor Elite schemes quote or decline.

 

### Towergate Antur Broker Checks

 

The scheme checks the **Subagent Id** = 15 to ensure only Towergate Antur brokers receive premiums from this scheme. It declines in all other cases.

 

### Risk Data Validation

 

The scheme checks that the **Policy Type Id** = 4, indicating "Fleet Vehicles with Claims Management", and declines in all other cases.

 

The scheme also checks that the **Number of Vehicles** supplied in the risk data is between 11 and 20, and declines in all other cases.

 

---