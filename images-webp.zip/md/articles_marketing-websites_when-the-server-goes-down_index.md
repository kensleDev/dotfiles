[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# When the server goes down

 

---

 

#### If the server goes down after you changed a file (so you know which file is the problem):

 

If you know the specific site that is bringing down the server, you can de-activate it: 

 

```
sudo a2dissite officialsclaimsassist.co.uk.conf
```

 

Test and reload:

 

```
sudo apachectl configtest
```

 

```
sudo service apache2 reload
```

 

After fixing issue, reactivate the website with: 

 

```
sudo a2ensite portalclaimsline.co.uk.conf
```

 

If it won’t reload, try explicitly starting the service with 

 

```
sudo apache2 start
```

 

If the apache service isn’t running you will always need to explicitly run the **start** command rather than **reload**

 

Then you can try and fix the issue with the site before reactivating it.

 

#### If the server goes down for a reason you don’t know

 

First check the logs.

 

- Check the error logs for apache in /var/log/apache2
- If permission to apache2 is denied, try sudo su before trying to get into the logs

 

If you can’t get into the logs, you’ll need to run some commands to determine the cause of the problem.

 

- ping the website URL which sends a quick message to a server to check that it’s okay.

 

This will verify that the **domain** is setup correctly. To check if the server is specifically responding, you would ping the **IP address** of the server directly. E.g. **ping 8.8.8.8**will tell you that Google’s server is responding while running **ping google.com** will fail if their domain isn’t setup correctly.

 

- If the server is okay it’ll give a result like this:

 

Reply from 92.52.106.33:

 

bytes=32 time=12ms TTL=53

 

- If you get this result, then it’s a domain name issue:

 

ping: unknown host [www.nosuchwebsite.fr](http://www.nosuchwebsite.fr)

 

- If nothing happens when you ping, or you get something like request timed out – not a good sign. If your ping command has timed out, then chances are your whole server has crashed, or the network has broken down between you and the server.

 

****

 

**If a site isn’t loading:**

 

- **Determine the problem**Is it a site error (i.e. 500, 404 etc) or are you unable to reach the site at all? If it’s the latter, proceed to step (1). If not, troubleshoot the site error as normal.

 

 

 

- **(1) Determine if it’s an isolated incident**Visit another site that’s hosted on the same server to see if it loads. If not, proceed to step (2)
- **(2) Has the server crashed?**Try and login via SSH - if you can, the server is operational - proceed to step **(3)**. If not, proceed to step **(4)**
- **(3)** **Is apache running?**Run service apache2 status (with sudo if needed) and it will report whether it’s up and running. If it’s running, try restarting or reloading the service or running **sudo apachectl configtest** to verify that the configurations are correct. If there’s still no joy, it’s time to start digging into log files!
- **(4) I can’t login to the server… it must be down!!**Login to the Azure control panel and attempt to start the server manually (ask IT to do this!)

 

If it won’t fire up again, it’s time to admit defeat and ask IT to restore the server to a working backup image.

 

### Error: apache2.service is not active, cannot reload.

 

```
sudo apachectl stop
```

 

```
sudo service apache2 start
```

 

#### If the server goes down after you rebooted the server:

 

The main reason for this happening is Apache not starting up after a reboot. This means the server will come back online but the websites will not. 

 

To check Apache's status, run: 

 

```
sudo apachectl status
```

 

If Apache is showing as down, start it up again: 

 

```
sudo service apache2 restart
```

 

Run the status check again, Apache should be showing as *Running* and the websites should be back up.