[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Opteven Data Feed Errors

 

---

 

# Troubleshooting Opteven Data Feed Errors

 VW Extended Warranty - Opteven Data Feed Errors returns Error Message Missing Drive Type;Missing Version  Obtain the Drive Type and Model from CarWeb via the intranet; if there is missing information on CarWeb then email their tech support [support@carwebuk.com](mailto:support@carwebuk.com)  Run the following SQL against the 582499_LawshieldVW database on 192.168.100.201\CNX_TGSL, replacing the values in the DECLARE statements with the values returned from CarWeb:  DECLARE @PolicyNumber VARCHAR(30) = 'POLICY_NUMBER' DECLARE @DriveType VARCHAR(200) = 'DRIVE_TYPE' DECLARE @Model VARCHAR(200) = 'MODEL'  SELECT TOP 10 DRIVETYPE, MODEL, * FROM USER_VW_VEHDETS uvv JOIN CUSTOMER_POLICY_DETAILS cpd ON uvv.POLICY_DETAILS_ID = cpd.POLICY_DETAILS_ID WHERE cpd.POLICYNUMBER = @PolicyNumber  -- Model and DriveType were incorrect, check this is correct SELECT TOP 10 MODEL, DRIVETYPE, * FROM USER_VW_VEHDETS WHERE POLICY_DETAILS_ID = (SELECT POLICY_DETAILS_ID FROM CUSTOMER_POLICY_DETAILS WHERE POLICYNUMBER = @PolicyNumber)  -- Update Model and DriveType from CarWeb UPDATE USER_VW_VEHDETS SET DRIVETYPE = @DriveType, MODEL = @Model WHERE POLICY_DETAILS_ID = (SELECT POLICY_DETAILS_ID FROM CUSTOMER_POLICY_DETAILS WHERE POLICYNUMBER = @PolicyNumber)   

---

 Opteven send report Search by registration number and customer is unable to get a quote online  Check the VIN and reg number on Carweb, the DVLA. try Cazana through Hi-Vis  Have a look at the following websites, bearing in mind that they literally read the first 8 characters to give you certain details which it can decode: [https://uk.vin-info.com](https://uk.vin-info.com/)/ [https://www.autodna.com](https://www.autodna.com/)  Contact CarWeb at [support@carwebuk.com](mailto:support@carwebuk.com) to ask if they can investigate the reg number and VIN  To determine whether the customer has had an EW reminder un the following SQL against the VWFSMarketing database on 192.168.100.104\PRD_CNX:  DECLARE @RegistrationNo NVARCHAR(24) = 'REGISTRATION_NO' DECLARE @ChassisNumber NVARCHAR(60) = 'CHASSIS_NUMBER' DECLARE @FirstName NVARCHAR(100) = 'FIRST_NAME' DECLARE @LastName NVARCHAR(100) = 'LAST_NAME' DECLARE @Email NVARCHAR(400) = 'EMAIL'  SELECT TOP 10 * FROM Warranty WHERE RegistrationNo = @RegistrationNo OR ChasisNumber = @ChassisNumber OR (FirstName = @FirstName AND LastName = @LastName) OR Email = @Email  SELECT TOP 10 * FROM History WHERE Data LIKE '%"RegistrationNo":"' + @RegistrationNo + '"%' OR Data LIKE '%"ChasisNumber":"' + @ChassisNumber + '"%' OR Data LIKE '%"FirstName":"' + @FirstName + '","LastName":"' + @LastName + '"%' OR Data LIKE '%"Email":"' + @Email + '"%'