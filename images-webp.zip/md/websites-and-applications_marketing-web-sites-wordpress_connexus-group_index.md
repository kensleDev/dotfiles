[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Connexus Group

 

---

   

## Website Details

  **Live URL:** [https://www.connexus.co.uk](https://www.connexus.co.uk) **UAT URL:** []()      

---

 

Our main company website used as a hub for introducing our various businesses. This is one of our latest builds.

 

| URL | https://www.connexus.co.uk |
| --- | --- |
| Admin URL | https://www.connexus.co.uk/admin |
| CMS | Pyro CMS |
| PHP version | ~7.2 |
| Location | Azure production |
| Database location | Azure production |
| SSL Cert | From IT on PRD-LINUX-VM01 |
| SSL Expires | August 6, 2024 |