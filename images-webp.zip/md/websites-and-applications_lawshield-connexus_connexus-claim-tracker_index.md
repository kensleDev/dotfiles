[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Connexus Claim Tracker

 

---

   

## Website Details

  **Live URL:** [https://claimtracker.connexus.co.uk/](https://claimtracker.connexus.co.uk/) **UAT URL:** [https://claimtracker-uat.connexus-test.co.uk/](https://claimtracker-uat.connexus-test.co.uk/)    Angular 2+ Bootstrap SCSS   

---

 

This is the Connexus Claim Tracker white-label website