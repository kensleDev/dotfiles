[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Getting the Last EW Policy Details

 

---

    

```
// Only look at policy numbers starting with EWC, not sure the code does this, need to check next time I look at itDECLARE @regNo NVARCHAR(7) = 'AD12KUD'DECLARE @vinNo VARCHAR(17) = 'WAUZZZ4G9FN072350'DECLARE @today DATE = CONVERT(DATE, GETDATE())DECLARE @renewalCutOffDate DATE = DATEADD(DAY, 30, @today)DECLARE @minimumStartDate DATE = DATEADD(YEAR, -1, DATEADD(D, -45, @today))SELECT TOP 1    cpd.POLICYNUMBER,    uvv.REGISTRNO,    pc.MILAGELMT_ID,    pc.COVERTYPE_ID,    pc.VOLXS_ID,    uvv.CURRMILEAGE,    cpd.POLICYSTARTDATE,    cpd.POLICYENDDATE,    pc.SUBSCRIPTION_ID,    uvv.ABICODE,    uvv.DATEOFREG,    uvv.VINNUMBER,    uvv.DRIVETYPE,    uvv.ENGSIZE,    uvv.MODEL,    uvv.[TYPE],    uvv.MAKE,    uvv.RATINGMODEL,    FUEL_ID = uvv.FUEL_IDFROM USER_VW_VEHDETS uvvJOIN CUSTOMER_POLICY_DETAILS cpd ON uvv.POLICY_DETAILS_ID = cpd.POLICY_DETAILS_IDJOIN USER_VW_PRODCOVR pc ON uvv.POLICY_DETAILS_ID = pc.POLICY_DETAILS_IDWHERE UPPER(uvv.REGISTRNO) = @regNo OR UPPER(uvv.VINNUMBER) = @vinNoAND cpd.POLICYENDDATE <= @renewalCutOffDateAND cpd.POLICYSTARTDATE >= @minimumStartDateAND cpd.LIVE = 1AND cpd.POLICY_STATUS_ID IN ('3AJPUL66', '3AJPUL85', '3GQ31967') -- Is a policy, lapsed or pendingORDER BY cpd.POLICYENDDATE DESC
```