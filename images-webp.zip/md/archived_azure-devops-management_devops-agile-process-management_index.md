[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# DevOps - Agile Process Management

 

---

 

Connexus uses Azure DevOps for both source control and project management. The standard "Agile" process management template built-in to DevOps has been heavily customised to best represent the software development processes implemented at Connexus.

 

## Accessing Azure DevOps Process Management

 

You can access the Azure DevOps Process Management console by navigating to the Home page of Azure DevOps, then clicking **Organisation Settings** at the bottom left, and finally selecting **Process** under *Boards* on the menu to the left.

 

## "Connexus Agile" Process

 

The **Connexus Agile** process defines the project and process management for Connexus development projects. In order to do so, it modifies and extends the default "Agile" process in several ways, described below.

 

### Work Item Types

 

The first thing to note is that the **Epic**, **Feature** and **Issue** Work Item types are disabled; they are unused in Connexus processes.

 

#### Standard "Agile" Work Item Types

 

We make use of some of the standard Work Item types available under the "Agile" process template:

 

- **User Story** - defines a customer requirement and, where possible, written as a true Agile user story
- **Task** - defines a low-level technical requirement, usually with specific implementation detail
- **Bug** - defines a bug or issue identified in the deliverable solution

 

#### Custom Work Item Types

 

Additionally, we have defined further Work Item types that represent other elements and aspects of the Connexus development process:

 

- **Technical Debt** - defines a high-level technical debt requirement; analogous to a **User Story**
- **Content** - a more specific **Task** type used explicitly to define low-level requirements to be implemented as application "content" (e.g. customer-supplied text, images etc. to be added to a CMS)
- **Observation** - a precursor to certain issues that may or may not become **Bugs**; usually raised where there is uncertainty around a potential issue

 

#### Custom Work Item Fields

 

Alongside the standard Work Item fields that come with the built-in types, we have defined additional fields to store more specific details, such as:

 

- **Customer Ref** - used where the customer has their own reference to a **User Story** or **Bug**
- **Original Estimate**, **Remaining Work** and **Completed Work** - used to define the number of hours work originally estimated, remaining and completed against several different types of Work Item

 

### Process "States"

 

The standard Work Item templates in DevOps come with a set of pre-defined **states** to represent their progress, including:

 

- **New**
- **In Progress**
- **Active**
- **Resolved**
- **Closed**
- **Removed**

 

Connexus' development process expands on these states to include additional steps. These do vary between different Work Item types, but fundamentally follow the below breakdown:

 

- **Proposed** 

- New - initial work item state
- Analysis in Progress - a BA and/or Product Owner are analysing the customer requirement
- Product Owner Approval - with the Product Owner for approval
- QA Approval - with the QA/Test team for approval
- Development Backlog - a work item that is approved for development to begin
- **In Progress** 

- On Hold - awaiting feedback or further information from the customer/BA/Product Owner
- Failed Testing - internal testing failed with the QA/Test team
- In Development - actively in development
- Peer Review - ready to be peer-reviewed
- Ready to Deploy - ready to deploy to a test environment
- Deployed - deployed to a test environment
- Ready for Testing - ready for the QA/Test team to test
- In Testing - actively in testing
- Failed UAT - external testing failed with the Product Owner/customer
- **Resolved** 

- Test Complete - all internal testing complete with the QA/Test team
- Product Owner Review - with the Product Owner/customer for review/approval
- **Completed** 

- Closed - closed; either completed or otherwise
- **Removed** 

- Removed - when the Work Item is no longer a requirement

 

## Further Reading

 

Further information on how to customise and manage Azure DevOps processes is best found in the official Microsoft documentation at:[](https://docs.microsoft.com/en-us/azure/devops/organizations/settings/work/inheritance-process-model?view=azure-devops&tabs=agile-process)

 

[https://docs.microsoft.com/en-us/azure/devops/organizations/settings/work/inheritance-process-model?view=azure-devops&tabs=agile-process](https://docs.microsoft.com/en-us/azure/devops/organizations/settings/work/inheritance-process-model?view=azure-devops&tabs=agile-process)