[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Data Dictionary

 

---

 

## Introduction

 

This article defines and describes various database tables in the Transactor database schema and their relationships.

 

## Transactor Database Table Concepts

 

### LIST_ and SYSTEM_LIST_ tables

 

Tables with the prefix **LIST_** store what would normally be referred to as *Metadata*. Almost all LIST_ tables will have a corresponding **_LINK** table which defines the many-to-many relationships between items in the associated LIST_ table and other entities such as AGENT, PRODUCT or SCHEME. The most commonly used list tables are described below:

 

| Table | Description |
| --- | --- |
| LIST_ACTIVITY | Defines a list of marketing activities. Selectable from the Marketing screen within TCAS when providing risk details for a policy |
| LIST_ACTIVITYGROUPING | Defines a relationship between LIST_ACTIVITY and LIST_CAMPAIGN entries |
| LIST_BIKE_LOCK | Defines a list of acceptable bike locks |
| LIST_CAMPAIGN | Defines a list of marketing campaigns. Selectable from the Marketing screen within TCAS when providing risk details for a policy |
| LIST_CARD_TYPE | Defines a list of credit and debit cards |
| LIST_CANCEL_REASON | Defines a list of valid policy cancellation reasons |
| LIST_COUNTRY | Defines a list of valid countries |
| LIST_COVER_TYPE | Defines a list of acceptable cover options available under the VWFS Extended Warranty product |
| LIST_DAYTIME | Defines a list of acceptable "vehicle kept" locations during the day |
| LIST_DRIVER_OPTION | Defines the different levels of cover provided under a motor insurance policy e.g. "Insured Only" or "Insured and Spouse" |
| LIST_EMPLOYERS_BUS | Defines a list of acceptable business practices or business types |
| LIST_EMPLOYMENT_STATUS | Defines a list of acceptable employment statuses |
| LIST_ENDORSEMENT | Defines a list of valid policy endorsements (conditions applied) |
| LIST_EXCESS_LEVELOI | Defines a list of acceptable indemnity cover levels available under the Excess Waiver product |
| LIST_KEEPER | Defines a list of acceptable "registered keeper" options for a motor insurance policy e.g. "Proposer" or "Spouse" |
| LIST_LAPSE_REASON | Defines a list of valid policy lapsed reasons |
| LIST_LICENCE_TYPE | Defines a list of valid driving licence types |
| LIST_MARITAL_STATUS | Defines a list of valid marital statuses |
| LIST_METHODOFCONTACT | Defines a list of valid methods of contact. Selectable from the Marketing screen within TCAS when providing risk details for a policy |
| LIST_MILEAGE_LIMIT | Defines a list of acceptable mileage limit cover options available under the VWFS Extended Warranty product |
| LIST_OCCUPATION | Defines a list of acceptable occupations |
| LIST_OFFENCE_CODE | Defines a list of official offence codes that may factor into the premium for a policy |
| LIST_OVERNIGHT | Defines a list of acceptable 'vehicle kept' locations during the night |
| LIST_PAYMENT_TYPE | Defines a list of acceptable payment types |
| LIST_PAYMETHOD | Defines a list of acceptable payment methods |
| LIST_POLICY_STATUS | Defines the list of policy statuses e.g. "Prospect" or "Lapsed" |
| LIST_PRODUCT_TYPE | Defines the list of valid insurance product types |
| LIST_RELATIONSHIP | Defines a list of valid relationships between insured parties |
| LIST_SOURCE_BUSINESS | Defines a list of valid sources of business e.g. "Email" or "Website" |
| LIST_SUBSCRIPTION_TYPE | Defines a list of acceptable subscription types available under the VWFS Extended Warranty product |
| LIST_TITLE | Defines a list of acceptable personal titles |
| LIST_VEHICLE_FUEL | Defines a list of acceptable vehicle fuel types |
| LIST_VEHICLE_GEARBOX | Defines a list of valid vehicle gearbox types |

 

 

 

| Table | Description |
| --- | --- |
| SYSTEM_LIST_DM_FILETYPE | Defines a list of valid file types that can be uploaded into the Transactor Document Manager for use as templates in Document Packs |
| SYSTEM_LIST_DM_VISIBILITY | Defines a list of valid 'visibility' conditions for Document Packs configured in the Transactor Document Manager |
| SYSTEM_LIST_EMAIL_DESTINATION | Defines a list of valid email destinations when sent from Transactor (e.g. Client, Agent, SubAgent etc.) |
| SYSTEM_LIST_POLICY_LENGTH | Defines a list of valid policy lengths |
| SYSTEM_LIST_PRODUCTTYPE | Defines a list of valid types of insurance product (e.g. Household, Motor, Excess Waiver etc.) |
| SYSTEM_LIST_PRODUCTTYPE_VERSION | Defines the history of entries in the SYSTEM_LIST_PRODUCTTYPE table |
| SYSTEM_LIST_VEHICLE | Defines a list of valid vehicle "types" (e.g. Make, Model, Variant, Engine size etc.) uniquely identified by official ABI codes |

 

 

 

### RATE_ tables

 

Tables with the prefix **RATE_** store rating information for certain *Insurance Products* in a 'matrix'. They should be created and managed through the Transactor **Product Modeller** tool (accessible via **TES Tool Suite**) as much as possible. Products such as **VWFS Extended Warranty** and **Lawshield Pedal Cycle** use rating tables because the rating criteria are complex enough to require a rating matrix:

 

| Table | Description |
| --- | --- |
| RATE_AUDI_RATES_V2 | Defines the premium rates for Audi Extended Warranty. Grouped by 'date ranges' identified in the RATE_EW_DATES_RANGE table |
| RATE_SEAT_RATES_V2 | Defines the premium rates for SEAT Extended Warranty. Grouped by 'date ranges' identified in the RATE_EW_DATES_RANGE table |
| RATE_SKODA_RATES_V2 | Defines the premium rates for SKODA Extended Warranty. Grouped by 'date ranges' identified in the RATE_EW_DATES_RANGE table |
| RATE_VW_RATES_V2 | Defines the premium rates for VW Extended Warranty. Grouped by 'date ranges' identified in the RATE_EW_DATES_RANGE table |
| RATE_VWCV_RATES_V2 | Defines the premium rates for VWCV Extended Warranty. Grouped by 'date ranges' identified in the RATE_EW_DATES_RANGE table |
| RATE_EW_DATES_RANGE | Defines the date ranges in which a group of Extended Warranty rates are applicable |
| RATE_IPTRATE | Defines the Insurance Premium Tax (IPT) rates and the dates they are valid from/to |
| RATE_LSPCYCLE_RATES | Defines the premium rates for Lawshield Pedal Cycle (Velosure) |
| RATE_LSPCYCLE_SALES | Defines the offers/sales available to Velosure customers |

 

 

 

### NAV_ tables

 

Tables with the prefix **NAV_** store all of the UI configuration required for the custom screens you see in TCAS that define the forms, fields, labels and relationships to data that allows Transactor to be infinitely configurable to accept risk data for any type of insurance product.

 

### RM_ tables

 

Tables with the prefix **RM_** store all of the data that is configurable through the Transactor **Relationship Manager** application. The most commonly used tables are described below:

 

| Table | Description |
| --- | --- |
| RM_AGENT | Defines the list of Agents as defined by us in the Transactor Relationship Manager |
| RM_AGENT_PRODUCT_LINK | Defines the relationship between Agents and Products |
| RM_AGENT_SUBAGENT_LINK | Defines the relationship between Agents and Subagents (Brokers) |
| RM_COMMISSION | Defines the individual Commission rates applied for a Partner, Agent and Subagent in a Commission Group |
| RM_COMMISSION_GROUP | Defines a group of Commissions that are applied to a Scheme |
| RM_INSURER | Defines a list of Insurers (Underwriters) as defined by us in the Transactor Relationship Manager |
| RM_INTEREST_RATE | Defines a list of Interest Rates that can be applied to a Payment Plan |
| RM_PARTNER | Defines the list of Partners as defined by us in the Transactor Relationship Manager |
| RM_PAYMENT_PLAN | Defines a list of valid Payment Plans that can be used to pay for an insurance product |
| RM_PRODUCT | Defines the list of Insurance Products as defined by us in the Transactor Relationship Manager |
| RM_PRODUCT_SCHEME_LINK | Defines the relationship between Products and Schemes |
| RM_RANGE | Defines a list of Policy Number Ranges as defined by us in the Transactor Relationship Manager |
| RM_RANGE_GROUP | Defines a group of Policy Number Ranges that are applied to a Scheme |
| RM_SCHEME | Defines the list of Schemes as defined by us in the Transactor Relationship Manager |
| RM_SCHEME_INSURER | Defines the relationship between Schemes and Insurers (Underwriters) |
| RM_SUBAGENT | Defines the list of Subagents (Brokers) as defined by us in the Transactor Relationship Manager |
| RM_VERSION | Stores the latest published version of the Relationship Manager (v6 only) |

 

 

 

### SYSTEM_DM_ tables

 

Tables with the prefix **SYSTEM_DM_** store data configurable through the **Document Configuration** section of the Transactor **TES Tool Suite** application. The most commonly used tables are described below:

 

| Table | Description |
| --- | --- |
| SYSTEM_DM_DOCUMENT | Defines a list of Document Packs as defined in the Transactor Document Manager (via TES Tool Suite) |
| SYSTEM_DM_FILE | Defines a list of Templates as defined in the Transactor Document Manager (via TES Tool Suite) |
| SYSTEM_DM_FILE_LINK | Defines the relationship between Document Packs and Templates |
| SYSTEM_DM_FORMULA | Defines the list of Document Formulae as defined in the Transactor Document Manager (via TES Tool Suite) |
| SYSTEM_DM_PRINTER | Defines printer settings for physical printing of Document Packs |
| SYSTEM_DM_VISIBILITY | Defines the Visibility preferences for Document Packs |

 

 

 

### Security/Permissions tables

 

The **SYSTEM_SECURITY_PROFILE**, **SYSTEM_ROLE** and **SYSTEM_TASK** tables store the user permissions data in Transactor.

 

### Scheme Definitions table

 

The **SYSTEM_SCHEME_DEFINITIONS** table stores the scheme definitions data in Transactor.