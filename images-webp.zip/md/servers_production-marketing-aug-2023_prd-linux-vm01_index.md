[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# PRD-LINUX-VM01

 

---

 

## Server Details

  **Server Type:** Web **IP Address:** 52.151.76.213  

---

 

Websites migrated to PRD-UBUNTU-20 in 2022 to increase security.

 

Currently hosts Connexus.co.uk and the CRM 

 

---

 

## Websites

 

- Connexus Group - [https://www.connexus.co.uk](https://www.connexus.co.uk)
- CRM - [https://crm.connexus.co.uk](https://crm.connexus.co.uk)