[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Velosure - Renewals

 

---

 

Velosure renewal invitations are automated with the built-in Transactor Renewal invite process.

 

This uses **Task Scheduler** in Windows on a nightly basis to check for policies that are due for renewal and automatically invites the renewals, which in turn triggers the automated queuing and sending of renewal invitation emails.

 

However, all renewals are currently transacted manually via TCAS.