[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Vue & Web API - Publish to Multiple Enviroments

 

---

 By default, vue-cli-service adds 3 NPM scripts to package.json, serve, build and lint, the first two of which build for development and serve up the site in the dev web server, and build for production respectively:  

```
"scripts": {
    "serve": "vue-cli-service serve",
    "build": "vue-cli-service build",
    "lint": "vue-cli-service lint"
},
```

   By adding another script adding the --mode parameter to the build command, a staging build can also be created:  

```
"staging": "vue-cli-service build --mode staging",
```

   Environment variables for different environments are setup by creating a .env file and overload files for each environment, eg .env.staging and .env.production, in the root folder (NB this is the folder where the package.json sits, not the subfolder eg src where the Vue components sit. These files consist of key/value pairs and variables which are to be accessed by Vue are prefixed VUE_APP_. The override files only specify the variables that are overridden from .env.  .env:  

```
VUE_APP_UMBRACO_ENDPOINT='https://cdn.umbraco.io'
VUE_APP_UMBRACO_PROJECT_ALIAS='dev-velosure'
```

   Entering the following in .env.staging will override only the VUE_APP_TRANSACTOR_API_ENDPOINT environment variable:   

```
VUE_APP_TRANSACTOR_API_ENDPOINT='https://lawshieldv6-api.connexus-test.co.uk/'
```

    Entering the following in .env.production will override the VUE_APP_UMBRACO_PROJECT_ALIAS and VUE_APP_TRANSACTOR_API_ENDPOINT environment variables:  

```
VUE_APP_UMBRACO_PROJECT_ALIAS='velosure'
VUE_APP_TRANSACTOR_API_ENDPOINT='https://lawshieldv6-api.lawshield.co.uk/'
```

   The variables are then used in the code as follows; this is baked into the staging or production builds but is injected at runtime in a dev serve:  

```
process.env.VUE_APP_UMBRACO_ENDPOINT
```

  

## Setting up Vue so that Visual Studio knows how to deploy it

 The vue.config.js needs to be configured to tell the publish process to copy the built Vue app to wwwroot, and also to not copy the map files to the production build: 

```
module.exports = {
    outputDir: "./wwwroot/",
    productionSourceMap: false,
    // the rest of the config
};
```

 Note that this will build the JS and CSS into the project folder so this needs adding into the .tfignore 

## Setting up .Net to include the Vue project in the deployment

 

The Staging environment needs adding to the solution:

 

1. Build -> Configuration Manager
2. In the Active solution configuration dropdown, select New
3. Name = Staging
4. Copy settings from Release
5. Ensure Create new project configurations is checked

 

Pre-build events need to be added to the web.config to transpile the TypeScript in a Release or Staging build:

 

```
<Target Name="PreBuild" BeforeTargets="PreBuildEvent">
    <Exec Command="if $(ConfigurationName) == Release (npm run build)" />
    <Exec Command="if $(ConfigurationName) == Staging (npm run staging)" />
  </Target>
```

 

The web.config file also needs modifying to copy any resource folders, the healthcheck.html and robots.txt files to the published build:

 

```
<Target Name="additional-files" Condition="'$(Configuration)' == 'Staging' Or '$(Configuration)' == 'Release'" BeforeTargets="AssignTargetPaths" DependsOnTargets="PrepareForPublish">
    <ItemGroup>
      <Content Include="EmailTemplates\**" CopyToPublishDirectory="Always"></Content>
      <Content Include="healthcheck.html" CopyToPublishDirectory="Always"></Content>
      <Content Include="robots.txt" CopyToPublishDirectory="Always"></Content>
    </ItemGroup>
  </Target>
```

 

## Setting up .Net to use multiple environments

 

The appsettings.json file can be overridden for each environment where the variables are required to be changed, so for example if the appsettings.json contains:

 

```
{
    "Logging": {
        "LogLevel": {
            "Default": "Information",
            "Microsoft": "Warning",
            "Microsoft.Hosting.Lifetime": "Information"
        }
    },
    "AllowedHosts": "*",
    "ConnectionStrings": {
        "ConnexusConfigEntities": "Server=192.168.200.113;database=ConnexusConfig_UAT;user=connexusAdmin;password=connexus@1;"
}
```

 

and this connection string is valid for dev and UAT but needs to change for production, then an appsettings.Production.json file is created as follows:

 

```
{
  "ConnectionStrings": {
    "ConnexusConfigEntities": "Server=192.168.100.118;database=ConnexusConfig;user=connexusAdmin;password=connexus@1;"
}
```

 

The override files are then loaded after the main appsettings.json in Startup.cs:

  

```
public Startup(IWebHostEnvironment environment)
{
    var builder = new ConfigurationBuilder()
        .SetBasePath(environment.ContentRootPath)
        .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
        .AddJsonFile($"appsettings.{environment.EnvironmentName}.json", optional: true)
        .AddEnvironmentVariables();
 
    Configuration = builder.Build();
}
```

  

Note that any components which load appsettings.json will also need modifying in the same way.

 

The environment is determined by the ASPNETCORE_ENVIRONMENT variable and this is not baked into the code as it is in JavaScript, therefore it needs to be setup in IIS via the web.config. Add the following lines to the web.config under <system.webServer>:

 

```
<aspNetCore processPath=".\Velosure.exe" stdoutLogEnabled="false" stdoutLogFile=".\logs\stdout" hostingModel="InProcess">
        <environmentVariables>
          <environmentVariable name="ASPNETCORE_HTTPS_PORT" value="44315" />
          <environmentVariable name="COMPLUS_ForceENC" value="1" />
          <environmentVariable name="ASPNETCORE_ENVIRONMENT" value="Development" />
        </environmentVariables>
      </aspNetCore>
```

 

And create a transformation file for Staging called web.Staging.config:

 

```
<?xml version="1.0"?>
<configuration xmlns:xdt="http://schemas.microsoft.com/XML-Document-Transform">
  <location>
    <system.webServer>
      <aspNetCore processPath=".\Velosure.exe">
        <environmentVariables>
          <environmentVariable name="ASPNETCORE_ENVIRONMENT"
                               value="Staging"
                               xdt:Locator="Match(name)"
                               xdt:Transform="Replace" />
        </environmentVariables>
      </aspNetCore>
    </system.webServer>
  </location>
</configuration>
```

 

and for Release called web.Release.config:

 

```
<?xml version="1.0"?>
<configuration xmlns:xdt="http://schemas.microsoft.com/XML-Document-Transform">
  <location>
    <system.webServer>
      <aspNetCore processPath=".\Velosure.exe">
        <environmentVariables>
          <environmentVariable name="ASPNETCORE_ENVIRONMENT"
                               value="Production"
                               xdt:Locator="Match(name)"
                               xdt:Transform="Replace" />
        </environmentVariables>
      </aspNetCore>
    </system.webServer>
  </location>
</configuration>
```

 

The transformations are applied at publish time, not build time.

 

## Setting up the Staging and Release publish options

 Right-click on the solution and click Publish Click New and select Folder, then Next and browse to the location where the deployment should live This will create a profile called FolderProfile, so it needs renaming, click Rename and enter the new profile name = Release Click Edit and select the Settings tab Choose Release from the Configuration drop-down if it is not already chosen Expand File Publish Options and check Delete all existing files prior to publish  This creates a file called FolderProfile.pubxml under Properties -> Publish Profiles and does not rename it, so this should be undone in the Pending Changes window Repeat the above for the Staging publish profile