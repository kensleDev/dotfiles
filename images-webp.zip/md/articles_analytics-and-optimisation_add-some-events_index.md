[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Add some Events

 

---

 

## Introduction

 

Google Tag Manager uses **event triggers** to fire **tags** to Google Analytics.

 

There are many types of events that can be handled, e.g.:

 

- Page View
- DOM Ready
- Clicks
- Element Visibility
- Form Submission

 

## How to setup events in Google Tag Manager

 

We will look at how to setup a click event and a visibility event.

 

### Declaring a variable for click events

 

If we want to handle any clicks that redirect to a given URL, we need to be able to access the element's URL. GTM provides an *auto-event variable* which exposes properties of the element such as its ID, classes, and as we want here, its URL.

 

1. Select **Variables** from the menu bar on the left hand side of the screen
2. Click **New** in the User-Defined Variables panel
3. Change the name from "Untitled Variable" to "element url"
4. Click the pencil in the Variable Configuration panel
5. Select**Page Elements** -> **Auto-Event Variable** in the Choose variable type dialog
6. Select "**Element URL**" from the Variable Type dropdown
7. Select "**Full URL**" from the Component Type dropdown
8. **Save**

 

### Declaring a click event trigger

 

1. Select Triggers from the menu bar on the left hand side of the screen
2. Click **New** in the Triggers panel
3. Change the name from "Untitled Trigger" to something meaningful
4. Click the pencil in the Trigger Configuration panel
5. Select **Click** -> **All Elements** in the Choose trigger type dialog
6. Select **Some Clicks** from the "This trigger fires on" radio buttons
7. Select "**element url**" from the first dropdown
8. Select "**matches Regex**" from the second dropdown
9. Enter a regular expression to represent the desired URL
10. **Save**

 

### Declaring a visibility trigger

 

1. Select Triggers from the menu bar on the left hand side of the screen
2. Click **New** in the Triggers panel
3. Change the name from "Untitled Trigger" to something meaningful
4. Click the pencil in the Trigger Configuration panel
5. Select **User Engagement** -> **Element Visibility** in the Choose trigger type dialog
6. Select **ID** from the "Selection method" dropdown
7. Enter the ID of the element you wish the event to fire on visibility as the Element ID
8. Select "**Once per page**" from the "When to fire this trigger" dropdown
9. Enter **100%** as the Minimum percent visible
10. Check Observe DOM changes
11. Select **"All visibility events**" from the "This trigger fires on" radio buttons
12. **Save**

 

### Declaring tags

 

This is the easy part as it is the same for all event types.

 

1. Select **Tags** from the menu bar on the left hand side of the screen
2. Click **New** in the Tags panel
3. Change the name from "Untitled Tag" to something meaningful
4. Click the pencil in the Tag Configuration panel
5. Select **Featured** -> **Google Analytics: Universal Analytics** in the Choose tag type dialog
6. Select **Event** from the Track Type dropdown
7. Enter a meaningful Category, eg "Button"
8. Enter a meaningful Action, eg "Click"
9. Enter a meaningful Label
10. Select "{{GA Tracking ID}}" from the Google Analytics Settings dropdown
11. Click the pencil in the Triggering panel
12. Select the trigger that fires the tag
13. **Save**

 

## Example: A click and a visibility event for the Insure With sites

 

### Declaring a click event trigger for the Get Cover Now link

 

1. Select Triggers from the menu bar on the left hand side of the screen
2. Click **New** in the Triggers panel
3. Change the name from "Untitled Trigger" to "Event - EW Get Cover Now"
4. Click the pencil in the Trigger Configuration panel
5. Select **Click** -> **All Elements** in the Choose trigger type dialog
6. Select **Some Clicks** from the "This trigger fires on" radio buttons
7. Select "**element url**" from the first dropdown
8. Select "**matches Regex**" from the second dropdown
9. Enter "/extended-warranty\/?#get-cover-now" for the regular expression
10. **Save**

 

### Declaring a visibility trigger for the quote bar

 

1. Select Triggers from the menu bar on the left hand side of the screen
2. Click **New** in the Triggers panel
3. Change the name from "Untitled Trigger" "Visibility - EW Quote"
4. Click the pencil in the Trigger Configuration panel
5. Select **User Engagement** -> **Element Visibility** in the Choose trigger type dialog
6. Select **ID** from the "Selection method" dropdown
7. Enter "**quote-bar**" for the Element ID
8. Select "**Once per page**" from the "When to fire this trigger" dropdown
9. Enter **100%** as the Minimum percent visible
10. Check Observe DOM changes
11. Select **"All visibility events**" from the "This trigger fires on" radio buttons
12. **Save**

 

### Declaring a click event tag for the Get Cover Now click

 

1. Select **Tags** from the menu bar on the left hand side of the screen
2. Click **New** in the Tags panel
3. Change the name from "Untitled Tag" to "EW Get Cover Now"
4. Click the pencil in the Tag Configuration panel
5. Select **Featured** -> **Google Analytics: Universal Analytics** in the Choose tag type dialog
6. Select **Event** from the Track Type dropdown
7. Enter "Button" as the Category
8. Enter "Click" as the Action
9. Enter "Event - EW Get Cover Now" as the Label
10. Select "{{GA Tracking ID}}" from the Google Analytics Settings dropdown
11. Click the pencil in the Triggering panel
12. Select "Event - EW Get Cover Now"
13. **Save**

 

### Declaring a tag for the quote bar visibility

 

1. Select **Tags** from the menu bar on the left hand side of the screen
2. Click **New** in the Tags panel
3. Change the name from "Untitled Tag" to "Visibility - EW Quote"
4. Click the pencil in the Tag Configuration panel
5. Select **Featured** -> **Google Analytics: Universal Analytics** in the Choose tag type dialog
6. Select **Event** from the Track Type dropdown
7. Enter "Visibility" as the Category
8. Enter "Quote Visible" as the Action
9. Enter "Visibility - EW Quote" as the Label
10. Select "{{GA Tracking ID}}" from the Google Analytics Settings dropdown
11. Click the pencil in the Triggering panel
12. Select "Visibility - EW Quote"
13. **Save**

 

## Previewing the changes

 Google Tag Manager allows the changes to be previewed before they are published 

1. Click the Preview button in the top right hand corner
2. Enter the site's URL, including the https://, in the Connect Tag Assistant to your site dialog
3. Click **Connect**
4. This opens a browser with which the developer can interact
5. Back in Tag Assistant, click **Continue**
6. As the developer interacts with the site and tags are fired, they are moved from the **Tags Not Fired** to the **Tags Fired** section
7. When you have finished previewing, click the **x** in the top left corner of Tag Assistant
8. Click **Stop Debugging**
9. Close the Tag Assistant and preview windows

 

## Publishing the changes

 Unlike Google Analytics, Google Tag Manager does not update in real time and needs to be published 

1. Click the **Submit** button in the top right hand corner
2. Enter a **Version Name** and **Version Description**
3. Click **Publish**