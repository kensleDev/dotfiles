[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Setting up a SagePay User

 

---

 

![](../images-webp/image_72.webp)

 

Password S4g3p4y

 

Username = porschepayjdoe
John
Doe
j.doe@connexus.co.uk
Password = Welcome21$
Ignore Account Privileges
My Sage Pay Access, check:
Search
Terminal
Default Landing page:
Check Terminal

 

Email the user, I strongly suggest you should change your password the first time you login