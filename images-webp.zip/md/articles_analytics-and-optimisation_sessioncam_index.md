[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# SessionCam

 

---

 

The VWFS "Insure with" and Velosure websites use a 3rd party analytical monitoring tool called **SessionCam,**which takes recordings of user interactions with these websites. It allows us to playback user interactions in real-time and provides analytical data based on the recordings, such as:

 

- Heat maps
- "Struggle" scores
- Errors encountered
- Funnels

 

You can access SessionCam at: [https://console.sessioncam.com/](https://console.sessioncam.com/)