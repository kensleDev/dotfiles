[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# EW - Useful Stored Procedures

 

---

 

****Due to our set up and how transactor does renewals. We had to jump through many hoops in order to achieve the FCA emails.

 

Below are a list of store procedures that have been created in order to achieve this.

 

- CONNEXUS_RENEWAL_POLICY_QUOTES_UPDATES_SP

 

This finds what policies are up for renewal and will shift their milieage and rate to day one. It will also create a log in the notes of the policy of what has changed. This procedure will run every day of a SQL Server agent job called

 

- UPDATE_POLICY_RENEWAL_QUOTES.

 

If the job fails we will be notified by email

 

- CONNEXUS_RENEWAL_PREMIUM_FCA

 

This will get our renewal premium from the renewal record (Policy status 3AJPUL79) that is created in the CUSTOMER_POLICY_DETAILS table upon on running the renewal invite process.

 

- CONNEXUS_RENEWAL_PREVIOUS_PREMIUM_FCA

 

This will get the previous premium for the emails. As the current policy is still live upon renewal. Through which we can get the current premium

 

- CONNEXUS_RENEWAL_PREMIUM_END_YEAR CONNEXUS_RENEWAL_POLICY_START_DATE CONNEXUS_RENEWAL_POLICY_END_DATE

 

Due to how auto renewals work we need get our start and end year from the current live policy.

 

Auto renewal goes off the renewal record which shifts the policy to be the new policy. So the start and end will change. Therefore we cannot just pass the policy start and end dates into our document formulas

 

- CONNEXUS_RENEWAL_FIRST_MONTHLY_EW_DDI_PREMIUM_FCA
- CONNEXUS_RENEWAL_OTHER_MONTHLY_EW_DDI_PREMIUM_FCA

 

These get our first and monthly payments that match up with what is quoted on the website so they now all matched! We now know how transactor calculates the break down which I will send in a different email.

 

#### Helper Procedures

 

In order to speed of the renewal process and to avoid having to do thing manually. Which is very time consuming. I Created a few helper procedures in order to update records and return values. These I believe could be useful to whole team.

 

- CONNEXUS_RENEWAL_TEST_PAY

 

This will return the first and monthly payment for a specific premium value passed in

 

- CONNEXUS_UPDATE_EMAIL

 

This will update a user’s email by passing the policy number and the email we want to change to in

 

- SP_CANCEL_RENEWAL_INVITE

 

This will cancel the renewal invite that has been sent. From testing this saved having to go in and undo everything by hand.

 

#### Reporting

 

Now the whole Renewals process is automated. We have daily reports that need to go out. As transactor cannot generate the Renewal Audit Report daily. We have get it ourselves and email out.

 

- CONNEXUS_Automated_EW_Report_Renewal_Audit
- CONNEXUS_Automated_Report_Renewal_Audit

 

These store procs run the same transactor store procedure that runs for a renewal audit but for our specific date range.

 

CONNEXUS_Automated_EW_Report_Renewal_Audit does a bit more as it is for Extended Warranty. As we have shifted the mileage and subscription. It is useful to have this in the report.

 

- CONNEXUS_EMAIL_VW_EW_REPORT This will run the reporting store procs and email them out to development as csv text file. Which can then be imported to Excel.