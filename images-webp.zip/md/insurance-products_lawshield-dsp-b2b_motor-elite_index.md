[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Motor Elite

 

---

 

Our Motor Legal Protection product provides customers with an exceptional claims management service, peace of mind and a hassle-free solution following a non-fault accident. We provide up to £100,000 legal expenses cover and £10,000 cover for Motor Prosecution Defence.

 

Motor Elite is also referred to as Motor Legal Protection.

 

## Product Details

  **Product Reference:** MRTREAM **Product Type Id:** 671  

---

 

## Schemes

 

- [Motor Elite AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite/motor-elite-amtrust/)
- [Motor Elite Commercial AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite/motor-elite-commercial-amtrust/)
- [Motor Elite Fleet AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite/motor-elite-fleet-amtrust/)
- [Motor Elite Fleet Claims Management 1-10 Vehicles AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite/motor-elite-fleet-claims-management-1-10-vehicles-amtrust/)
- [Motor Elite Fleet Claims Management 11-20 Vehicles AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite/motor-elite-fleet-claims-management-11-20-vehicles-amtrust/)
- [Motor Elite Fleet Claims Management 20+ Vehicles AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite/motor-elite-fleet-claims-management-20-vehicles-amtrust/)
- [Motor Elite Trade with Claims Management AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite/motor-elite-trade-with-claims-management-amtrust/)
- [Motor Legal Protection Farm AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite/motor-legal-protection-farm-amtrust/)
- [Motor Elite AmTrust - Classic 5 Unit Policy](/insurance-products/lawshield-dsp-b2b/motor-elite/motor-elite-amtrust-classic-5-unit-policy/)
- [Motor Elite AmTrust - Classic 10 Unit Policy](/insurance-products/lawshield-dsp-b2b/motor-elite/motor-elite-amtrust-classic-10-unit-policy/)

 

---