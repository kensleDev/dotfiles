[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# DSP - Add New Broker Login

 

---

 

TGSL stores user accounts in a hierarchy of:

 

- **Partner** - For DSP this is always **Lawshield UK Ltd** 

- **Agent** - For DSP this is always **Lawshield Wholesale** 

- **SubAgent** - This level represents the broker. If it does not already exist in Transactor it must be created within the Transactor Relationship Manager as below, copying settings similar to those for existing DSP Subagents.
N.B. This will create a row in the database table **RM_SUBAGENT** with a unique GUID (subagent_id). If this subagent is then recreated in another environment (e.g. is created in both DEV and LIVE databases) then ideally the GUID from one system must be copied across to the other, but this is not mandatory.  ![](../images-webp/image_2.webp)  The subagent must be added to the DSP codebase *enum*and within the database **LIST_CEL_SUBAGENT** and **LIST_CEL_SUBAGENT_LINK**
For more info on this please refer to [DSP - Add New Broker](/archived/indivual-articles-archived/dsp/dsp-add-new-broker/)
- **Operators** - Each broker (subagent) can have many logins, and these are set up on the Transactor server in the TES Tool Suite > User Administration > Operator Maintenance > Add. Add details similar to the example below. The password should have a capital letter and a number, and the email and login ID should match. (The system uses the login as the default email address of the user, and so needs to be an email address).
- Ensure you add a Role for the broker, so you can configure the Role to have access to the required Products. E.g. look at Eastwood settings.![](../images-webp/image_3.webp)