[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Deployment Issues - Insurewith sites

 

---

 

As the insurewith sites get more complex and each becomes slightly more unique there are settings that can be easily overlooked during a large deployment. 

 

- Env.js file ( scripts/connexus/env.js). This holds configuration for GlobalPay settings essentially selecting between live and sandbox. If this is set incorrectly the GlobalPay hpp wil give a 506/508 error complaining that the MERCHANTID is wrong.
![](../images-webp/image_21.webp)
- SEAT codebase has some extra code to allow the alternative brand 'CUPRA' to be displayed. The webconfig file has a setting for BRANDALTERNATE. If this is missing, the extended warranty regplate lookup becomes dormant.
- In order to alleviate the issue with globalpay/transactor where a payment is taken but Transactor fails to incept a policy, there is a chunk of code that allows retries and specifies the time between retries. This may need to be added each deploy. The code lives in the Views\ExtendedWarranty\**PaymentProcessing.cshtml** view file
![](../images-webp/image_22.webp)