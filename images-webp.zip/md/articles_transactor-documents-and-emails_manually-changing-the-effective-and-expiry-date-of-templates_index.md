[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Manually Changing the Effective and Expiry Date of Templates

 

---

 

 

 

```
SELECT TOP 10 * FROM SYSTEM_DM_FILE --SYSTEM_DM_DOCUMENT for documentsWHERE FILE_NAME like 'SEAT_ddi-ew-policy-terminated-failed-contact-51%'UPDATE SYSTEM_DM_FILESET EXPIRY_DATE = '2099-03-16 08:45:00.000'WHERE FILE_ID = 1134AND FILE_VERSION_ID = 9UPDATE SYSTEM_DM_FILESET EFFECTIVE_DATE = '2021-03-16 08:46:00.000', EXPIRY_DATE = '2099-03-16 09:00:00.000'WHERE FILE_ID = 1134AND FILE_VERSION_ID = 9
```