[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Connexus Medical Appointments

 

---

   

## Website Details

  **Live URL:** [https://www.connexusmedicalappointments.co.uk](https://www.connexusmedicalappointments.co.uk) **UAT URL:** []()      

---

 

Also known as CMA, this static site is primarily business facing used to promote our medical services to the insurance and legal sectors. Generally we receive a lot of enquiries from doctors who want to join our panel of experts.

 

| URL | https://www.connexusmedicalappointments.co.uk |
| --- | --- |
| Admin URL | N/A |
| CMS | N/A |
| PHP version | ~7.2 |
| Location | prd-ubuntu-20.04 |
| Database location | N/A |
| SSL Cert | From IT on prd-ubuntu-20.04 |
| SSL Expires | April 28, 2024 |