[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# React Basics

 

---

 

## React is a view library

 

React is not a hammer so don't treat every problem as if it's a nail.

 

React has no reason to know of business logic so create a class that sits alongside the component which holds the business logic. The provider therefore only deals with state and expose a function for updating state, and the constructor of the service class takes the context as a parameter; the service layer can therefore use this delegate to update state.

 

Note that if following this pattern, components must be functional as the solution requires a hook to get the context. You may think that the componentDidMount lifecycle hook in a class-based component. You would be wrong; context is asynchronous and what you will get back is a standard JavaScript object. However the useContext hook does return the expected context object.

 

## State management

 

React has two types of component, functional components which traditionally have been stateless, and class-based components which have local state.

 

Until recently there have been two main ways of sharing state between components, prop drilling which means that a component passes its state to a child component which receives it as props, or using a third party state management library, commonly Redux. Redux is complex and expensive in terms of development time, and there is a school of thought that would say it is dead. It is not, but we are not looking to use it as yet; it has been said that Redux is like glasses, you will know when you need it.

 

A third way of sharing state was the experimental, and now legacy, Context API. This was unstable and was not recommended, but as of React 16.x there is a new Context API and the legacy version will be removed in a future version. This is now the preferred state management tool.

 

## Updating state

 

State is not updated directly using a JavaScript assignment statement as this will not trigger a re-render; instead it is updated via the setState function. The first overload that a developer is likely to encounter takes an object as a parameter:

 

#### File Name: setStateExample1

 

```
setState({ firstName: 'Adrian' });
```

 

This would update the firstName property in state to "Adrian".

 

**setState is asynchronous** so subsequent lines of code can not expect to access the updated state. Calls to setState are also batched together so assuming that the counter variable in state holds the value 0 and the following code were run:

 

#### File Name: setStateExample2

 

```
setState({ counter: this.state.counter + 1 });
setState({ counter: this.state.counter + 1 });
```

 

Then when the process has completed the value of the state's counter property will be 1, as the value in state at the start of the batch will be used as the initial state and the second setState will do the same assignment as the first. However setState can take a function rather than an object, and the following code would set the state's counter property to 2 as expected, as the functions cannot be batched:

 

#### File Name: setStateExample3

 

```
this.setState((prevState) => {return {counter: prevState.counter + 1};})
this.setState((prevState) => {return {counter: prevState.counter + 1};})
```

 

This does not mean however that code following these statements can access this.state.counter and expect it to be 2. Let us not forget that setState is asynchronous; this does not change when passing in a delegate. However another overload of setState accepts a callback as a second parameter, this is only called when the code is run and so the following example will show counter = 1 assuming that it was 0 prior to setting state:

 

#### File Name: setStateExample4

 

```
setState({ counter: this.state.counter + 1 }, () => showCounter());

showCounter = () => {
	alert(this.state.counter);
}
```

 

## The new Context API

 

The new Context API introduced in React 16.x uses a Provider/Consumer pattern.

 

A default state is declared and a context created by calling createContext; this can take a default state or null as a parameter. A context has a provider and a consumer.

 

The provider is a class component which has a state, props, a render function and in the pattern I am recommending just has one other function to update state.

 

The render function will return a context.Provider passing state including the updateState function as props named value, and the provider's props, here destructured into an object named children, wrapped in the provider. The following example is a simple provider with three properties in its state and an updateState function:

 

#### File Name: src/context/JourneyProvider.tsx

 

```
import * as React from 'react'
import { JourneyState } from './JourneyState'

const DefaultState: JourneyState = {
    forename: null,
    surname: null,
    age: null
}

export const JourneyContext = React.createContext(null)

export class JourneyProvider extends React.Component {
    // Set the default state on the class to the same default state as the context initialisation above
    state = DefaultState

    render() {
        const { children } = this.props
        const { forename, surname, age } = this.state

        return (
            <JourneyContext.Provider
                value={{
                    forename: forename,
                    surname: surname,
                    age: age,
                    updateState: this.updateState
                } as JourneyState}
            >
                {children}
            </JourneyContext.Provider>
        )
    }

    updateState = (stateObject: object, callback?: () => void): void => {
        this.setState(stateObject, callback);
    }
}
```

 

The consumer is returned by a component. It can access the context by wrappinging a JavaScript function which takes the context as a parameter and returns JSX. The following example uses a hook to access the context and news up a "service layer" before returning the consumer which can then access the "service layer". Note that the hook is not required for the consumer to access the context, it available to the consumer by being passed in as a parameter:

 

#### File Name: src/components/JourneyStep1/index.tsx

 

```
import * as React from 'react'
import { JourneyContext } from '../../context/JourneyProvider';
import { JourneyStep1Service } from './journeyStep1Service'
import { JourneyState } from '../../context/JourneyState';

function JourneyStep1Component() {
    let journeyContext: JourneyState = React.useContext(JourneyContext);
    let journeyStep1Service = new JourneyStep1Service(journeyContext);

    return (
        <JourneyContext.Consumer>
            {(context: JourneyState) => (
                <>
                    <div>
                        <label htmlFor="forename">Forename</label>
                        <input
                            id="forename"
                            name="forename"
                            value={context.forename || ''}
                            onChange={event => context.updateState({ forename: event.target.value })}
                            onBlur={event => journeyStep1Service.validateName()}
                        />
                    </div>

                    <div>
                        <label htmlFor="surname">Surname</label>
                        <input
                            id="surname"
                            name="surname"
                            value={context.surname || ''}
                            onChange={event => context.updateState({ surname: event.target.value })}
                            onBlur={event => journeyStep1Service.validateName()}
                        />
                    </div>

                    <div>
                        <label htmlFor="age">Age</label>
                        <input
                            id="age"
                            name="age"
                            value={context.age || ''}
                            onChange={event => context.updateState({ age: Number(event.target.value) })}
                        />
                    </div>
                </>
            )
            }
        </JourneyContext.Consumer>
    )
}

export default JourneyStep1Component
```

 

JourneyStep1Service referred to above is the "service layer" class containing the business logic:

 

#### File Name: src/components/journeyStep1/journeyStep1Service.ts

 

```
import { JourneyState } from '../../context/JourneyState'

export class JourneyStep1Service {
    forenameIsValid: boolean = false;
    surnameIsValid: boolean = false;
    context: JourneyState;

    constructor(context: JourneyState) {
        this.context = context;
    }

    validateForename = () => {
        this.forenameIsValid = this.context.forename.length > 0;
    }

    validateSurname = () => {
        this.surnameIsValid = this.context.surname.length > 0;
    }

    validateName = () => {
        this.validateForename();
        this.validateSurname();
    }
}
```

 

In order to use a consumer, the component were it is declared must be rendered within a provider element. In this example the component is rendered in a view:

 

#### File Name: src/pages/JourneyStep1/index.tsx

 

```
import * as React from 'react'
import { Link } from 'react-router-dom'

import JourneyStep1Component from '../../components/journeyStep1'

function JourneyStep1() {
    return (
        <React.Fragment>
            <JourneyStep1Component />
            <Link to={`/step2`} className="btn">Step 2</Link>
        </React.Fragment>
    );
}

export default JourneyStep1
```

 

which in turn is rendered within the Provider element on the main page. This example also uses react-router:

 

#### File Name: src/index.tsx

 

```
import * as React from 'react'
import { render } from 'react-dom'
import { BrowserRouter as Router, Route } from 'react-router-dom'
import JourneyStep1 from './pages/JourneyStep1';
import JourneyStep2 from './pages/JourneyStep2';
import { JourneyProvider } from './context/JourneyProvider';

const rootElement = document.getElementById('root')
render(
    (
        <JourneyProvider>
            <Router>
                <div>
                    <Route path="/" component={JourneyStep1} />
                    <Route path="/step2/" component={JourneyStep2} />
                </div>
            </Router>
        </JourneyProvider>
    ), rootElement)
```

 

## Hooks

 

I briefly mentioned hooks; these were introduced into React at version 16.8.0 and provide state and other React features which were previously only available in class-based components to functional components. Facebook consider this to be the way forward although they **currently** have no plans to deprecate class-based components.

 

Examples of hooks are micro-state; the following example is a wrapper around local state which provides a means to access and set a single property in local state, passing 0 in this case as the initial value:

 

#### File Name: counter.tsx

 

```
function Counter() {
    const [count, setCount] = useState(0);

    return(
        <div>
			{count}
			<button onClick={() => setCount(count + 1)}>Increment</button>
        </div>
    )
}
```

 

Effect hooks (useEffect) let you perform side effects in function components and can be considered as a combination of componentDidMount, componentDidUpdate and componentWillUnmount. There are two types of side effects, those that require a clean-up before unmounting and those that don't.

 

The hook we used above is useContext which gives access to the context within a functional component.

 

## React-router

 

The example above also used react-router; be sure to install and import react-router-dom rather than react-router as the former is specific to working with the DOM.

 

The main HTML renders BrowserRouter aliased as Router, which wraps two routes. The router will process the routes from top to bottom and render the component (or in our case view) whose path attribute matches the browser's URL. The exact attribute can also be specified in which case the path attribute must match the URL exactly.

 

We also saw routing in use on the page where the Link directive was used to create a hyperlink redirecting to '/step2' which the router will then use to render page 2.

 

## Tips for AngularJS developers

 

AngularJS has built-in HTML directives, React does not. For example:

 

Handle onClick instead of ng-click

 

The equivalent of ng-class can be achieved by wrapping the class definition in JavaScript and using a ternary operator, for example:

 

#### File Name: ngClassEquivalent

 

```
className={"btn " + (context.useSingle ? ' active' : '')}>
```

 

The equivalent of ng-show can be achieved by wrapping the content of what would be the ng-show in JavaScript and using the && operator, as in the following example:

 

#### File Name: ngShowEquivalent

 

```
{context.hasError && <label className="error">The value is out of range</label>}
```

 

To achieve the same as ng-hide, do the same but negate the condition with a !