[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Claim Tracker Timeline Structure

 

---

 

The timeline is constructed by using a tree structure in memory and is represented as a tree. The visual representation however uses the visual language of **branches**from the **trunk**.

 

The trunk refers to the main linear stage at the centre of the timeline. 

 

To illustrate, here is an example:

 

![](../images-webp/image_66.webp)

 

This is constructed from a tree that looks like this:

 

![](../images-webp/image_67.webp)

 

The green highlighted stages represent the **trunk**. “Solicitor’s File Opened” and “Engineer Inspected” both share the same parent, “Engineer Instructed”. This can appear counter-intuitive due to the visual layout, as “Solicitor’s File Opened” and “Engineer Instructed” are aligned vertically, however as “Solicitor’s File Opened” is **dependent** (in the animation and also the layout) on “Engineer Instructed”, the parent-child relationship still holds. 

 

This Diagram shows how the various properties are used to construct the timeline visually.

 

![](../images-webp/image_68.webp)

 

Here’s an example:

 

![](../images-webp/image_69.webp)

 

**Personal Case manager assigned**:

 

**BranchLevel**: 0, **BranchFromParentType**: BranchLinear, **PositionFromTrunk**: PositionTrunk

 

**Solicitor’s File Opened**:

 

 **BranchLevel**: 1, **BranchFromParentType**: BranchUpFromParent, **PositionFromTrunk**: PositionUp

 

**Repair Authorised**:

 

 **BranchLevel**: 3, **BranchFromParentType**: BranchUpFromParent, **PositionFromTrunk**: PositionTrunk

 

A full detailed example:

 

![](../images-webp/image_70.webp)

 

![](../images-webp/image_71.webp)

 

**Personal Case Manager Assigned**:

 

**BranchLevel**: 0,

 

**BranchFromParentType**: BranchLinear,

 

**PositionFromTrunk**: PositionTrunk

 

**Engineer Instructed**:

 

 **BranchLevel**: 1,

 

**BranchFromParentType**: BranchLinear,

 

**PositionFromTrunk**: PositionTrunk

 

**Engineer Inspected**:

 

 **BranchLevel**: 2,

 

**BranchFromParentType**: BranchLinear,

 

**PositionFromTrunk**: PositionTrunk

 

**Repair Authorised**:

 

**BranchLevel**: 3,

 

**BranchFromParentType**: BranchLinear,

 

**PositionFromTrunk**: PositionTrunk

 

**Estimated Completion**:

 

 **BranchLevel**: 4,

 

**BranchFromParentType**: BranchLinear,

 

**PositionFromTrunk**: PositionTrunk

 

**Repair Completed**:

 

 **BranchLevel**: 5,

 

**BranchFromParentType**: BranchLinear,

 

**PositionFromTrunk**: PositionTrunk

 

**Liability Admitted**:

 

**BranchLevel**: 1,

 

**BranchFromParentType**: BranchUpFromParent,

 

**PositionFromTrunk**: PositionUp

 

**Solicitor's File Opened**:

 

 **BranchLevel**: 2,

 

**BranchFromParentType**: BranchDownFromParent,

 

**PositionFromTrunk**: PositionDown

 

**Date Hire Instructed**:

 

**BranchLevel**: 3,

 

**BranchFromParentType**: BranchUpDoubleFromParent,

 

**PositionFromTrunk**: PositionUpDouble

 

**Hire vehicle out**:

 

**BranchLevel**: 4,

 

**BranchFromParentType**: BranchLinear,

 

**PositionFromTrunk**: PositionUpDouble

 

**Hire vehicle back**:

 

 **BranchLevel**: 5,

 

**BranchFromParentType**: BranchLinear,

 

**PositionFromTrunk**: PositionUpDouble