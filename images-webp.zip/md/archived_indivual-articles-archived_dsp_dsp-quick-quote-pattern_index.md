[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# DSP - "Quick Quote" Pattern

 

---

  

## DSP Scheme File "Quick Quote" Pattern

 

This article seeks to define a pattern created by the lord and master of all Transactor with the intention of allowing a scheme to give a quick quote before a user provides a risk.

 

The idea behind this is reasonably straightforward. Imagine a product with a single question as a dropdown selection of options. Each selection has its own Net Premium and therefore needs to be separated via schemes. Now imagine that you want to show all of the prices for that product and allow a user to select the option that suits them best. You will see this in the likes of Motor Elite (Motor Legal Protection) and Motor Elite Extra (Motor Legal Protection Extra).

 

For Motor Elite Extra there is an option to define the type of hire vehicle that you want. But how do you know what you want until you have a price? Simple answer: if you haven't answered the question (defined by the value of 0) then the scheme will just give you a price. If you have answered the question and it is NOT the answer the scheme is looking for then it will decline.

 

See below for an example in the Motor Elite Extra scheme:

 

```
{For Each}Client
    {For Each}Policy_Details
        {For Each}UO_MOTOREX_SCREEN01
            {Remark}**************************************
            {Remark}Quick Quote functionality
            {Remark}**************************************
            {Equation}Equation
                {TypeWorkfield}HIREVEHICLE_ID%
                {Operator=}=
                {TypeQuestion}Client.Policy_Details.UO_MOTOREX_SCREEN01.UQ_MOTOREX_SCREEN01_HIREVEHICLE
            {End Equation}End Equation
			
            {If}If
                {Truth}Truth
                    {TypeWorkfield}HIREVEHICLE_ID%
                    {Operator<>}<>
                    {TypeConstant}0
                {End Truth}End Truth
				
                {If}If
                    {Truth}Truth
                        {TypeWorkfield}HIREVEHICLE_ID%
                        {Operator<>}<>
                        {TypeConstant}2
                    {End Truth}End Truth
                    {Decline}Decline
                        {TypeString}This scheme is only available for Hatchback Hire Vehicles
                    {End Decline}End Decline
                {End If}End If
             {End If}End If			
        {End For}End For		
    {End For}End For
{End For}End For
```