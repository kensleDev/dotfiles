[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Products, Schemes and Lines of Business (LOBs)

 

---

 

## Transactor Terminology

 

### Products

 

The Transactor Relationship Manager defines a **Product** as representing an insurance "offering" from our business to the customer (e.g. Porsche OMRMotor, Motor Elite, VWFS Extended Warranty etc.).

 

A product is associated with a specific **Product Type** (e.g. OMR Motor, Legal Expenses, Extended Warranty etc.).

 

A product can be rated by a number of **Schemes** which allows the potential for a "panel" of insurers, although in most cases at Connexus we only have one scheme per product.

 

Product data is stored in the Transactor database in the RM_PRODUCT table and can be queried as follows:

 

```
SELECT TOP 10 *FROM RM_PRODUCT
```

 

### Product Types

 

Transactor represents the insurance "risk" data as a **Product Type**. This is what defines the questions that are asked in order to collect the information required to quote and incept a particular type of policy. Transactor stores lots of information about product types, including the raw data that defines the questions to be asked within TCAS when quoting for a customer.

 

Product Type data is stored in Transactor in the SYSTEM_LIST_PRODUCTTYPE table and can be queried as follows:

 

```
SELECT TOP 10 *FROM SYSTEM_LIST_PRODUCTTYPE
```

 

### Schemes

 

The Transactor Relationship Manager defines a **Scheme** as representing a way to determine, amongst other things, a *Gross Premium* for a **Product**. Other configuration includes *Commissions* and *Policy Number ranges*.

 

Scheme data is stored in Transactor in the RM_SCHEME table and can be queried as follows:

 

```
SELECT TOP 10 *FROM RM_SCHEME
```

 

### Lines of Business (LOBs) - Scheme Files

 

Transactor defines a **Line of Business** as a way to determine a *Net Premium* for a **Scheme**. This can be implemented in a variety of different ways including communicating with third-party insurers directly or indirectly. The most common implementation at Connexus is via a **Scheme File**.

 

Scheme files are created and defined using the **TES Product Modeller** tool (yes, confusing I know) which is available via the **TES Tool Suite** application under "Product Modelling". The Product Modeller doesn't just manage the scheme files themselves, it also manages the promotion and publishing of scheme files and updates to make them available to use in Transactor.

 

Promoted Line of Business data is stored in Transactor in the SYSTEM_SCHEME_DEFINITIONS table and can be queried as follows:

 

```
SELECT TOP 10 *FROM SYSTEM_SCHEME_DEFINITIONS
```

 

## Putting it All Together

 

You can relate the data in the database tables together with JOINS to identify the relationships between **Product Types**, **Products**, **Schemes** and **Lines of Business**:

 

```
SELECT DISTINCT TOP 100 *FROM RM_PRODUCT pJOIN SYSTEM_LIST_PRODUCTTYPE pt ON p.PRODUCTTYPE_ID = pt.PRODUCTTYPE_IDJOIN RM_PRODUCT_SCHEME_LINK x ON x.PRODUCT_ID = p.PRODUCT_IDJOIN RM_SCHEME s ON x.SCHEME_ID = s.SCHEME_IDJOIN SYSTEM_SCHEME_NAME sn ON sn.PRODUCTTYPE = pt.PRODUCTTYPE_ID AND sn.SCHEMETABLE_ID = s.SCHEMETABLE_IDJOIN SYSTEM_SCHEME_DEFINITIONS lob ON sn.SCHEMENAME = lob.PRODUCTNAMEWHERE p.NAME = 'Motor Elite (AmTrust)'
```