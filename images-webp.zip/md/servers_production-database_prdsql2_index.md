[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# PRDSQL2

 

---

 

## Server Details

  **Server Type:** Database **IP Address:** 192.168.100.102  

---

 

This database server hosts one instance of **Microsoft SQL Server** and will host all *Production* Transactor v6 and non-Transactor databases going forwards.

 

Clustered with [PRDSQL1](/servers/production-database/prdsql1/).

 

Connections to this database server should be made with the following server/hosts:

 

- 192.168.100.118

 

---