[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Testing Velo data

 

---

 

Testing Velo – checking prospects/policies

Open SQL Management studio

 

Use either UAT DB - 192.168.200.113
or Live - 192.168.100.118

 

Database is called **TGSL_Lawshield_UAT** ( for UAT)

 

or **TGSL_Lawshield** for Live

 

Use the following Query 

 

(other useful scripts here too - \\172.18.226.1\Filestore\Connexus Digital\Web Development\Transactor Scripts - useful)

 

**SELECT**

 

**DATEADD(day, 0, DATEDIFF(day, 0, CPD.CREATEDDATE)) + DATEADD(day, 0 - DATEDIFF(day, 0, CPD.QUOTEGUARANTEEDATE), CPD.QUOTEGUARANTEEDATE) as DateAndTimeCreated,**

 

**cpd.SOURCE_BUSINESS_ID,**

 

**cycc.SALE_ID,**

 

**CPD.POLICYNUMBER,      /* Policy Number when policy, quote reference when prospect */**

 

**ssn.SCHEMENAME,**

 

**cycc.USEMULTIRATE,     /* Use Multi Vehicle rates */**

 

**cycc.USEELECTRICRATE,  /* Use Electric Vehicle rates*/**

 

**cycc.SPORTSCOVER,      /* Sports Cover */**

 

**cycc.WORLDWIDECOVER,   /* World wide Cover */**

 

**cycc.EUROPEANCOVER,    /* European Cover */**

 

**cycc.ROADRAGE,         /* Road Rage */**

 

**cycc.PERSONALACC,      /* Personal Accident */**

 

**cycc.CYCLEHIRE,        /* Cycle Hire */**

 

**cycc.PUBLIAB_ID,       /* Public Liability ID*/**

 

**cycc.CLOTHING_ID,      /* Clothing ID (seems to be used for Accessories) */**

 

**cycc.FAMILYCOVER,      /* Family Cover */**

 

**ssp.FULLNAME,**

 

**rmpp.name,**

 

**cycc.HOMEVALUE,        /* Total Home Value */**

 

**cycc.AWAYVALUE,        /* Total Away Value */**

 

**cycc.PREVIOUSCLAIMS,   /* Previous Claims */**

 

**lt.TITLE_DEBUG,        /* Title */**

 

**CIP.FORENAME,          /* Forename */**

 

**CIP.SURNAME,           /* Surname */**

 

**cip.EMAIL,             /* Email */**

 

**CCA.HOUSE,             /* Address */**

 

**CCA.STREET,            /* Address */**

 

**CCA.LOCALITY,          /* Address */**

 

**CCA.CITY,              /* Address */**

 

**CCA.COUNTY,            /* Address */**

 

**CCA.POSTCODE,          /* Address */**

 

**ct.TELEPHONENUMBER,    /* Telephone */**

 

**cip.DOB,               /* Date of Birth */**

 

**cpd.POLICY_DETAILS_ID, /* CUSTOMER_POLICY_DETAILS.POLICY_DETAILS_ID These two are the main links */**

 

**cpd.HISTORY_ID,        /* CUSTOMER_POLICY_DETAILS.HISTORY_ID        in the database to a customer record */**

 

**cpd.LIVE,              /* Live policy if 1 – historic policies are 0 */**

 

**cpd.PREFFEREDMETHODCONTACT_ID, /* Email only (unchecked) = 3EHPHID7, Email and Post (checked) = 3EHPHID8 - 3EHPHID8 NOT WORKING */**

 

**cpd.AllowMailFromAdmin, /* Marketing Preferences – Velosure Email */**

 

**cpd.AllowTeleFromAdmin, /* Marketing Preferences – Velosure Telephone */**

 

**cpd.AllowMailFromTP,    /* Marketing Preferences – Third Party Email */**

 

**cpd.AllowTeleFromTP,    /* Marketing Preferences – Third Party Telephone */**

 

**LPS.POLICY_STATUS_DEBUG, /* Policy Status – Policy/Prospect/Historic/Cancelled etc */**

 

**SSN.SCHEMENAME,         /* Scheme name*/**

 

**CPD.PREMIUMINCAPR,      /* Premium */**

 

**CPD.POLICYINCEPTIONDATE, /* Policy Inception Date*/**

 

**'BIKEDTLS>>>' as BIKEDTLS,**

 

**CYCB.*,                 /* Bike(s) details */**

 

**cycb.value,             /* Bike(s) Value */**

 

**'CLIENT>>>' as CLIENT,**

 

**CYCC.*,                 /* Client details */**

 

**'CLIENT_LINK>>>' as CLIENT_LINK,**

 

**CYCCL.*,                /* ID’s Details linking tables together */**

 

**'CYCLEADD>>>' as CYCLEADD,**

 

**CYCADD.*                /* Address cycles are stored at */**

 

**FROM CUSTOMER_POLICY_DETAILS as CPD with (nolock)**

 

**left join customer_policy_link as CPL with (nolock) on CPD.POLICY_DETAILS_ID=CPL.POLICY_DETAILS_ID and CPD.HISTORY_ID=CPL.POLICY_DETAILS_HISTORY_ID**

 

**left join CUSTOMER_INSURED_PARTY as CIP with (nolock) on CPL.INSURED_PARTY_ID=CIP.INSURED_PARTY_ID and CPL.INSURED_PARTY_HISTORY_ID=CIP.HISTORY_ID**

 

**left join CUSTOMER_CLIENT_ADDRESS as CCA with (nolock) on CCA.INSURED_PARTY_ID=CIP.INSURED_PARTY_ID and CCA.HISTORY_ID=CIP.HISTORY_ID**

 

**left join CUSTOMER_TELEPHONE as CT with (nolock) on CT.INSURED_PARTY_ID=CIP.INSURED_PARTY_ID and CT.HISTORY_ID=CIP.HISTORY_ID and ct.TELEPHONE_ID=(select top 1 TELEPHONE_ID from CUSTOMER_TELEPHONE where CUSTOMER_TELEPHONE.INSURED_PARTY_ID=CIP.INSURED_PARTY_ID order by TELEPHONENUMBER desc) /* Exclude blank telephone numbers if one is declared */**

 

**left join SYSTEM_SCHEME_NAME as SSN with (nolock) on SSN.SCHEMETABLE_ID=CPD.SCHEMETABLE_ID**

 

**left join SYSTEM_SECURITY_PROFILE as SSP with (nolock) on SSP.PROFILE_ID =CPD.CREATEDBY**

 

**left join LIST_POLICY_STATUS as LPS with (nolock) on LPS.POLICY_STATUS_ID=CPD.POLICY_STATUS_ID**

 

**left join LIST_TITLE as LT with (nolock) on LT.TITLE_ID=cip.TITLE_ID**

 

**left join USER_LSPCYCLE_BIKEDTLS as CYCB with (nolock) on CPD.POLICY_DETAILS_ID=CYCB.POLICY_DETAILS_ID and CPD.HISTORY_ID=CYCB.HISTORY_ID**

 

**left join USER_LSPCYCLE_CLIENT as CYCC with (nolock) on CPD.POLICY_DETAILS_ID=CYCC.POLICY_DETAILS_ID and CPD.HISTORY_ID=CYCC.HISTORY_ID**

 

**left join USER_LSPCYCLE_CLIENT_LINK as CYCCL with (nolock) on CPD.POLICY_DETAILS_ID=CYCCL.POLICY_DETAILS_ID and CPD.HISTORY_ID=CYCCL.HISTORY_ID**

 

**left join USER_LSPCYCLE_CYCLEADD as CYCADD with (nolock) on CPD.POLICY_DETAILS_ID=CYCADD.POLICY_DETAILS_ID and CPD.HISTORY_ID=CYCADD.HISTORY_ID**

 

**left join RM_PAYMENT_PLAN as RMPP with (nolock) on cpd.PAYMENT_PLAN_ID = rmpp.PAYMENT_PLAN_ID**

 

**where cpd.createddate >= dateadd(DAY,-1,getdate())**

 

**order by DateAndTimeCreated desc, CPD.POLICYNUMBER**