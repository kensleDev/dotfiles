[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Motor Elite AmTrust - Classic 10 Unit Policy

    **Underwriter:** AmTrust Europe Limited **Net Premium:** £20.00     **UAT Scheme Table Id:** 1562 **UAT Scheme File Name:** 43M4V0T3.wpd  

---

  **Live Scheme Table Id:** 1524 **Live Scheme File Name:** 43MPMBE3.wpd    

---

 

## Product

 

- [Motor Elite](/insurance-products/lawshield-dsp-b2b/motor-elite/)

 

---

 

## Scheme Description

 

The Motor Elite AmTrust **Product** has a number of different scheme files; some for variations in cover types, others are specific to particular brokers.

 

The **Motor Elite AmTrust - Classic 10 Unit Policy** scheme is currently only available to Classic Insurance Brokers. Moreover, the rating differs from most others on the Motor Elite AmTrust product. Although the Lawshield buy-in rate from the underwriter is variable per vehicle, the premium charged by Classic Insurance Brokers to their clients is fixed for specific numbers of vehicles; in this case 6-10 vehicles.

 

### Risk Data

 

We then retrieve the **Number of Vehicles** to insure from the Motor Elite AmTrust Details screen, along with the **Subagent Id** (DSP variant) and **Policy Type Id** which dictates which of the Motor Elite schemes quote or decline.

 

### Classic Insurance Brokers Check

 

The scheme checks the **Subagent Id** = 19 to ensure only Classic Insurance Brokers receive premiums from this scheme. It declines in all other cases.

 

### Risk Data Validation

 

The scheme checks that the **Policy Type Id** = 8, indicating "Classic 6-10 Vehicles", and declines in all other cases.

 

The scheme also checks that the **Number of Vehicles** is less than or equal to 10.

 

---