[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# SQL to Find and Update Documents

 

---

 

### Finding Names of Ensurance Documents

 

```
SELECT TOP 100 doc.DOCUMENT_NAME, f.FILE_DESCRIPTION, f.FILE_NAME, f.FILE_TYPEFROM SYSTEM_DM_DOCUMENT docINNER JOIN SYSTEM_DM_FILE_LINK fl ON doc.DOCUMENT_ID = fl.DOCUMENT_IDINNER JOIN SYSTEM_DM_FILE f ON fl.FILE_ID = f.FILE_IDWHERE doc.EXPIRY_DATE > GETDATE()AND F.EXPIRY_DATE > GETDATE()AND (f.FILE_DESCRIPTION LIKE '%Audi%'OR f.FILE_DESCRIPTION LIKE '%SEAT%'OR f.FILE_DESCRIPTION LIKE '%Skoda%'OR f.FILE_DESCRIPTION LIKE '%VW%'OR f.FILE_DESCRIPTION LIKE '%Volkswagen%')AND doc.DOCUMENT_NAME LIKE '%Ensurance%'--AND f.FILE_TYPE = 5GROUP BY f.FILE_TYPE, doc.DOCUMENT_NAME, f.FILE_DESCRIPTION, f.FILE_NAMEORDER BY LOWER(SUBSTRING(doc.DOCUMENT_NAME, 1, 4)), doc.DOCUMENT_NAME, f.FILE_DESCRIPTION
```

 

## Finding Documents not used in live templates

 

```
SELECT TOP 1000 *FROM SYSTEM_DM_FILE fWHERE f.EXPIRY_DATE > GETDATE()AND NOT EXISTS (SELECT * FROM SYSTEM_DM_FILE_LINK flJOIN SYSTEM_DM_DOCUMENT d ON fl.DOCUMENT_ID = d.DOCUMENT_IDWHERE fl.FILE_ID = f.FILE_IDAND d.EXPIRY_DATE > GETDATE())AND (f.FILE_NAME LIKE 'Audi-Extended-Warranty-Confirmation-of-Cover-v7-amends%'OR f.FILE_NAME LIKE 'audi_advance_notice_90_CI%'-- File list truncated for brevity)
```

 

## Manually updating the effective and expiry dates

 

Firstly identify the document to be updated, as in the following example:

 

```
SELECT TOP 10 * FROM SYSTEM_DM_FILEWHERE FILE_NAME like 'SEAT_ddi-ew-policy-terminated-failed-contact-51%'
```

 

Then update the dates, as in the following example:

 

```
UPDATE SYSTEM_DM_FILESET EFFECTIVE_DATE = '2021-03-16 08:46:00.000', EXPIRY_DATE = '2099-03-16 09:00:00.000'WHERE FILE_ID = 1134AND FILE_VERSION_ID = 9
```