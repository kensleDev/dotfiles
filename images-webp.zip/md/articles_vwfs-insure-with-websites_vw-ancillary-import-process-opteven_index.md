[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# VW Ancillary Import Process (Opteven)

 

---

 

### VW Ancillary Import Process (Opteven)

 

There is an import facility written by Connexus, that imports data from OptEven in to Transactor for VW.

 

As described by Paul Naylor:

 

We have an automated process which monitors the load of the ancillary VW MOT and key Care data supplied by Opteven. This data should be passed to us each day and it is imported into the TCAS v6 WW environment by a process written and supported by the development team.

 

The tool is on installed on the [VW Production server](/servers/).

 

 

 

The location of the tool is here:

 

D:\Connexus Apps\OptevenCsvImporter

 

 

 

![](../images-webp/image_12.webp)

 

 

 

The config file is set to run the tool each night, and produce an email output with the results.

 

 

 

The tool can be manually run with the following command in a command window:

 

 

 

"D:\Connexus Apps\OptevenCsvImporter\ConnexusApplications.OptevenCsvImporterStart.exe"

 

 

 

Once the tool is finished, it just sits there stating 'Import Data into Transactor':

 

 

 

If there is no Task Manager activity related to the process, it is OK to close the command window (or CTRL-C the application to end it in the command window).