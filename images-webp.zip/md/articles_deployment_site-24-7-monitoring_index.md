[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Site 24/7 Monitoring

 

---

 

We utilise a web site monitoring tool provided by Site 24/7 which periodically requests a **healthcheck.html** file from each of our sites in order to determine receipt of an HTTP 200 response. This indicates that the web site is available to the general public.

 

## Website Deployments

 

Whenever we make deployments to a website, we need to inform Site 24/7 that there may be potential for downtime during deployment. We can do this by configuring a **schedule maintenance** entry against the relevant site(s) in our Site 24/7 account.

 

### Log in to Site 24/7

 

You can log in to our Site 24/7 account at:

 

- [https://www.site24x7.com/](https://www.site24x7.com/)
- **Username:** websitesupport@connexus.co.uk
- **Password:** Metrics2017£

 

Once logged in, you will be presented with a list of the sites that are monitored:

 

![](../images-webp/image_9.webp)

 

### Schedule Maintenance

 

To place a site into maintenance mode, this can be done simply by selecting an immediate duration from the hamburger menu to the right:

 

![](../images-webp/image_10.webp)

 

You will then need to complete the popup form with the details of the maintenance period:

 

![](../images-webp/image_11.webp)

 

If you would like to schedule a longer period, or a particular date/time, go to... **Home** > **Schedule Maintenance** > **Schedule Maintenance** in the menu at the top-left.