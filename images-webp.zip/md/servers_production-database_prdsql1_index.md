[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# PRDSQL1

 

---

 

## Server Details

  **Server Type:** Database **IP Address:** 192.168.100.101  

---

 

This database server hosts one instance of **Microsoft SQL Server** and will host all *Production* Transactor v6 and non-Transactor databases going forwards.

 

Clustered with [PRDSQL2](/servers/production-database/prdsql2/).

 

- 1103386-SQLCLU1 

- **TGSL_Lawshield** - VWFS Transactor v6
- **FastCode** - address lookup database
- **582499_LawshieldVW** - VWFS Transactor v6
- **TGSL_DSP** - DSP Transactor v6
- **FastCode** - address lookup database
- **version7_WA02** - Porsche Transactor v7
- **WA02_Configuration** - Porsche Transactor v7 "Configuration"
- **WA02_ServiceUsage** - Porsche Transactor v7 logging
- **InsureWithPorsche** - holds Porsche Centres for Drive Away journey validation
- **InsureWithPorscheUmbrac_7-6-1** - UmbracoCMS database for Insure with Porsche
- **ConnexusConfig** - configuration database for Insure with Porsche
- Plus all the Umbraco databases, and more

 

Connections to this database server should be made with the following server/hosts:

 

- 192.168.100.118

 

---