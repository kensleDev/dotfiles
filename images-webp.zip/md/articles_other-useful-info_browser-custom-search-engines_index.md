[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Adding a Custom Search Engine to your Browser

 

---

 

This can be useful if you have a site you frequently navigate to that you then simply want to search through. It works for all manner of things from Google, Youtube and Amazon to Fedex, DHL, UPS etc.

 

you take your repeatable Url, so in the case of the example that triggered this doc:

 

[https://volkswagenapprovedrepair.co.uk/approved-crash-repair-centre-contact-info/50550](https://volkswagenapprovedrepair.co.uk/approved-crash-repair-centre-contact-info/50550)

 

Strip Off the Centre Code (or your search term) and replace with %s (in chrome and brave, this may vary on browser, consult the page youre adding the custom browser to). it will then look something like this

 

[https://volkswagenapprovedrepair.co.uk/approved-crash-repair-centre-contact-info/%s](https://volkswagenapprovedrepair.co.uk/approved-crash-repair-centre-contact-info/50550)

 

Essentially it works similarly on all browsers now, you need to go find the search engines section in your browser, it will be something like one of the below, or you can navigate the settings menus

 

| Browser | Search Engines URL |
| --- | --- |
| Chrome Browser | chrome://settings/searchEngines |
| Microsoft Edge | edge://settings/searchEngines |
| Brave Browser | brave://settings/search |

 

You'll end up with a page something like this

 

![](../images-webp/image_83.webp)

 

![](../images-webp/image_84.webp)

 

When you add you'll do something like this, where your shortcut is the sequence you will type into the omnibar (url bar) to search. For the URL take the url you modified earlier and insert it here.

 

![](../images-webp/image_85.webp)

 

In this instance above ive created a shortcut of @VW, so we type "@VW" into the omnibar, you should see it start to prompt for a custom search (in chrome it will anyway)

 

![](../images-webp/image_86.webp)

 

you can then just press tab to enter this query mode, and enter your search term

 

![](../images-webp/image_87.webp)

 

with when you press enter, will return the information like so.

 

 

 

![](../images-webp/image_88.webp)