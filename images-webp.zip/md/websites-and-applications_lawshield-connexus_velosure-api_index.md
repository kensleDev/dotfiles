[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Velosure API

 

---

   

## Website Details

  **Live URL:** [https://velosureapi.velosure.co.uk](https://velosureapi.velosure.co.uk) **UAT URL:** [https://velosureapi.connexus-test.co.uk/](https://velosureapi.connexus-test.co.uk/)    Entity Framework 6 C#   

---

 

### Summary

 

This application is a .Net core 8 Web API, which serves as the backend for the Velosure website and the [Velosure CMS](/websites-and-applications/lawshield-connexus/velosure-connexus-cms/) that uses entity framework to handle the DB connection and entity relations for articles, FAQs and Offers. 

 

### Features

 

CRUD Endpoints for Articles(/Blogs) and FAQs used by both Velosure and the CMS (Note the CMS is a front for handling the creation and editing of these entities)

 

Functionality to create and update Offers to be displayed with an optional rule set for when they are applicable (No UI for this, configuration is SQL ONLY). The rules are written in json to be used with[json-rules-engine](https://www.npmjs.com/package/json-rules-engine) which is installed in the Velosure webiste to action on this rules

 

Functionality to accept form data from Velosure to send emails via the email API.

 

Global pay integration to handle payments on Velosure (to be removed and replaced by the new Payments API)

 

Bottom line to support setting up Direct Debit payments 

 

Address / Postcode lookup using FastCode

 

### Databases

 

UAT: ConnexusCMS-192.168.200.113

 

Live: ConnexusCMS-Server=192.168.100.118