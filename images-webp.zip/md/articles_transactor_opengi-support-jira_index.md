[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# OpenGI - Support (Jira)

 

---

 

We have a dedicated support account at OpenGI that can be accessed here: [Open GI Service Desk](https://servicedesk.opengi.co.uk/servicedesk/customer/portals).

 

Credentials are:

 

- **U:** development@connexus.co.uk
- **P:** R3dDr4g0n8