[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Disallow API

 

---

   

## Website Details

  **Live URL:** [http://disallowapi.connexus.rackspace](http://disallowapi.connexus.rackspace) **UAT URL:** [https://disallowapi.connexus-test.co.uk/](https://disallowapi.connexus-test.co.uk/)    .NET Core 6 C# Entity Framework Core   

---

 

#### Summary

 

This application is a dot net 8 API, the API documentation can be found on it's [swagger page](https://disallowapi.connexus-test.co.uk/swagger/index.html).

 

The purpose of this API to block specified users from being able to quote on our websites, if we think they are abusing our system. This is done by matching on:

 

- Email only
- Telephone only
- Address Line 1 and Postcode
- Surname, forename and postcode

 

If one or more of the above are matched, we don't quote. Instead we refer the user with a special quote ref in the following format xxx/xxx/xxx/REF, the key bit being that it ends in REF which the call centre staff will be able to use to recognise a blocked user.

 

The backing database holds more than just the blocked user records, it also contains audits for when and why that record has been updated through [the disallow UI](/websites-and-applications/lawshield-connexus/disallow-ui/) and user access logs which will be automatically written to the database when a matching user has been found and referred.

 

To easily limit / track the usage of the UI, we have built a custom login system specifically for this the disallow UI, which is also stored and handled through this API, as well as account creation we have forgotten password links, which both use the [email api](/websites-and-applications/lawshield-connexus/email-api/) to sent an email to the user with there randomly generated password (which they'll have to update on login.)

 

Any request to this API is gated by an API key which can be found in the appsetting.json for this application.

 

#### Databases

 

Live: DisallowList -192.168.100.118

 

UAT: DisallowList - 192.168.200.113

 

#### Intergrations

 

Currently the V6 API and the insureWithPorsche site are integration with API and are currently only enabled in UAT