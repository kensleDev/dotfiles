[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Connexus ExceptionHelper and ExecResponse

 

---

 

## Introduction

 

When different software systems or application layers communicate with each other, there is the potential for the called code to throw exceptions that aren't handled in the calling code. These can eventually bubble up to the user interface and cause the user to see unexpected behaviour or messages (such as YSOD!).

 

The Connexus codebase makes heavy use of a pattern that guarantees a response to calling code with flags and additional data indicating success or failure and the reasons for the failure. This serves two main purposes:

 

1. It persuades the calling code to handle any failures in code it has called to
2. It provides for automatic logging of all exceptions thrown when using the pattern

 

Ultimately, this results in better code quality because it persuades developers to implement exception handling at the point where the context is known, and therefore more detailed error messages and responses can be defined.

 

## Important Classes

 

### ExceptionHelper.cs

 

**ExceptionHelper** is a class that defines several different public methods that implement this 'guaranteed response' pattern. At a high level, these methods are simply wrappers around the framework **try-****catch-finally** pattern; they force any code provided to them as a delegate to run inside a **try-catch** block, optionally executing a **finally** delegate if provided.

 

What these methods add to the default framework **try-catch-finally** is that they *handle all exceptions*. None of the methods in this class will ever throw an exception to the calling code; instead returning an instance of an object that informs the calling code that an exception was encountered, including the details of that exception.

 

### ExecResponse.cs

 

**ExecResponse** is the class defined to contain the 'guaranteed' response from calls to methods on the **ExceptionHelper** class. There are two implementations of this class:

 

#### ExecResponse

 

The default implementation of **ExecResponse** has three properties:

 

- ErrorCode 

- An **int** property designed to hold a unique code identifying the specific error or exception encountered
- Message 

- A **string** property to allow the called code to define a user-readable message indicating what error or exception occurred, and why
- Success 

- A **bool** property indicating whether the called code executed successfully or not

 

```
public class ExecResponse
{
	public int ErrorCode;
	
	public string Message;
	
	public bool Success;

	public ExecResponse(int errorcode = 0, string message = "", bool success = true)
	{
		this.ErrorCode = errorcode;
		this.Message = message;
		this.Success = success;
	}
}
```

 

#### ExecResponse<T>

 

The secondary implementation, and the one used more often, is the **ExecResponse<T>** generic implementation. This inherits the properties and constructors of the default **ExecResponse** but introduces a fourth generic **T** property to hold any data that is to be returned:

 

- Value 

- A generic **T** property that allows the called code to define a *return value* to the caller

 

```
public class ExecResponse<T> : ExecResponse
{
	public T Value;

	public ExecResponse(T value, int errorcode = 0, string message = "", bool success = true)
	    : base(errorcode, message, success)
	{
		this.Value = value;
	}
}
```

 

## Implementation

 

Consider the following example:

 

We have an ASP.NET WebAPI application responsible for looking up details of a vehicle based on a VRM. The application appropriately splits the WebAPI implementation and the business logic for looking up the details of a vehicle into separate layers.

 

### Without ExceptionHelper

 

If we were to implement the above without the **ExceptionHelper** pattern, you would expect the code to look something like this:

 

**WebAPI Controller**

 

```
public class VehicleLookupController : Controller
{
	private readonly IVehicleLookupService _vehicleLookupService;

	public VehicleDetails LookupVehicleDetails(string vrm)
	{
		return _vehicleLookupService.LookupVehicleDetails(vrm);
	}
}
```

 

**Business Logic class**

 

```
public class VehicleLookupService
{
	public VehicleDetails LookupVehicleDetails(string vrm)
	{
		if (String.IsNullOrWhiteSpace(vrm))
			throw new ArgumentException("vrm");
		
		/// business logic to look up vehicle details
		
		return new VehicleDetails();
	}
}
```

 

The problem with the above code is that it is possible for the business logic class to throw exceptions that aren't handled in the WebAPI controller. This will result in the WebAPI action method returning an HTTP 500 error to the calling code, with no information as to why the call to our WebAPI application failed.

 

### With ExceptionHelper

 

We want to ensure the calling code always receives an HTTP 200 response from our WebAPI application, with details about the success or failure of the lookup in order that the calling code can handle all eventualities and present the most appropriate feedback to the user.

 

In order that the WebAPI layer can always provide either a successful or failed response to the calling code, we implement the **ExceptionHelper** pattern and return an **ExecResponse** instance every time. The biggest change in implementing this involves providing the existing business logic to an **ExceptionHelper** method as a *delegate* Action or Func<TIn, TOut>:

 

**WebAPI Controller**

 

```
public class VehicleLookupController : Controller
{
	private readonly IVehicleLookupService _vehicleLookupService;

	public ExecResponse<VehicleDetails> LookupVehicleDetails(string vrm)
	{
		return _vehicleLookupService.LookupVehicleDetails(vrm);
	}
}
```

 

**Business Logic class**

 

```
public class VehicleLookupService
{
	private readonly ExceptionHelper _exceptionHelper;

	public ExecResponse<VehicleDetails> LookupVehicleDetails(string vrm)
	{
		return _exceptionHelper.TryCatch(errorCode: (int)Errors.FailedToLookUpVehicleByVrm,
			code: () => {
				if (String.IsNullOrWhiteSpace(vrm))
					throw new ArgumentException("vrm");
				
				/// business logic to look up vehicle details
				
				return new VehicleDetails();
			});
	}
}
```

 

With this small modification the feedback to any calling code, and therefore the end-user, is much improved and any exceptions thrown by the business logic are automatically logged by the **ExceptionHelper** class.

 

## Previous Incarnation

 

It is important to note that the **ExceptionHelper** has evolved over time to enhance its usefulness in the Connexus codebase; the documentation above considers the current implementation.

 

In its previous incarnation, the **ExceptionHelper** class was *static* meaning its functionality could be called directly from the class without an instanced object. This worked fine for the primary purpose of guaranteeing a response to calling code, but it lacked severely in logging of exceptions; it was actually assisting in hiding exceptions and thus hindering any investigations into issues.

 

This previous incarnation exists in many of the solutions at Connexus; when appropriate it should be upgraded to the latest version, though this is likely to be a large refactoring task.