[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Adding Conditional Content to HTML Emails

 

---

 

Adding conditions using the below approach will create the conditions in the **Personalizations** -> **Condtions**section of the email setup step. Conditions will only become visible and editable after they have been added to the HTML using the **Edit the source**section.

 

**Defining a condition through an HTML file**
When coding or importing your own HTML, it is possible to define a condition by adding the attribute data-actito-if= in the email section for which you want to create the condition.

 

This implies only establishing the association between the condition variable and the relevant HTML section. For example: data-actito-if=${condition1}

 

You will then need to set the parameters for the different criteria through the Actito interface, via the Personalizations tab (cf. previous section). It is not possible to code the parameters directly on the HTML file.

 

```
Example: conditions on an td tag<td data-actito-if=${condition1} align="left"></td>
```