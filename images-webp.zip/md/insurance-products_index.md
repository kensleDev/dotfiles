[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Insurance Products

 

---

   

#### Lawshield DSP (B2B)

 

---

 

- ** [Motor Elite](/insurance-products/lawshield-dsp-b2b/motor-elite/)
- ** [Motor Elite Extra](/insurance-products/lawshield-dsp-b2b/motor-elite-extra/)
- ** [Family Select Legal Expenses](/insurance-products/lawshield-dsp-b2b/family-select-legal-expenses/)
- ** [Equestrian Plan Legal Protection](/insurance-products/lawshield-dsp-b2b/equestrian-plan-legal-protection/)
- ** [Park Homes and Static Caravan Legal Protection](/insurance-products/lawshield-dsp-b2b/park-homes-and-static-caravan-legal-protection/)
- ** [Home Emergency](/insurance-products/lawshield-dsp-b2b/home-emergency/)
- ** [Keycare](/insurance-products/lawshield-dsp-b2b/keycare/)
- ** [Excess Waiver](/insurance-products/lawshield-dsp-b2b/excess-waiver/)
- ** [Brokerbility Breakdown Insurance](/insurance-products/lawshield-dsp-b2b/brokerbility-breakdown-insurance/)
- ** [Landlord Home Emergency](/insurance-products/lawshield-dsp-b2b/landlord-home-emergency/)
- ** [Landlord Legal Expenses](/insurance-products/lawshield-dsp-b2b/landlord-legal-expenses/)
- ** [Landlord Rent Guarantee](/insurance-products/lawshield-dsp-b2b/landlord-rent-guarantee/)

   

#### Volkswagen Financial Services (VWFS)

 

---

 

- ** [VWFS Extended Warranty](/insurance-products/volkswagen-financial-services-vwfs/vwfs-extended-warranty/)
- ** [VWFS Ensurance](/insurance-products/volkswagen-financial-services-vwfs/vwfs-ensurance/)
- ** [Porsche OMR Motor (Annual)](/insurance-products/volkswagen-financial-services-vwfs/porsche-omr-motor-annual/)
- ** [Porsche OMR Motor (5-day Drive Away)](/insurance-products/volkswagen-financial-services-vwfs/porsche-omr-motor-5-day-drive-away/)
- ** [VWFS Standalone MOT](/insurance-products/volkswagen-financial-services-vwfs/vwfs-standalone-mot/)
- ** [VWFS Approved Used MOT](/insurance-products/volkswagen-financial-services-vwfs/vwfs-approved-used-mot/)
- ** [VWFS Approved Used Keycare](/insurance-products/volkswagen-financial-services-vwfs/vwfs-approved-used-keycare/)

   

#### Lawshield (B2C)

 

---

 

- ** [Lawshield Pedal Cycle (Velosure)](/insurance-products/lawshield-b2c/lawshield-pedal-cycle-velosure/)