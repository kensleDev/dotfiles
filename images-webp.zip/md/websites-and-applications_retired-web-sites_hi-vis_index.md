[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Hi-Vis

 

---

   

## Website Details

  **Live URL:** [https://hi-vis.performancecarhire.co.uk/](https://hi-vis.performancecarhire.co.uk/) **UAT URL:** [https://hi-vis.connexus-test.co.uk/](https://hi-vis.connexus-test.co.uk/)    .NET Core C# ASP.NET MVC Core HTML SCSS Bootstrap ReactJS   

---

 

## Introduction

 

Hi-Vis is a Business-to-Business (B2B) web application used by brokers to help select suitable replacement vehicles for performance and prestige vehicles and to send enquiries to PCH.[](https://proclaim-api.lawshield.co.u/)

 

## Architecture

 

The goal with this API is to provide a single entry point for all communications to and from ProClaim environments, the architecture is designed to make the introduction of functionality for new applications as easy as possible.

 

The Hi-Vis solution contains multiple projects:

 

- **HiVis**
 

- ReactJS client layer
- **HiVis.Api** 

- ASP.NET MVC 5 *API* client layer exposing endpoints for consumers
- **HiVis.Common** 

- Provides error codes, configuration classes and core model definitions
- **HiVis.Dal** 

- Provides an Entity Framework 6 context for direct communications with the database
- **HiVis.Identity** 

- Provides an implementation of *Json Web Tokens (JWT)* using ASP.Net Identity, and an Entity Framework 6 context for direct communication with the Identity database
- **HiVis.Services** 

- Core business logic layer implementing all communications with Cazana, the Identity and Hi-Vis databases, file imports and logging
- **HiVis.UnitTests** 

- Unit tests for the service layer written in MS Test with Moq. Entity Framework is mocked using as third-party plugin, **Coderful.EntityFramework.Testing**.

 

## Integrations

 

The Hi_Vis website integrates with one external system:

 

- **Cazana** - for looking up vehicle details and images by registration plate

 

## Further Reading

 

Further details about technologies, architecture and insurance products can be found in other areas of the Knowledgebase:

 

[Hi-Vis Architecture](/archived/hi-vis/hi-vis-architecture/)