[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Central Logging API

 

---

   

## Website Details

  **Live URL:** [https://centralloggingapi.lawshield.co.uk](https://centralloggingapi.lawshield.co.uk) **UAT URL:** [https://centralloggingapi.connexus-test.co.uk](https://centralloggingapi.connexus-test.co.uk)    .NET Core C# Entity Framework Core .NET Core 6   

---

 

### This API is a database based logging service, that's purpose is a have a one stop place to store logging information regardless of the nature / technology used in an application.

 

The API can be found on [the swagger page.](https://centralloggingapi.connexus-test.co.uk/swagger/index.html)

 

We currently have two Live application integrated with this this API, Insure With Porsche and Velosure.

 

This Application is a dot net core 8 API which uses entity framework core to handle the database entities,

 

[A special additional integration we have is with a windows background service](/websites-and-applications/lawshield-connexus/internal-background-worker/)

 

##### Example of how to use:

 

###### Dot net framework 4.7.* request would look something like this:

 

```
public enum Severity
    {
        Log = -1,
        LogWarning = 0,
        LogError = 1,
    }}
```

 

```
public class LogRequest{public string Message { get; set; }public string applicationName { get; set; }}
```

 

```
public IRestResponse LogResponse(string baseUrl, LogRequest data, Severity severity){// Creates the rest client from the BaseURL and the passed in IAuthenticator type for client authenticationvar client = new RestClient(){BaseUrl = new Uri(baseUrl),};ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
var request = new RestRequest(){Resource = "/api/Logging/${severity}",Method = Method.POST,RequestFormat = DataFormat.Json,};request.AddBody(data);// Newtonsoft is not the default json serializer for RESTSharp anymore.// So we have to tell it to userequest.UseNewtonsoftJsonSerializer(); return client.Execute(request);}
```

 

###### React (JavaScript)  request would look something like this:

 

```
const LoggingService = {
    logError: (message) => {
        return log(process.env.REACT_APP_LOGGING_API_URL, 'LogError', message);
    },
    logWarning: (message) => {
        return log(process.env.REACT_APP_LOGGING_API_URL, 'LogWarning', message);
    },
    logInfo: (message) => {
        return log(process.env.REACT_APP_LOGGING_API_URL, 'Log', message);
    },
}
const log = (url, severity, message) => {
    const opts = 
        method: "POST",
        headers: {
            accept: "text/plain",
            "content-type": "application/json",
        },
        body: JSON.stringify({ "message": message, "applicationName": "Velosure" })
    };
    return fetch(
        `${url}/api/Logging/${severity}`,
        opts
    );
}
```