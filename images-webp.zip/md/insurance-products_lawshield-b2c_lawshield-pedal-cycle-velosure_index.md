[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Lawshield Pedal Cycle (Velosure)

 

---

 

This is the underlying insurance product for the Lawshield **Velosure** quote and buy website. 

 

## Product Details

  **Product Reference:** LSLPED **Product Type Id:** 316  

---

 

## Schemes

 

- [Lawshield Pedal Cycle](/insurance-products/lawshield-b2c/lawshield-pedal-cycle-velosure/lawshield-pedal-cycle/)

 

---