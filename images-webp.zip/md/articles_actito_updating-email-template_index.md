[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Updating Email Template

 

---

 

Below are the steps to update an email template:

 

1. Go to **Manage e-mail campaigns** section. This can be accessed from the vertical toolbar located on the left or through the **Portal** section.
2. Locate the email and select it by clicking on it. Click **Edit**
3. After making the changes, go back to the **Manage e-mail campaigns**section and click on the email again. This time select **More**-> **Save as template**
4. Tick select **Edit an existing template**and make sure you select the correct **Existing template** to update
5. Click **Next**
6. If the email template was generating the **Subject**before, this needs to be selected again at this page
7. Click **Save**
8. Create a test campaign with this email template to make sure the changes are in place