[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# JSON Definition

 

---

 

To manage the Proclaim Service inputs and outputs whilst also accommodating a range of claim query types, a data-driven approach was taken. In the ConnexusConfig database associated with the development / UAT, a config setting called ProclaimInputFields is set, containing the JSON data.

 

Here is a snippet that shows the format:

 

```
{"proclaimFieldsCollection":    [{        "queryType":"TRK003",        "caseType":"029",        "inputFields":             [{                "fieldName":"case.key",                "fieldQuestion":"Enter claim reference",                "answer":"",                "quesType":"1",                "inputName": "claimnumber"            }],        "outputFields":            [{                "fieldName":"Fee Earner.Description",                "fieldValue":"",                "outputName":"FeeEarnerDesc",                "outputFriendlyName":"Personal Case Manager Assigned",                "isDate":false,                "stageRef":"feeEarnerInstructedChubbStage"            }],        "trunkStages":            ["feeEarnerInstructedChubbStage",             "engineerInstructedChubbStage",             "engineerInspectedChubbStage",             "repairsAuthorisedChubbStage",             "estimatedCompletionChubbStage",             "repairsCompletedChubbStage"],        "branches":        [            ["liabilityAdmittedChubbStage"],            ["solictorFileOpenedChubbStage"],            ["hireInstructedChubbStage","hireVehicleOutChubbStage","hireVehicleBackChubbStage"]        ],        "minBranchStage": "engineerInstructedChubbStage"        }],    }
```

 

For this data there are associated models in the project for serailisation and use throughout the application.

 

Here follows an explanation of the JSON fields:

 

- **proclaimFieldsCollection**: the root object name for (de)serialisation, each object (comma separated) in the following array represents the full inputs / outputs and expected timeline construction for different query / case types
- **queryType**: A key for Proclaim to identify the query being accessed by the API (defined by IT in Proclaim)
- **caseType**: A key for Proclaim to identify the types of cases being returned by the query (defined by IT in Proclaim)
- **inputFields**: The collection of input fields map directly to Proclaim 'questions' - these define criteria input to the Proclaim API to filter query results. At it's most basic this includes a case number and registration number. 

- **fieldName**: The name of the field in Proclaim (must exactly match)
- **fieldQuestion**: The question related to the field in Proclaim (must exactly match - often worded like a UI label)
- **answer**: This is empty in the config - should be updated with the input from the front-end (e.g. the actual claim number). The **ProclaimService** has methods which take the **ClaimFormViewModel** input fields and match to the relevant 'questions' populating this.
- **quesType**: This is essentially the data type for the input (which **answer** must be in) which the **ProclaimQuesType** enum defines (1 is string)
- **inputName**: This is a name that can map to the front-end (e.g. **claimnumber**, **registrationPlate**) - for different Proclaim queries, even if the data is the same, there's often differences in naming hence the separate mapping for the application to use
- **outputFields**: This is the collection of fields returned by the Proclaim query / API. It is from these outputs that eventually the timeline is built (though this could of course be used for other purposes). 

- **fieldName**: The name of the field in Proclaim so results can be mapped).
- **fieldValue**: The value output from the query for the field (blank in the config, updated in the **ProclaimService**)
- **outputName**: A unique name in string form that can be used in the app.
- **outputFriendlyName**: A friendly name for display (e.g. with spaces / sentence case etc.)
- **isDate**: A boolean to indicate if the field is a date or not
- **stageRef**: A JSON style string name that can be used as a reference / associative index for the timeline stages
- **trunkStages**: In order, a list of the **stageRef**output fields that make up the linear Trunk stages. The first item of which is the root node.
- **branches**: A list of lists - each list is it's own branch, should be maximum of 4. Each list is of **stageRef**output fields that make up the branch in order, the first item of which is the 'branch root node'
- **minBranchStage**: The first point in the trunk (a **stageRef** to the output field) that branches can be applied.