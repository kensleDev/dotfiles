[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - VWFS Standalone MOT

 

---

 

This is a free product offered to customers of VWFS brand vehicles for free MOT insurance

 

## Product Details

  **Product Reference:** VWMOT **Product Type Id:** 673  

---

 

## Schemes

 

- [VWFS Standalone MOT](/insurance-products/volkswagen-financial-services-vwfs/vwfs-standalone-mot/vwfs-standalone-mot/)

 

---