[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Webpack Configuration

 

---

 

## What is Webpack?

 

Webpack is a JavaScript module bundler. At its most basic level it takes a JavaScript module and its dependencies and outputs a single module. However by utilising loaders it can output CSS, images and other assets, and therefore it is often used in place of task runners such as gulp or grunt. Modern web frameworks such as React, Angular and Vue all use Webpack under the hood with varying levels of abstraction.

 

## Installing Webpack

 

Webpack needs to be installed at both the global and project level, so when using Webpack for the first time:

 

```
npm install -g webpack webpack-cli
```

 

and when creating a new project:

 

```
npm install --save-dev webpack webpack-cli
```

 

## Running Webpack

 

Webpack is typically run using NPM scripts. For example if the package.json contains the following scripts:

 

```
"scripts": {
    "dev": "webpack --mode development --watch",
    "build": "webpack --mode production",
    "debug": "webpack --display-error-details"
  },
```

 

Then a production build would be run as follows:

 

```
npm run build
```

 

## Development and production builds

 

The scripts section above has the ability to create development and production builds by use of the --mode flag which takes an argument development or production. If the flag is not supplied then it defaults to production. A production build will be minified and will also warn if any file sizes are > 244kb.

 

## The config file

 

As of version 4, Webpack can work with zero configuration but in all likelihood a config file will be used. The configuration file webpack.config.js is a CommonJS file that exports a webpack configuration object. The properties of this object tell Webpack how to build its output. A simple config file to build ./Scripts/src/index.js and output ./Scripts/dist/index.js would look like this:

 

```
'use strict'; var path = require('path');module.exports = {     entry: './Scripts/src/index.js',     output: {         path: path.resolve(__dirname, './Scripts/dist/'),         filename: 'index.js'     }};
```

 

## Runners

 

### Transpilation

 

Webpack is commonly used to transpile JSX, ES6 and in our case TypeScript (including TSX) to ES5. In order to transpile TypeScript, firstly the TypeScript loader must be installed:

 

```
npm install ts-loader
```

 

The resolve property must have .ts and optionally .tsx added to its extensions. Note that the default extensions must be included in the array as otherwise they would be overwritten:

 

```
resolve: {
    // Add '.ts' and '.tsx' as resolvable extensions.
    extensions: [".webpack.js", ".web.js", ".ts", ".tsx", ".js"]
},
```

 

and the module property's rules array requires an object whose test property is a RegEx to define TypeScript file extensions and whose loader property is the TypeScript loader:

 

```
module: {
    rules: [
        {
            test: /\.tsx?$/,
            loader: 'ts-loader'
        },
    ]
},
```

 

### CSS

 

There are two CSS loaders required to use CSS. The CSS needs to be imported into the entry point in order to do this:

 

```
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-table/react-table.css';
import './content/css/site.scss';
```

 

css-loader turns CSS into valid JavaScript
style-loader turns this JavaScript into a CSS style tag and injects it into the DOM

 

This however will inject a <style> tag into the <head> which is beneficial in a development environment because outputting CSS files takes a while to build, but is not suitable for a production environment because the DOM loads before the CSS is injected and therefore an unstyled site is visible for a split second prior to the styling being applied.

 

The solution to this is to use a plugin mini-css-extract-plugin.

 

Note that the import statements above include a SASS file. SASS can be pre-processed with the sass-loader, so to put everything together:

 

Firstly install the required npm packages (node-sass is a dependency of sass-loader and is not something we need to concern ourselves with):

 

```
npm install --save-dev node-sass sass-loader css-loader mini-css-extract-plugin
```

 

The plugin must be imported into the config file:

 

```
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
```

 

and setup in the plugins array; the plugin has a filename property which is the name of the output file including the relative path if any:

 

```
plugins: [
    new MiniCssExtractPlugin({ filename: 'Content/css/[name].css' }),
],
```

 

Now the CSS rule can be added to the rules array. A few things to note:

 

1. This regex handles SASS and CSS; pre-processing CSS won't make any difference
2. The style-loader is not required in this example as the CSS is not being injected into the DOM
3. The use array is in reverse order; the example below will run sass-loader, css-loader then mini-css-extract-plugin in that order

 

```
rules: [
    {
        test: /\.[s]?css$/,
        use: [
            MiniCssExtractPlugin.loader, // 3. Extract css into files
            'css-loader',   // 2. Turns css into commonjs
            'sass-loader'   // 1. Turns sass into css
        ]
    }
]
```

 

### Files

 

Webpack needs to know how to handle files referred to in the CSS such as background images; the file-loader plugin will handle this.

 

```
npm install --save-dev file-loader
```

 

A rule is then added to the module's rules array; this example will copy any files of type svg, png, jpg, jpeg or gif to a subfolder named Content/images in the output folder, keeping the filenames:

 

```
module: {
    rules: [
        {
            test: /\.(svg|png|jpe?g|gif)$/,
            use: {
                loader: 'file-loader',
                options: {
                    name: '[name].[ext]',
                    outputPath: 'Content/images'
                }
            }
        }
    ]
}
```

 

Note however that these files will not be picked up by the CSS unless the output property's publicPath property is set to '/':

 

```
output: {
    path: path.resolve(__dirname, './Scripts/dist/'),
    filename: '[name].js',
    publicPath: '/'
},
```

 

### Source mapping

 

As the examples above use TypeScript and SASS, Webpack can output map files so that the original source can be debugged. The source-map-loader is installed via npm:

 

```
npm install --save-dev source-map-loader
```

 

The devtool property must be exported; this can be either inline-source-map which writes the map to the js file, or preferably source-map which creates a separate .map.js file:

 

```
devtool: 'source-map',
```

 

And the following rule will run source-map-loader prior to outputting .js files:

 

```
module: {
    rules: [
        {
            enforce: 'pre',
            test: /\.js$/,
            loader: 'source-map-loader'
        }
    ]
},
```

 

### Copying files

 

Static files need to be copied to the dist folder; this can be achieved with copy-webpack-plugin:

 

```
npm install copy-webpack-plugin
```

 

This must be imported into the config file:

 

```
const CopyWebpackPlugin = require('copy-webpack-plugin');
```

 

And added to the plugins array; the following example will copy from './Scripts/src/content/images' to 'Content/images' and Web.config from the root to the root of the dist folder.

 

```
plugins: [
    new CopyWebpackPlugin([
        { from: './Scripts/src/content/images', to: 'Content/images' },        { from: './Web.config', to: '.' }    ], { copyUnmodified: true }),
],
```

 

## Splitting JavaScript into chunks

 

By default Webpack will output a single JavaScript file containing both the bespoke and third-party library code. It is preferable to output two separate files which is achieved by setting the optimization property. How the code is split into chunks is configurable, but the easiest option is simply to split it into these two files as follows:

 

```
optimization: {
    splitChunks: { chunks: 'all' }
},
```

 

If the output's filename property is is set to '[name].js' then the files will be named main.js and vendor.js respectively.

 

## Cache busting

 

It is preferable for the browser to cache JavaScript and CSS so it doesn't have to be downloaded every time the user visits the site, but if a file has changed then we need to have a mechanism to let the browser know and re-download the file. This is achieved by adding a hash to the filename.

 

The output filename property can use a variable [hash] which suffixes the filename with a hash generated every time, or [contenthash] which generates a hash based on content so the hash only changes when the file has changed and only downloaded if the hash has changed otherwise it would be retrieved from the cache. Coupled with html-webpack-plugin (see below) this will add a <script> tag using this hash into the html file.

 

```
output: {
    path: path.resolve(__dirname, './Scripts/dist/'),
    filename: '[name].[contenthash].js',
    publicPath: '/'
},
```

 

A gotcha here is that the module.id forms part of the hash and by default this is incremented based on resolving order. What this means is that if a new bundle is added anywhere other than after the last bundle then any subsequent bundles have their module.id changed. This can be overcome by setting the moduleIds property to 'hashed' in the optimization object:

 

```
optimization: {
    moduleIds: 'hashed',
    splitChunks: { chunks: 'all' }
},
```

 

## Cleaning the output folder

 

If cache busting is enabled then the output folder can soon get messy as new files are generated and the old files not deleted. This is easily resolved with clean-webpack-plugin. Firstly install the plugin via npm:

 

```
npm install clean-webpack-plugin
```

 

and import the plugin into the config file, note that the curly brackets are required:

 

```
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
```

 

The plugin is then simply added to the plugins array:

 

```
plugins: [
    new CleanWebpackPlugin(),
],
```

 

## Injecting script and style tags into an HTML template

 

So far JavaScript and CSS files have been output but they would need to be manually inserted into an HTML file, and when cache busting is utilised this can be prone to errors. The <script> and <style> tags can be automatically inserted by use of the html-webpack-plugin:

 

```
npm install html-webpack-plugin
```

 

This needs to be imported into the config file:

 

```
const CopyWebpackPlugin = require('copy-webpack-plugin');
```

 

and then added to the plugins array. The constructor takes an argument called template which is the location of the html template:

 

```
plugins: [
    new HtmlWebpackPlugin({
        template: './Scripts/src/index.html'
    }),
],
```

 

## Notifying the developer of the build status

 

The developer can be notified of the build status via SnoreToast with the webpack-notifier:

 

```
npm install webpack-notifier
```

 

This needs to be imported into the config file:

 

```
const WebpackNotifierPlugin = require('webpack-notifier');
```

 

and then added to the plugins array:

 

```
plugins: [
    new WebpackNotifierPlugin(),
],
```

 

## Enabling BrowserSync

 

BrowserSync can be enabled with browser-sync-webpack-plugin:

 

```
npm install browser-sync-webpack-plugin
```

 

This needs to be imported into the config file:

 

```
const BrowserSyncPlugin = require('browser-sync-webpack-plugin');
```

 

and then added to the plugins array:

 

```
plugins: [
    new BrowserSyncPlugin(),
],
```

 

## The Webpack Development Server

 

Webpack has a lightweight web server which can be used in a development environment. **Note that using the Webpack dev server creates a build in memory rather than writing to the filesystem.**

 

```
npm install webpack-dev-server
```

 

This is typically run via an npm script; this will create the dev build in memory, run the dev server, open the default browser and navigate to the web page:

 

```
"scripts": {
    "start": "webpack-dev-server --env.NODE_ENV=dev --open"
  }
```

 

The config file has a devServer property as in the following example:

 

```
devServer: {
    historyApiFallback: true,
    contentBase: path.resolve(__dirname, 'content'),
    port: 3000
}
```

 

The historyApiFallback property means that the index.html is served up if a request results in a 404 error. This enables development of websites using client-side routing which otherwise would fall over if the page was refreshed.

 

The contentBase property tells the server to serve up static content from the content subfolder; without this all content would be served up from the root.

 

### Writing the HTML output to the filesystem

 

A major problem with the above approach occurs when using html-webpack-plugin; the <script> and <style> tags are injected into the HTML template when first served up, but not on refresh resulting in an error. To get round this, install the html-webpack-harddisk-plugin:

 

```
npm install html-webpack-harddisk-plugin
```

 

Import it into the config file:

 

```
const HtmlWebpackHarddiskPlugin = require('html-webpack-harddisk-plugin');
```

 

and both add it to the plugins array and set the HtmlWebpackPlugin's alwaysWriteToDisk property to true:

 

```
plugins: [
    new HtmlWebpackPlugin({
        template: './Scripts/src/index.html',
        alwaysWriteToDisk: true
    }),
    new HtmlWebpackHarddiskPlugin(),
],
```

 

This does not write any content to the filesystem other than the HTML, but as it also serves up the HTML from the filesystem with the <script> and <style> tags injected, this is sufficient.

 

This approach can be quite temperamental, an alternative would be to create a dev build and use local IIS for testing purposes.

 

## Defining variables

 

Webpack can for example solve the problem of resolving different endpoints for different environments by passing in the NODE_ENV property and setting a variable based on this. For example given the following npm scripts:

 

```
"scripts": {
    "dev": "webpack --mode development --env.NODE_ENV=dev --watch",
    "build": "webpack --mode production --env.NODE_ENV=prod",
    "start": "webpack-dev-server --env.NODE_ENV=dev --open",
    "debug": "webpack --env.NODE_ENV=dev --display-error-details"
  }
```

 

a function can be created in the config file to set a variable based on a parameter:

 

```
let apiHost = '';
 
function setupApi(env) {
    switch (env) {
        case "prod":
            apiHost = 'https://hi-visapiuat.performancecarhire.co.uk/';
            break;
        case "dev":
        default:
            apiHost = 'http://localhost:57308';
            break;
    }
}
```

 

and as the config file is actually a JavaScript module, the exports can take the environment as a parameter, call the new function and return the export properties:

 

```
module.exports = env => {
    setupApi(env.NODE_ENV);
 
    return {
        /* export properties */
    }
};
```

 

This approach requires a new plugin to be defined, which in turn requires Webpack to be imported into the config script:

 

```
const webpack = require('webpack');
```

 

```
plugins: [
    new webpack.DefinePlugin({
        'process.env': {
            API_URL: JSON.stringify(apiHost)
        }
    })
],
```

 

The variable can then be used in the application:

 

```
apiUrl: string = process.env.API_URL;
```

 

## Putting it all together

 

This sample webpack.config.ts file taken from Hi-Vis demonstrates how all the techniques described above can be put together:

 

```
'use strict';
 
const path = require('path');
const WebpackNotifierPlugin = require('webpack-notifier');
const BrowserSyncPlugin = require('browser-sync-webpack-plugin');
const HtmlWebpackHarddiskPlugin = require('html-webpack-harddisk-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const webpack = require('webpack');
 
module.exports = env => {
    setupApi(env.NODE_ENV);
 
    return {
        entry: './Scripts/src/index.tsx',
 
        optimization: {
            moduleIds: 'hashed',
            splitChunks: { chunks: 'all' }
        },
 
        output: {
            path: path.resolve(__dirname, './Scripts/dist/'),
            filename: '[name].[contenthash].js',
            publicPath: '/'
        },
 
        devtool: 'source-map',
 
        resolve: {
            // Add '.ts' and '.tsx' as resolvable extensions.
            extensions: [".webpack.js", ".web.js", ".ts", ".tsx", ".js"]
        },
 
        module: {
            rules: [
                {
                    enforce: 'pre',
                    test: /\.js$/,
                    loader: 'source-map-loader'
                },
                {
                    test: /\.tsx?$/,
                    loader: 'ts-loader'
                },
                {
                    test: /\.[s]?css$/,
                    use: [                        env === 'prod' ? MiniCssExtractPlugin.loader : 'style-loader', // 3. Extract css into files or inject into DOM                        'css-loader',   // 2. Turns css into commonjs                        'sass-loader'   // 1. Turns sass into css                    ]                },
                {
                    test: /\.(svg|png|jpe?g|gif)$/,
                    use: {
                        loader: 'file-loader',
                        options: {
                            name: '[name].[ext]',
                            outputPath: 'Content/images'
                        }
                    }
                }
            ]
        },
 
        plugins: [
            new CleanWebpackPlugin(),
            new WebpackNotifierPlugin(),
            new BrowserSyncPlugin(),
            new HtmlWebpackPlugin({
                template: './Scripts/src/index.html',
                alwaysWriteToDisk: true
            }),
            new HtmlWebpackHarddiskPlugin(),
            new MiniCssExtractPlugin({ filename: 'Content/css/[name].[contentHash].css' }),
            new CopyWebpackPlugin([                { from: './Scripts/src/content/images', to: 'Content/images' },                { from: './Web.config', to: '.' }            ], { copyUnmodified: true }),            new webpack.DefinePlugin({
                'process.env': {
                    API_URL: JSON.stringify(apiHost)
                }
            })
        ],
 
        devServer: {
            historyApiFallback: true,
            contentBase: path.resolve(__dirname, 'content'),
            port: 3000
        }
    }
};
 
let apiHost = '';
 
function setupApi(env) {
    switch (env) {
        case "prod":
            apiHost = 'https://hi-visapiuat.performancecarhire.co.uk/';
            break;
        case "dev":
        default:
            apiHost = 'http://localhost:57308';
            break;
    }
}
```