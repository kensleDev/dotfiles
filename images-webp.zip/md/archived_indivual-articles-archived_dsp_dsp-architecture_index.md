[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# DSP - Architecture

 

---

 

## Introduction

 

The Lawshield **Digital Sales Platform** (DSP) is a broker-to-broker (B2B) **ancillary insurance** sales platform for brokers to incept policies on behalf of their customers. Ancillary insurance products are usually sold *in addition to* more mainstream insurances and typical examples include:

 

- Legal Expenses
- Excess Waiver
- Breakdown Cover
- Keycare
- Home Emergency

 

DSP is built, managed and maintained by Connexus and is hosted at: [https://dsp.lawshield.co.uk](https://dsp.lawshield.co.uk)

 

This is the only application at Connexus still written predominantly in VB.NET and ASP.NET WebForms. It is also the only true "Transactor"-based web application; fully utilising the documented method of integrating a web application with Transactor V6. Not only does the website interface with Transactor V6, but the web application is itself driven by Transactor's own codebase via their code libraries (DLLs).

 

Alongside the usual HTML and CSS, the application uses JavaScript on the client-side; but in small quantities.

 

## Application Architecture

 

With the primary technology implementing DSP being ASP.NET WebForms, most of the business logic lives close to the UI layer directly in the front-end project. However, there are a few additional projects in the solution providing other business-logic and data-access layers:

 

- **CEL** - the front-end ASP.NET WebForms application layer
- **CEL.CSharp** - services and helpers, written in C#
- **CEL.TransactorDatabase** - data-layer implemented with Entity Framework and Repository Pattern to provide some direct database interactions outside of the Transactor logic available in their codebase
- **CEL.Tests** - beginnings of a unit-test project - never really fleshed out
- **CEL.TransactorInteractions** - Redundant project

 

## CEL - Front-End Project

 

As described above, the main front-end application layer is implemented in the 'standard' Transactor architecture. This provides familiar journey processes to the Transactor codebase that means Transactor itself is responsible for navigating a user through the journey to inception; by way of a standard structure and naming conventions.

 

### Example - Family Select Legal Expenses (FAMSEL)

 

As an example, the **Family Select Legal Expenses** product provides the following files within a specifically-named folder in the root of the CEL application:

 

- **/FAMSEL** 

- Assumptions.aspx
- Payment.aspx
- PaymentCompleted.aspx
- PolicySummary.aspx
- ProductRateCard.aspx
- QuotationSaved.aspx
- View.aspx
- YourDetails.aspx
- famsel.config

 

Checking the folder structure for other product type codes (e.g. **MTREAM** for Motor Elite (AmTrust) or **HMEMERG** for Home Emergency) will show the same file structure, save for the naming of the product-specific .config file.

 

Transactor identifies with these file names and knows how to navigate to the correct page under relevant and appropriate circumstances and user actions.

 

#### User Controls

 

Many of the pages identified under each product-specific folder reference a wide number of **User Controls**. This makes the pages themselves more concise and breaks up the required elements into manageable chunks.

 

The User Controls are grouped and organised by their purpose, rather than the product they relate to. As such, the folder structure for any given product will look similar to the following:

 

- **/UserControls/Documents** 

- FamilySelectDocs.ascx
- **/UserControls/Products** 

- **/compliancePoints** 

- CancellationTextFamSel.ascx
- KspFamSel.ascx
- PanelFamSel.ascx
- PanelFamSelSummary.ascx
- **/forms** 

- AddressDetails.ascx
- PersonalDetails.ascx
- **/summary** 

- AddressDetails.ascx
- PersonalDetails.ascx
- PolicyDocumentsFamSel.ascx
- ProductDetails.ascx

 

There may be additional and supplementary User Controls for certain products based on the complexity of the risk data.

 

## Authentication and Authorisation

 

Security in DSP is implemented directly with Transactor; that is that Transactor is responsible for managing user accounts and permissions via the TES Tool Suite. Further information about this is available in the associated DSP article: [DSP - Add New Broker Login](/archived/indivual-articles-archived/dsp/dsp-add-new-broker-login/).

 

## Policy Documentation

 

All policy documentation (including Policy Booklets, Insurance Product Information Documents (IPIDs) and Insurance Distribution Directives (IDDs) are available to brokers directly in DSP for the products they have access to. All policy documentation is held in the **/policydocs** folder at the root of the front-end CEL project.

 

## Product Rate Cards

 

Some of the insurance products sold through DSP have very basic rating criteria; indeed some have none at all (e.g. Family Select). In these cases, DSP uses the [DSP - "Quick Quote" Pattern](/archived/indivual-articles-archived/dsp/dsp-quick-quote-pattern/) in order to present a single premium to the user.

 

A handful of the products on offer through DSP have more complex rating criteria or a number of risk factors to consider. In these cases, a static **Product Rate Card** is offered in DSP to present all of the cover options and premium levels for the different risks. The three products currently available that require this are:

 

- Breakdown
- Excess Waiver
- Landlord Rent Guarantee

 

In these cases, an XML file defines all of the possible combinations of cover options and the premium that should be presented to the user for those options, per-Broker. These are held in the **/productRateCardXml** folder at the root of the front-end CEL project. The relevant file is loaded at runtime to present the correct pricing rate card to the user based on which broker they are associated with.

 

### Transactor "Subagent" and DSP "Subagent"

 

DSP **Brokers** are defined in Transactor as **Subagents** of the "Lawshield Wholesale" **Agent**. All broker users are assigned to a specific Subagent in their user permissions via TES Tool Suite. In addition to the standard Transactor data representing a Broker, DSP defines additional data to simplify Broker association and rating by providing its own representation of the brokers in a Transactor "LIST" table: **LIST_CEL_SUBAGENT**. This allows for a numeric broker ID to be used in DSP and in Scheme Files to determine which Broker we are working with.

 

The Transactor **Subagent ID** is mapped to the DSP **LIST_CEL_SUBAGENT ID** in a configuration file at the root of the front-end CEL project called **login.config**.

 

Once a user and Broker are mapped to the associated DSP LIST_CEL_SUBAGENT identifier, this is then referenced in the file names of the Product Rate Card XML files.