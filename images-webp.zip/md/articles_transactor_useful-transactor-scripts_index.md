[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Useful Transactor Scripts

 

---

 

I have a few scripts I have created / used to do various things in Transactor, they are located on the server here:

 

\\192.168.30.18\CompanyData\Connexus Digital\Web Development\Transactor Scripts - useful

 

A few regularly used ones:

 

| Script filename | Description |
| --- | --- |
| 00 - RM_SCHEME_ENRICHMENT_SETUP_NEW.sql |  |
| Add Porsche Legal Expenses Addon.sql |  |
| Aggregator database - see quotes.sql | View quotes in the aggregator database (Quotezone) |
| Aggregator Database.sql |  |
| Count Column Values.sql |  |
| Delete a scheme.sql |  |
| DSP - Copy Commissions from one commission group to another.sql | Copy commissions from one commission group to another, and alter them as they copy if required. |
| DSP - Get Commission settings for each broker .sql |  |
| DSP - Get Logins.sql | View logins. |
| DSP - Get Policies, Brokers, Users active.sql |  |
| DSP - Reinstate User Login.sql | Use to re-instate a deleted user login. |
| Find and Replace String in Documents.sql |  |
| Fix Email Error - not emailing.sql |  |
| Gender setting and lookup.sql |  |
| Get all Live Docs in Doc Packs.sql | Show all Documents and Document Packs promoted against a scheme(s) |
| Get all Templates and Doc Packs.sql | Show all Documents and Document Packs promoted against a scheme(s) |
| Get Customer Details - Velosure.sql | will retrieve all data for a Velosure client(s) |
| Get Customer Details with Endorsements.sql | will retrieve data for a client with Endorsements |
| Get Customer Details.sql | will retrieve data for a client |
| Get Events and Triggers for a scheme.sql | Show all Events and Triggers promoted against a scheme(s) |
| GetDateDiff Function.sql |  |
| Law Shield_Test_Schemes_TIC.sql | Scheme Promotion Script (supplied by Open GI) |
| Porsche - fix MTA issue for a customer record.sql | Use to fix the 'mtaStartDate' error |
| Porsche - MTA fix - switch to correct MTA record.sql | Switch the current history record in Transactor. |
| Porsche - update registration number.sql | Porsche - update registration number |
| Porsche Docs rename - UAT.sql |  |
| Porsche model fix.sql |  |
| Porsche query for cars 15 years plus.sql |  |
| QuoteZone - add Top 1 and 2 source of businesses.sql |  |
| Remove users who no longer work here.sql |  |
| Restore Orphaned Users.sql | Use this after restoring a database to fix permission issues. |
| Search Database for column names.sql | use this to save time looking for column names in a database |
| Search Database for String.sql | use this to look for data in the database, will return all tables/columns the data exists. Can take a while to run on large databases. |
| Search Stored Procedures.sql | Searches stored procedures for some text. |
| SP_UPDATE_SCHEME_PRODUCT_ACCESS_TOKEN.sql |  |
| SQL User Permissions and passwords.sql |  |
| UAT ONLY - Erase email addresses from UAT.sql | Erase customer email addresses from a DB - use in UAT only, after restoring from LIVE. |
| Update insurer Name in Transactor.sql |  |
| Velosure - Add Velosure Broker Discount.sql |  |
| Velosure - Add Velosure Broker Spring 2023 10% Discount.sql |  |
| View Event Queue (Emails and Docs to be processed).sql | View the event queue - use if emails/documents are not working. |
| VW Payment references.sql | View VW payment references |
|  |  |

 

This is updated all the time, so please take a look. There are usually comments in the SQL Scripts indicating the details of what the script does in more detail than above.