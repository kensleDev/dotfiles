[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Checking Payment is Working

 

---

 

Look for policies created in the timescale on CNX_TGSL LawshieldVW:

 

```
SELECT TOP 10lps.POLICY_STATUS_DEBUG,pp.NAME,v.MAKE,v.MODEL,v.REGISTRNO,cpd.CREATEDDATE,cpd.PAYMENT_PLAN_IDFROM CUSTOMER_POLICY_DETAILS cpdJOIN USER_VW_VEHDETS v ON v.POLICY_DETAILS_ID = cpd.POLICY_DETAILS_IDJOIN LIST_POLICY_STATUS lps ON lps.POLICY_STATUS_ID = cpd.POLICY_STATUS_IDJOIN RM_PAYMENT_PLAN pp ON cpd.PAYMENT_PLAN_ID = pp.PAYMENT_PLAN_IDWHERE v.MAKE = 'SKODA'AND lps.POLICY_STATUS_DEBUG = 'Policy'ORDER BY cpd.CREATEDDATE DESC
```

 

Look for:
POLICY_STATUS_DEBUG = Policy means the policy has been incepted, not just a prospect or quote
NAME = Full Annual means the user has paid by card, not setup a direct debit