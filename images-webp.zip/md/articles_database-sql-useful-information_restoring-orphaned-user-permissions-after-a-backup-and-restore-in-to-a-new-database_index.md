[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Restoring orphaned user permissions after a backup and restore in to a new database

 

---

 

When creating a new database on a new SQL instance, and restoring a database in to it from another SQL instance, user permissions become orphaned, meaning you can no longer login with previously working credentials.

 

To see users that are orphaned, the following script can be run:

 

/* View orphaned logins / users */
select
dp.name [user_name]
,dp.type_desc [user_type]
,isnull(sp.name,'Orphaned!') [login_name]
,sp.type_desc [login_type]
from 
sys.database_principals dp
left join sys.server_principals sp on (dp.sid = sp.sid)
where
dp.type in ('S','U','G')
and dp.principal_id >4
order by sp.name

 

![](../images-webp/image_81.webp)

 

Once you have the list of users that are orphaned, you can fix them by running the following:

 

/* Use the below to re-associate users / Orphaned logins - just replace ConnexusAdmin with the user required */
ALTER USER [ConnexusAdmin] WITH LOGIN=[ConnexusAdmin]

 

Re-running the view orphaned script will then show the login as no longer orphaned.

 

Further information on orphaned users can be found here:

 

[https://docs.microsoft.com/en-us/sql/sql-server/failover-clusters/troubleshoot-orphaned-users-sql-server?view=sql-server-ver15](https://docs.microsoft.com/en-us/sql/sql-server/failover-clusters/troubleshoot-orphaned-users-sql-server?view=sql-server-ver15)