[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Swapping between Environments

 

---

 

Acturis app will run in TEST or Production.

 

In order to start trying out the self-service documents, you will need to connect to the TEST environment.

 

 

 

For access to the TEST environment, please follow these steps:

 

 

 

- Ensure that the application is closed
- Right click on the Acturis Assistant icon in the bottom right of the screen and choose Settings
- On the Environments tab, click Add and select the TEST value in the Environment dropdown
- Click OK

 

 

 

To change between the environments, use the Environment drop down field on the **Home tab of the Acturis Assistant** and hit Apply then OK. You can then start up Acturis and the top left of the application should say ‘Acturis – TEST’ instead of ‘Acturis – Production’.