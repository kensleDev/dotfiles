[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Clear previous version when debugging

 

---

 

When debugging a Vue JS app, the localhost:***** will tend to hold the previous version. This instance needs to be killed. Note that sometimes this 'previous' version may even be a different app.

In console enter:

 

*netstat -ano|findstr "PID :8080"*

 

this will return a PID number for example "12345"

 

Kill the PID

 

*taskkill /pid 12345 /f*