[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# ProClaim API

 

---

   

## Website Details

  **Live URL:** [https://proclaim-api.lawshield.co.uk/](https://proclaim-api.lawshield.co.uk/) **UAT URL:** [https://proclaim-api.connexus-test.co.uk/](https://proclaim-api.connexus-test.co.uk/)    .NET Core C# ASP.NET MVC Core   

---

 

## Introduction

 

The ProClaim API is the Connexus "Middleware" API used for communicating with ProClaim. It takes on the responsibility of communicating with ProClaim using a Connected Service imported from **Proclaim.wsdl**. This allows consuming applications the freedom to use an independent technology stack with the only caveat that the technologies of choice must be able to consume a RESTful API.

 

[](/websites-and-applications/lawshield-connexus/velosure/)The Claim Tracker was the first website to consume this API and is built using .NET Core 3.1, ASP.NET Core WebAPI and Angular.

 

The API is self-documenting by use of Swagger and provides a full description of each endpoint including the definition of the expected and returned JSON data. It can be viewed at: [https://proclaim-api.lawshield.co.uk](https://proclaim-api.lawshield.co.u)

 

## Architecture

 

The goal with this API is to provide a single entry point for all communications to and from ProClaim environments, the architecture is designed to make the introduction of functionality for new applications as easy as possible.

 

The solution contains multiple projects:

 

- **ConnexusServices.ProClaim** 

- ASP.NET Core MVC 5 *API* client layer exposing endpoints for consumers
- **ConnexusServices.ProClaim.Common** 

- Provides error codes, configuration classes and core ProClaim query and save model definitions
- **ConnexusServices.ProClaim.Services** 

- Core business logic layer implementing all communications with ProClaim, an Entity Framework 6 context for direct communications with the ProClaim database, and the API authorisation service
- **ConnexusServices.ProClaim.TokenGenerator** 

- Provides a console-based facility for generating valid authentication tokens for communicating with the ProClaim API

 

### Core Implementation Principles

 

As and when further applications use the API, it is necessary to update one or two Json files in the API as follows:

 

#### Querying ProClaim

 

Add configuration for the query to the **proclaimFieldsCollection** node in **ProclaimQueryInputFields.json** as follows:

 

- **queryType** - a key for Proclaim to identify the query being accessed by the API (defined by IT in Proclaim)
- **caseType** - a key for Proclaim to identify the types of cases being returned by the query (defined by IT in Proclaim)
- **inputFields** - the collection of input fields map directly to Proclaim 'questions' - these define criteria input to the Proclaim API to filter query results. At it's most basic this includes a case number and registration number 

- **fieldName** - the name of the field in Proclaim (must exactly match)
- **fieldQuestion** - the question related to the field in Proclaim (must exactly match - often worded like a UI label)
- **answer** - this is empty in the config - the calling application should pass the input from the front-end (e.g. the actual claim number)
- **quesType** - this is essentially the data type for the input (which **answer** must be in) which the **ProclaimQuesType** enum defines (1 is string)
- **inputName** - this is a name that can map to the front-end (e.g. **claimnumber**, **registrationPlate**) - for different Proclaim queries, even if the data is the same, there's often differences in naming hence the separate mapping for the application to use
- **outputFields** - the collection of fields returned by the Proclaim query / API 

- **fieldName** - the name of the field in Proclaim so results can be mapped).
- **fieldValue** - the value output from the query for the field (blank in the config)
- **outputName** - a unique name in string form that can be used in the app
- **outputFriendlyName** - a friendly name for display (e.g. with spaces / sentence case etc.)
- **isDate** - a boolean to indicate if the field is a date or not
- **stageRef** - a JSON style string name that can be used as a reference / associative index for the timeline stages

 

#### Writing to ProClaim

 

Add configuration to the **ProclaimSaveScreenDataFields** node in **ProclaimSaveScreenDataFields.json** as follows:

 

- **caseType** - Proclaim case type
- **screenDataFields** - collection of fields to save to Proclaim: 

- **fieldName** - the name of the field in Proclaim (must exactly match)
- **screenDataName** - this is a name that can map to the front-end (e.g. **claimnumber**, **registrationPlate**) - for different ProClaim queries, even if the data is the same, there's often differences in naming hence the separate mapping for the application to use

 

## Further Reading

 

Further details about technologies and architecture can be found in other areas of the Knowledgebase:

 

- [ProClaim API - Architecture](/articles/proclaim/proclaim-api-architecture/)