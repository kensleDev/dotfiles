[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Pre-Population from QuoteZone

 

---

 

## Introduction

 

A requirement has been put forward to integrate with QuoteZone which would involve storing the data retrieved by a new API and pre-populating Velosure with this data. The following data will need pre-populating:

 

## quoteContextProvider/state

 

| Property 1 | Property 2 | Property 3 |  | Description |
| --- | --- | --- | --- | --- |
| IndividualBikeDetails |  |  |  | Array of bike details |
| IndividualBikeDetails | agreedToLockDisclaimer |  |  | True when "I confirm this bike is secured..." is checked |
| IndividualBikeDetails | homeValue |  |  | Value |
| IndividualBikeDetails | includeInAwayValue |  |  | True unless "Insure away from home" is unchecked on a multi-bike quote |
| IndividualBikeDetails | make |  |  | Make |
| IndividualBikeDetails | model |  |  | Model |
| IndividualBikeDetails | uniqueId |  |  | Sequential ID |
| IndividualBikeDetails | validationChecked |  |  | true |
| PedalCycleRiskModel | awayValue |  |  | Away value |
| PedalCycleRiskModel | bicycles |  |  | Array of bike details |
| PedalCycleRiskModel | bicycles | homeValue |  | Value |
| PedalCycleRiskModel | bicycles | make |  | Make |
| PedalCycleRiskModel | bicycles | model |  | Model |
| PedalCycleRiskModel | hasPreviousClaims |  |  | Radio button "Have you had any previous cycle claims.." |
| PedalCycleRiskModel | hasSecondaryAddress |  |  | Has a secondary address been entered |
| PedalCycleRiskModel | includeAccessoriesCover |  |  | Is accessories cover included |
| PedalCycleRiskModel | includeFamilyCover |  |  | Is family cover included |
| PedalCycleRiskModel | includePersonalAccidentCover |  |  | Is personal accident cover included |
| PedalCycleRiskModel | includeRoadRageCover |  |  | Is road rage cover included |
| PedalCycleRiskModel | includeSportCover |  |  | Is sport cover included |
| PedalCycleRiskModel | includeWorldwideCover:true |  |  | Is worldwide cover included |
| PedalCycleRiskModel | isElectric |  |  | Is the bike electric |
| PedalCycleRiskModel | marketing | sourceBusinessId |  | Source of business ID |
| PedalCycleRiskModel | policy | coverEndDate |  | Policy end date |
| PedalCycleRiskModel | policy | coverStartDate |  | Policy start date |
| PedalCycleRiskModel | proposer |  |  | Details about the insured party |
| PedalCycleRiskModel | proposer | address | city | Primary address - City |
| PedalCycleRiskModel | proposer | address | county | Primary address - County |
| PedalCycleRiskModel | proposer | address | house | Primary address - House number |
| PedalCycleRiskModel | proposer | address | locality | Primary address - Locality |
| PedalCycleRiskModel | proposer | address | postcode | Primary address - Postcode |
| PedalCycleRiskModel | proposer | address | street | Primary address - Street |
| PedalCycleRiskModel | proposer | dateOfBirth |  | Date of birth (JS date format) |
| PedalCycleRiskModel | proposer | emailAddress |  | Email address |
| PedalCycleRiskModel | proposer | forename |  | Forename |
| PedalCycleRiskModel | proposer | surname |  | Surname |
| PedalCycleRiskModel | proposer | telephone | number | Telephone number |
| PedalCycleRiskModel | proposer | title |  | Title |
| PedalCycleRiskModel | proposer | titleId |  | Title ID - titleOptions.value from CMS where label = Title |
| PedalCycleRiskModel | secondaryAddress | city |  | Secondary address - City |
| PedalCycleRiskModel | secondaryAddress | county |  | Secondary address - County |
| PedalCycleRiskModel | secondaryAddress | house |  | Secondary address - House number |
| PedalCycleRiskModel | secondaryAddress | locality |  | Secondary address - Locality |
| PedalCycleRiskModel | secondaryAddress | postcode |  | Secondary address - Postcode |
| PedalCycleRiskModel | secondaryAddress | street |  | Secondary address -Street |
| Quote Response |  |  |  | Quote data retrieved from Transactor |
| Quote Response | annualGrossPremium |  |  | Annual gross premium |
| Quote Response | basePremium |  |  | Base premium |
| Quote Response | commission |  |  | Commission |
| Quote Response | declineReason |  |  | Decline reason, null |
| Quote Response | instalmentsApr |  |  | APR |
| Quote Response | instalmentsFirstPayment |  |  | First payment amount |
| Quote Response | instalmentsGrossPremium |  |  | Installments gross premium |
| Quote Response | instalmentsInterestPc |  |  | Installments interest % |
| Quote Response | instalmentsServiceCharge |  |  | Installments service charge |
| Quote Response | instalmentsSubsequentPayments |  |  | Installments subsequent payments |
| Quote Response | ipt |  |  | IPT |
| Quote Response | netPremium |  |  | Net premium |
| Quote Response | quoteReference |  |  | Quote reference |
| Quote Response | schemeId |  |  | Scheme ID |
| currentJourneyStage |  |  |  | As per QuoteJourneyStages enum |
| discountCodeEntered |  |  |  | Discount code if one entered |
| locationKept |  |  |  | As per LocationCyclesKept enum |

 

 

 

## quoteContextUiProvider/uiState

 

| Property 1 | Property 2 | Description |
| --- | --- | --- |
| contactingServerForInception |  | False; we are not contacting the server |
| contactingServerForQuote |  | False; we are not contacting the server |
| cycleRescueIpidDocument |  | Current document, populated by step 2 visible |
| discountBannerHtml |  | Discount banner HTML discount from Transactor |
| discountCodeLoadingVisible |  | false |
| dobAsCalendarDate |  | Date of birth in JS date format |
| dobAsText |  | Date of birth in format dd/mm/yyyy |
| globalPayRetryCount |  | Prop to re-render step 3 on GlobalPay retry = 0 |
| policyDocumentsClicked |  | Policy documents checkbox clicked = true |
| policyStatementClicked |  | Policy statement checkbox clicked = true |
| primaryAddressVisibility |  | Visibility for primary address |
| primaryAddressVisibility | loadingVisible | false |
| primaryAddressVisibility | manualVisible | true |
| primaryAddressVisibility | selectVisible | false |
| privacyPolicyClicked |  | Privacy policy checkbox clicked = true |
| referralOptions |  | Array of where you heard about us; referralOptions in CMS |
| secondaryAddressVisibility | loadingVisible | false |
| secondaryAddressVisibility | manualVisible | true |
| secondaryAddressVisibility | selectVisible | false |
| step3Key |  | Prop to re-render step 3 = 1 |
| triedServerForInception |  | false |
| triedServerForQuote:true |  | true |
| validInceptionResponseReceived |  | false |
| validQuoteResponseReceived |  | true |
| velosureIpidDocument |  | Current document, populated by step 2 visible |
| velosureTermsOfBusinessDocument |  | Current document, populated by step 2 visible |

 

 

 

## Validation

 

If the requirement is to go straight to step 3, quote summary, then the validators for steps 1 & 2 should be called first:

 

```
QuoteJourneyValidationService.checkStage1FullyValidQuoteJourneyValidationService.checkStage2FullyValid
```

 

If the intention is to populate the data and start at the beginning then there is no need to do this as it will be triggered by the user progressing through the journey.

 

If the user is presented with the quote summary and then decides to go back and change data which affects the quote then the existing system will handle forcing a re-quote and no additional functionality is required.