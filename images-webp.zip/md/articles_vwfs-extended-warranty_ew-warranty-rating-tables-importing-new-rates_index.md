[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# VWFS Extended Warranty Rating Tables + how to update rates

 

---

 

This article describes how rating works for the VWFS Extended Warranty product and websites. It talks through the various database tables and how they link together and also defines how to update the rating if VWFS were to change their rates.

 

The article assumes you have some knowledge of rating tables in Transactor. If not then you should read the Transactor Product Management documentation on Company Data.

 

## Transactor - Extended Warranty Rating tables

 

---

 

Transactor rating tables allow us to configure complex rating systems that are dependent on a number of risk factors. Data from rating tables can then be used in Transactor scheme files to determine a premium based on the relevant risk factors. Please read the Knowledgebase article on Transactor scheme files for more information on how to do this.

 

The tables containing the raw rating data from VWFS are:

 

- **RATE_AUDI_RATES_V2**
- **RATE_SEAT_RATES_V2**
- **RATE_SKODA_RATES_V2**
- **RATE_VW_RATES_V2**
- **RATE_VWCV_RATES_V2**

 

**Important:** in our **UAT** environment these tables are in both the "dbo" and "TGSLUser" schemas. The tables that matter are those in the "dbo" schema. In our **Live** environment, these tables only exist in the "TGSLUser" schema.

 

### VWCV Model Rating

 

The VWCV rating table differs from the other brands in that it uses the vehicle *model* rather than the engine size as the risk criteria.

 

### VWCV Duplicate Rates - Caddy and Caddy Maxi

 

It is necessary to ensure that rates for the VWCV **Caddy** supplied by VWFS are duplicated, with the *model* replaced with **"Caddy Maxi"**. This is because the Caddy Maxi is recognised as a different model and so no rates are returned unless we introduce this duplication. The script mentioned in the 'Importing' section below will do this for you.

 

### Defining rates by Policy Start Date

 

Additionally, you will need to be aware of the **RATE_EW_DATES_RANGE** table. We use this table to define the timeframe that rates are applicable from and to based on the **Policy Start Date** of the risk being rated. It is referenced as a foreign key in each of the brand-specific rating tables listed above.

 

For new rates, a new row must be added to this table with the relevant **Start Date** and the previous row **End Date** set to expire one second before the new start date.

 

## Transactor - Extended Warranty List Tables

 

---

 

There are several custom "list" tables for Extended Warranty in Transactor:

 

- **LIST_SUBSCRIPTION_TYPE**
- **LIST_COVER_TYPE**
- **LIST_MILEAGE_LIMIT**
- **LIST_VOL_EXCESS**

 

These hold "metadata" defining the cover options (and therefore risk data) for VWFS Extended Warranty each with its own unique identifier; all of which are used in defining unique rate entries in the rating tables.

 

## Transactor - Extended Warranty User Tables

 

---

 

The product-specific database tables for VWFS Extended Warranty are:

 

- **USER_VW_VEHDETS** (vehicle details)
- **USER_VW_PRODCOVR** (cover level options)
- **USER_VW_CLIENTDT** (which is considered redundant - it duplicates data from CUSTOMER_INSURED_PARTY)

 

The **PRODCOVR** table holds the details of the cover level options (e.g. Cover Type, Excess, Annual Mileage etc.). There are a number of fields that are redundant; Extended Warranty originally started life as a Breakdown product but was subsequently hijacked into Extended Warranty.

 

### Rating Criteria

 

The VWFS Extended Warranty product has several rating criteria:

 

- Vehicle details 

- Current Mileage
- Engine Size (in CC)
- Subscription Type ("Day-one" or "Lapsed")
- Cover Type ("All Component" or "Named Component")
- Annual Mileage
- Voluntary Excess

 

**Vehicle Details**

 

The current mileage of the vehicle is compared to a Min and Max mileage range.

 

**Engine Size**

 

The size of the engine (in CC) is compared to a Min and Max CC. Special vehicles (such as a SEAT Leon Cupra or Audi R8) are identified as having a CC of 10,000. Although this isn't an accurate CC of the vehicle, this is used as a special case to separate higher maintenance vehicles from others.

 

**Policy Start Date**

 

As discussed above the policy start date is compared to a Date Range from the RATE_EW_DATES_RANGE table.

 

**Subscription Type**

 

Details on the subscription type.

 

**Cover Type, Annual Mileage and Voluntary Excess**

 

The final three criteria are identified from the risk data directly based on their entries in the relevant LIST tables defined above.

 

**Premium Breakdown**

 

The premium is broken down into its constituent parts, including the NET underwriter premium, Opteven Fee, Connexus Fee, VWFS Fee, VERS Administration charge and the fulfilment fee. These fields are extracted and added to each other in the scheme file to determine the Gross premium (less IPT).

 

### Opteven - Rate Identification

 

The LIBTECH_ID and LIBTECH_VERSION columns make up the unique identifier of the rate from the viewpoint of Opteven who handle the claims for VWFS Extended Warranty.

 

### Importing updated rates in to Transactor from Excel

 

To save a lot of manual work, [Power BI](https://powerbi.microsoft.com) has been used to import the spreadsheet supplied by Opteven. Power BI imports the required worksheets, tidies up the data, moves the columns around, deletes unneeded columns and replaces values from the spreadsheet with the values used in the rating tables. It then adds some SQL formatting to the data, which allows a copy/paste export of data and after a copy/paste to replace TABS with commas, you have the SQL ready to run in to the database.

 

The values that are replaced are as follows (DB value, Spreadsheet Value):

 

- **LIST_SUBSCRIPTION_TYPE**D, DAYONE
L, LAPSED
- **LIST_COVER_TYPE**3BB3DPF8, All Component Cover
3SL01Q14, Named Component Cover
- **LIST_MILEAGE_LIMIT**3SKLU3S6, 10,000
3SKLU4I5, 15,000
3SOMH1F9, over 15,000****
- **LIST_VOL_EXCESS**3SOM1LN6, £0
3SKLSUN9, £100
3SMQ8B71, £250
Process

 

To update the rates, follow this process:

 

**** NOTE: Using Power BI on the shared network is very slow. I created this all locally and it was much quicker. Since moving it to the CompanyData drive, I note that it is significantly slower, and really hammers the CPU. I would suggest developing locally, and them moving to the CompanyData drive to save time. Unfortunately Power BI does not support relative paths, so you will need to modify the data source to local, and back to CompanyData when you have finished (see below on how to do this) ****

 

1). Create a copy of, and then load the Power BI file - "\\192.168.30.18\CompanyData\Connexus Digital\Web Development\BAU\VW Marketing\VWM #218 - Update All Brand EW Rates 01.01.22\Extended Warranty Rates Tidy.pbix"[](/"\\192.168.30.18\CompanyData\Connexus%20Digital\Web Development\BAU\VW Marketing\VWM #218 - Update All Brand EW Rates for AC and NC effective 1st November\Extended Warranty Rates Tidy.pbix")

 

2). Load the new source spreadsheet in to Power BI by changing the Data Source Settings:

 

File -> Options and settings -> data source setting.

 

![c3.PNG](https://community.powerbi.com/t5/image/serverpage/image-id/234962iDA24824A619F5CE1/image-size/large?v=v2&px=999)

 

This will update the source for all the worksheets (rather then editing them all individually in the Advanced Editor).

 

3). Transform the Data - Resolve any import issues, and configure to ensure everything is imported correctly.

 

The area where we define the data structure and transform the data is 'Transform Data'. This is where all the work is done.

 

If the new spreadsheet is exactly the same format as the previous spreadsheet supplied, then no Power BI changes will be needed; the new spreadsheet will simply import and have all its data transformed by Power BI.

 

Chances are, there will be some changes, such as the worksheet names increasing from V10 to V11. There are also numerous typo's in the spreadsheet that are catered for, meaning each worksheets rules are slightly different (although largely the same).

 

Power BI is case sensitive, and there are various differences in the spreadsheet which are catered for. E.g. "Net Premium Insurer" = "Net premium insurer" and "net premium insurer" in some worksheets. Also "annual mileage" = "annual mileag" in some worksheets (missing the "e" off the end).

 

To fix any errors, I found it easiest to use the Advanced Editor where you can see all the steps applied to the process and manually edit them. These can also be changed through the Power BI application too. 'Applied Steps' on the right hand side has small cogs to configure each step applied to the data, so selecting and altering the right one will resolve an error.

 

Clicking on each 'Applied Step' shows the data transformed up to and including the step you clicked on. So clicking on the top step shows the first change, and so on. It is easy to find where the data has gone wrong and amend it by clicking through the steps and visually understanding the changes that are being applied.

 

Once you have all the data in the Transform Data section looking correct and without errors then you are ready to export the data. 

 

4). Export the data

 

Use the 'Copy Entire Table' to copy all the data to the clipboard.

 

![](../images-webp/image_13.webp)

 

Paste it in to a text Editor

 

 

 

5). Amend the exported data

 

You should have something that looks like the following ...

 

![](../images-webp/image_14.webp)

 

![](../images-webp/image_15.webp)

 

Delete the first header line

 

Do a Find/Replace and replace all TABS with a ", " (comma[space]), giving you some valid SQL:

 

![](../images-webp/image_16.webp)

 

6). Update SQL script.

 

Create a copy of the SQL script:

 

"\\192.168.30.18\CompanyData\Connexus Digital\Web Development\BAU\VW Marketing\VWM #218 - Update All Brand EW Rates 01.01.22\#218 New EW Rates 01.01.2022.sql"

 

Modify the start date of the new rates in the script. The script will end date the previous version automatically, and use a new ID for the date.

 

![](../images-webp/image_17.webp)

 

Update the script with the updated rates from Step 5. To do this, just Copy/Paste your new rates over the top of the existing rates in the script.

 

Repeat this for each set of rates from Power BI in to the SQL script - 10 in total.

 

It may be best to delete all the SQL adding the rates from the script first, and then paste each new set in place, leaving the comments in place for each set of rates.

 

This script also copies the '**Caddy**' model rates to '**Caddy Maxi**'.

 

7). Run the SQL

 

Run the new SQL script to add the rates - you will note the script has a BEGIN TRAN and ROLLBACK TRAN, so you will need to modify this or remove those lines in order to commit the transaction.

 

8). Check the database looks correct.

 

Use the SQL script:

 

"\\192.168.30.18\CompanyData\Connexus Digital\Web Development\BAU\VW Marketing\VWM #218 - Update All Brand EW Rates 01.01.22\Test EW Rates.sql"

 

This script will do the following:

 

Show the RATE_EW_DATES_RANGE table

 

![](../images-webp/image_18.webp)

 

Show the count of each set of rates for the old and new rates - these should match (unless the data has changed structure, in which case the scheme will have needed to be modified)

 

![](../images-webp/image_19.webp)

 

Show each rates table sorted by the same rates version, so you can visually see if the rates look sensible against the previous set. I.e. have they increased slightly and all columns complete as expected against the source data?

 

![](../images-webp/image_20.webp)

 

9). That's all folks :-)