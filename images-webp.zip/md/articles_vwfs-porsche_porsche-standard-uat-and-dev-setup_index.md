[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Porsche Standard UAT and Dev setup

 

---

 

**Code branch**

 

InsureWithPorsche\Branches\AnnualJourney-Multi-Vehicle

 

**Umbraco databases**

 

There are separate databases set up for UAT and Dev instances of Umbraco so it does not interfere with the current/trunk UAT and Live versions. Both UAT and Dev databases for Porsche Standard are located on SQL Server 192.168.200.113:

 

- UAT: InsureWithPorscheUmbraco_Annual_UAT
- Dev: InsureWithPorscheUmbraco_Annual_Dev

 

**Connexus config database:**

 

The config is populated from the ConnexusConfig database located on SQL Server 192.168.200.113. *Note, this is different to current/trunk UAT and Dev versions.*

 

**Chubb Scheme:**

 

Scheme number for both UAT and Dev is provided from the above *Connexus config database* and it's: 1404