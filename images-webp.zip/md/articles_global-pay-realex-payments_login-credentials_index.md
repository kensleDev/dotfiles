[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Globalpay login credentials

 

---

 

**GlobalPay credentials**

 

**Developer**

 

**ClientID**

 

dev025479531178854021

 

**Developer area login**

 

[https://developer.globalpay.com/user/login](https://developer.globalpay.com/user/login)

 

Username: development@connexus.co.uk

 

Password: See KeePass

 

**Portal for payments**

 

[https://realcontrol.sandbox.realexpayments.com/#/login](https://developer.globalpay.com/user/login)

 

ClientID: dev025479531178854021

 

Username: admin

 

Password: See KeePass

 

**Sub accounts**

 

Pre SCA v2 – one account for all

 

- internet

 

SCA v2 sub accounts

 

- Audi
- SEAT
- Skoda
- Velosure
- Volkswagen
- VWCV

 

Shared Secret (all accounts): v27oMPqZHH

 

 

 

**Live**

 

**ClientID**

 

lawshield

 

**Portal for payments**

 

[https://realcontrol.realexpayments.com/#/login](https://realcontrol.realexpayments.com/#/login)

 

Client ID: lawshield

 

Username: see below

 

Password: see below

 

For login credentials, you will require your own account. Contact Steven Sheath in accounts to arrange this.

 

**Sub accounts**

 

Pre SCA v2

 

- Internet
- Porsche – Porsche actually uses SagePay, assume this is for manual payments when needed.
- Volkswagen

 

SCA v2 sub accounts

 

- AudiSCAv2
- SEATSCAv2
- SkodaSCAv2
- VelosureSCAv2
- VolkswagenSCAv2
- VWCVSCAv2

 

Shared Secret (all accounts): SqtFUXSVqS

 

 

 

Payment Account Credentials

 

Moved to [Payments API Main](/articles/payments-api/api-main/)