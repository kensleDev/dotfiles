[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Heartcore - working with Deploy

 

---

 

[This video](/media/pswl0fv0/heartcore-working-with-deploy-v2.mp4) is an introduction to deploying and transferring changes between Umbraco HeartCore environments as well as best practices for the process. Areas covered are:

 

- Recommended workflow
- Deploying deletions
- Schema mismatches
- Content transfer dependencies
- Recreating environments