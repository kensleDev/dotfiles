[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Why Production InsureWith Sites have an Admin Instance

 

---

 

PRODWEB03 has an additional instance, the ‘admin’ version. This instance helps to mask the fact that the site is powered by Umbraco and provides a way to access the umbraco portal.

 

In the UAT environment we can append '/umbraco' e.g.

 

```
http://insurewithAudi.connexus-test/umbraco
```

 

In the Production environment this is hidden and the 'Admin' version is called instead e.g.

 

```
https://admin.insurewithaudi.co.uk/umbraco
```

 

In addition, when media files (images, pdf’s etc) are added, it is this instance of the site (more specifically, it’s ‘Media’ folder) that holds the updates. This is important to note.

 

Unlike UAT, appending ‘/umbraco’ to the URL will actually cause a redirect and the user will be transferred to the Home page. This Url Rewrite rule is set is IIS and is also available in web.config. This must not be deleted.

 

###### How to edit/view this configuration

 

Within IIS on PRODWEB03, select site and choose URL Rewrite

 

```

```

 

Inbound rules

 

```

```

 

Edit a rule

 

```

```

 

This is also available in the web.config

 

```

```