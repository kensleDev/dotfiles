[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Velosure Deployments

 

---

 

## If releasing to live and the schema has changed

 

---

 

Login to the Umbraco Cloud. Please see this article for our [Umbraco Heartcore Environment](/articles/website-content-management/connexus-heartcore-environment/)

 

Go to project **Velosure**

 

Deploy changes to live

 

## If releasing to live and there is new Umbraco content to publish

 

---

 

Login to the Velosure Dev Umbraco environment. Please see this article for our [Umbraco Heartcore Environment](/articles/website-content-management/connexus-heartcore-environment/)

 

For each Content or Media element that has changed:

 

- Click on the ellipsis next to the element
- Click Do something else
- Click Queue for transfer

 

## If releasing to UAT

 

---

 

Open the Velosure project in Visual Studio

 

Increment the Package version, Assembly version and Assembly file version in Velosure -> Properties -> Package tab:

 

![](../images-webp/image_23.webp)

 

Add a label by right-clicking on Velosure in Source Control Explorer and selecting Advanced -> Apply Label. The Name should be the version number suffixed with UAT, and the Comment a description of what has changed in this version:

 

![](../images-webp/image_24.webp)

 

Right-click on the Velosure project in Solution Explorer and select Publish. Select Staging and click Publish:

 

![](../images-webp/image_25.webp)

 

If you get an error "Error getting the active projectSystem.ArgumentException: Value does not fall within the expected range." clean the project and delete the contents of the Obj folder

 

This will build the C# and JavaScript for UAT and create a UAT deployment in C:\DEPLOYMENTS\Velosure; it takes a while

 

## If releasing to live

 

Open the Velosure project in Visual Studio

 

Take note of the version number in UAT and get this version from TFS by right-clicking on Velosure in Source Control Explorer and selecting Advanced -> Get Specific Version, selecting Label from the Version Type dropdown, and selecting the required label:

 

![](../images-webp/image_26.webp)

 

Right-click on the Velosure project in Solution Explorer and select Publish. Select Release and click Publish:

 

![](../images-webp/image_27.webp)

 

If you get an error "Error getting the active projectSystem.ArgumentException: Value does not fall within the expected range." clean the project and delete the contents of the Obj folder

 

This will build the C# and JavaScript for production and create a production deployment in C:\DEPLOYMENTS\Velosure; it takes a while

 

## All releases

 

---

 

In Windows Explorer, navigate to C:\DEPLOYMENTS\Velosure and zip up the contents using 7-zip, type zip.

 

DO INCLUDE ALL FILES!!

 

Copy the zip folder to the desktop of DEVWEB01 (192.168.204.217) for a UAT release or PRDWEB05 (192.168.104.4) for a live release

 

### Preparing the deployment

 

Create a new folder v*x*.*y*.*z* in C:\inetpub\wwwroot\Velosure, where x.y.z is the version number

 

Unzip the zip file into the above folder

 

Right-click -> Properties -> Security in the new folder and Edit

 

If IIS_IUSRS is not there, Add, select the root folder under Locations, enter IIS_USRS, and allow Full Control. If it does exist, check the permissions are Full Control

 

If IUSR is not there, Add, select the root folder under Locations, enter IUSR, and allow Full Control. If it does exist, check the permissions are Full Control

 

## If releasing to live

 

---

 

Login to PRDWEB06 (192.168.104.218), open Windows Explorer and copy the zip file from *\\192.168.104.4\c$\Users\(your* username)\Desktop to the Desktop

 

Repeat the "*Preparing the deployment*" section from *All releases* above on this server

 

Delete the zip files from PRDWEB05 & PRDWEB06

 

## On the night

 

---

 

Login to PRDWEB05 (192.168.104.4) and open IIS

 

In Sites > Velosure > Basic Settings, change the physical path to the new folder created above

 

Restart

 

In Application Pools > Velosure Recycle

 

Reapeat the above for PRDWEB06 (192.168.104.218)

 

Test