[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Proclaim API - Architecture

 

---

 

## Introduction

 

The purpose of the API is to abstract away the unpleasantness of Proclaim and to be able to use it in an object-oriented manner. Currently only the **Claim Tracker** utilises this API.

 

The technology used in the Proclaim API comprises:

 

- Microsoft .NET Core 3.1
- Microsoft .NET Standard 2.1
- ASP.NET MVC Core
- Entity Framework Core
- Microsoft SQL Server

 

## Application Architecture

 

The website has the following projects:

 

- **ConnexusServices.ProClaim** - the API
- **ConnexusServices.ProClaim.Common** - common models used by the API and service-layer
- **ConnexusServices.ProClaim.Services** - major service-layer implementations
- **ConnexusServices.ProClaim.TokenGenerator** - console app to generate a token

 

These projects are source controlled in an Azure DevOps "Project"; **ConnexusServices.ProClaim**, under C*onnexus* -> *ConnexusServices*. This project has a master 'trunk' code line.

 

#### Integrations

 

The website integrates with one internal system:

 

- **Proclaim** - for creation and retrieval of claim data