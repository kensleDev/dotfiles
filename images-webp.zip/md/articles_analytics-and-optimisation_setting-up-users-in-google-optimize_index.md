[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Setting up users in Google Optimize

 

---

 

## Introduction

 

Users need to be invited to access the account, and also need to their permissions setup against a container.

 

### Inviting a user to access the account

 

If this is the first experiment in a container, or the user does not already have access to that container:

 

In the Optimize All Accounts screen:

 

1. On the container in the All Accounts page, click on the Manage users icon in the top right corner
2. Click **+** and select **Add users**
3. Enter the **email address**
4. Ensure the User checkbox is checked
5. Click **Set all** against Container permissions and check **Read**
6. Click **Done** and **Invite**

 

### Setting user permissions for a container

 

In the Optimize All Accounts screen:

 

1. Click the **ellipsis** to the right of the container
2. Select **Manage Users**
3. Click **+** and select **Add users**
4. Enter the **email address**
5. Ensure the **Read** checkbox is checked
6. Click **Invite**

 

The VWFS account is **insurewithreporting@gmail.com**