[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Home Emergency

 

---

 

Home Emergency will provide assistance in the event of certain home emergencies, which impact the safety and security of a home, potentially rendering it uninhabitable.
Cover will be provided for rapid expert help using a national network of contractors to assist and stabilise the problem.
Our Home Emergency cover complements the main home insurance policy and provides peace of mind for customers.
The cover is provided for labour, parts and materials to carry out emergency repairs.

 

## Product Details

  **Product Reference:** HMEMERG **Product Type Id:** 431  

---

 

## Schemes

 

- [Home Emergency](/insurance-products/lawshield-dsp-b2b/home-emergency/home-emergency/)

 

---