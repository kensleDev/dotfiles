[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Visual Studio Publish of Insure with websites

 

---

 

## Missing JavaScript when Publishing

 

The VWFS Insure with websites (excluding Porsche) make heavy use of a 'shared' codebase. From a C# and .NET perspective, this doesn't impact on publishing a deployment from Visual Studio; all necessary libraries and DLLs will be included as necessary in the /bin folder of the website.

 

However, the method used to share JavaScript source between the websites means that the transpiled JavaScript from the **RefreshMvc.Typescript** project *is not included* in the publishing of deployments from Visual Studio.

 

The vast majority of the JavaScript implemented in the Insure with websites is copied from the **RefreshMvc.Typescript** project into the **/Scripts** folder of the relevant front-end website project when running building in Visual Studio. Given that this set of files could be rapidly changing each time, they aren't included in the project; rather they just reside within the physical /Scripts folder.

 

## Including JavaScript in Publish

 

The front-end website should be built and published as you would normally expect from within Visual Studio. This will create a deployment build in the **C:\DEPLOYMENTS** folder locally.

 

Then navigate to the **/Scripts** folder *in your local source controlled folder* and copy the entire contents of the folder, and paste it into the equivalent /Scripts folder within the deployment build just created in your C:\DEPLOYMENTS folder. This will then include the JavaScript in your deployment.