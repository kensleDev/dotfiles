[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# EW - Customer Communications - Emails and Letters

 

---

 

## Introduction

 

Connexus use two platforms to send out customer communications regarding VWFS Extended Warranty:

 

- **Actito** - used for initial customer invitations towards the end of a Manufacturer or Approved Used Warranty
- **Transactor** - for all other customer communications, including Confirmation of Cover and Renewals

 

## Actito Extended Warranty Invitations

 

The initial Extended Warranty invitation emails are sent to prospective customers nearing the end of their Manufacturer or Approved Used Warranty from the **Actito** (formerly SmartFocus) platform. The email templates are managed and maintained by the Marketing department, and the scheduling of the emails is driven by an export and import process, managed by the MI department using data in the VMS database.

 

## Transactor Emails and Letters

 

Extended Warranty communications, including but not limited to Confirmation of Cover and Renewal invitations are managed, maintained and distributed using **Transactor**. Most often these are sent automatically using the *Events and Triggers* functionality built-in to Transactor.

 

The email and letter templates are managed and maintained by the development team. As such they are held in Azure DevOps alongside the codebase for each brand website:

 

- **Audi** - $/InsureWithAudi/TransactorTemplates/ExtendedWarranty
- **SEAT** - $/InsureWithSeat/TransactorTemplates/ExtendedWarranty
- **SKODA** - $/InsureWithSkoda/TransactorTemplates/ExtendedWarranty
- **Volkswagen** - $/InsureWithVolkswagen/TransactorTemplates/ExtendedWarranty
- **VWCV** - $/InsureWithVWCV/TransactorTemplates/ExtendedWarranty

 

### Emails

 

There are fifteen email templates per brand:

 

| Template Name | Purpose |
| --- | --- |
| ew_confirmation_of_cover.html | Confirmation of Cover email for annual payments |
| ddi_confirmation_of_cover.html | Confirmation of Cover email for direct debit payments |
| ew_existing_customer_renewal.html | Standard renewal invitation |
| ew_existing_customer_renewal_expire.html | Renewal email where it is believed the customer is no longer eligible for Extended Warranty |
| ew_existing_customer_renewal_final.html | Renewal invitation reminder |
| ddi_ew_advance_notice.html | Sent to acknowledge a change in direct debit payments and/or date |
| ddi_ew_failed_direct_debit_40.html | Sent when a direct debit fails to be taken from the customer's bank account |
| ddi_ew_generic_please_call_us_20.html | Sent when there is an issue with the policy or payment |
| ddi_ew_generic_claim_21.html | Sent when a direct debit fails to be taken from the customer's bank account, and there is a claim on the policy |
| ddi_ew_new_account_details_30.html | Sent to acknowledge a change in the bank details for a direct debit |
| ddi_ew_policy_cancelled_customer_requested_60.html | Sent to acknowledge cancellation of a policy at the customer's request |
| ddi_ew_policy_terminated_customer_contacted_50.html | Sent to inform the customer of the cancellation of their policy |
| ddi_ew_policy_terminated_failed_contact_51.html | Sent when the customer has failed to acknowledge the cancellation of their policy |
| ddi_ew_response_to_cancellation_request_70.html | Sent to acknowledge a customer's request to cancel their policy, indicating any outstanding monies owed to either party |
| ddi_ew_update_payment_80.html | Sent to acknowledge a change in the payment date of a direct debit |

 

Some of these template names may vary slightly from brand to brand, but they serve the same purposes.

 

### Letters

 

There are seventeen letter templates per brand, plus a Confirmation of Cover document. The table below uses names from the Audi brand; the other brands identify with different prefix codes specific to the brand:

 

- **AU** - Audi
- **SE** - SEAT
- **SK** - SKODA
- **VW** - Volkswagen
- **CV** - VWCV

 

| Template Name | Purpose |
| --- | --- |
| AU001A - EW Existing customer renewal letter.doc | Standard renewal invitation letter |
| AU001B - EW Existing customer renewal reminder letter.doc | Standard renewal invitation reminder letter |
| AU001C - EW Existing customer renewal over 100k letter.doc | Renewal letter where it is believed the customer is no longer eligible for Extended Warranty |
| AU001D - EW Existing customer renewal letter 4years.doc | Standard renewal invitation letter where the customer is renewing for the fifth time |
| AU002A - EW Confirmation of Cover (Annual) letter.doc | Covering letter for Confirmation of Cover when paid for by card |
| AU002B - EW Confirmation of Cover (Direct Debit) letter.doc | Covering letter for Confirmation of COver when paid for by Direct Debit |
| AU002C - EW Confirmation of Cover (Annual) letter.doc | Covering letter for Confirmation of Cover when paid for by card and email encryption was not possible |
| AU002D - EW Confirmation of Cover (Direct Debit) letter.doc | Covering letter for Confirmation of COver when paid for by Direct Debit and email encryption was not possible |
| AU003A - EW Direct Debit change (from customer) confirmation letter.doc | Sent to confirm changes to Direct Debit details when requested by the customer |
| AU003B - EW Direct Debit change (from bank) confirmation letter.doc | Sent to confirm changes to Direct Debit details when requested by the customer's bank |
| AU004 - EW Direct Debit failed letter.doc | Sent to inform the customer of a failed Direct Debit payment |
| AU005 - EW Direct Debit problem (with claim) letter.doc | Sent to inform the customer of a failed Direct Debit payment where there is a claim on the policy |
| AU006A - EW Cancellation confirmation (customer request) letter.doc | Sent to acknowledge cancellation of a policy at the customer's request |
| AU006B - EW Cancellation confirmation (no contact, outstanding balance no claim) letter.doc | Sent to inform the customer of the cancellation of their policy when an attempt has been made to contact them and there is an outstanding balance to be paid |
| AU006C - EW Cancellation confirmation (no contact outstanding balance, with claim) letter.doc | Sent to inform the customer of the cancellation of their policy when an attempt has been made to contact them and there is an outstanding balance to be paid, and there is a claim on the policy |
| AU006D - EW Cancellation confirmation (no contact, refund due) letter.doc | Sent to inform the customer of the cancellation of their policy when an attempt has been made to contact them and there is a refund due to the customer |
| AU007 - EW Cancellation fee request letter.doc | Sent to inform the customer of the cancellation fee which must be paid upon cancellation |
| Extended_Warranty_Confirmation_of_Cover.doc | Provides confirmation of insurance to the customer and acts as a Statement of Fact including the cover details provided. |

 

Again, some of these template names will vary slightly from brand to brand.