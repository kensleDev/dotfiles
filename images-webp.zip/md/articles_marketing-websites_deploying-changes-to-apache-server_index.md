[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Deploying to Live Apache Server

 

---

 

#### Merging dev into the UAT master

 

After merging the branch with your changes onto the dev branch on GitHub or Azure, do the following:

 

- In [Putty](https://www.putty.org/#https://www.putty.org/), open your development server.
- Navigate into the folder than contains the project you need: **cd /var/www/project**
- Show all folders with ls- la
- Cd into the htdocs folder > cd htdocs
- Run git commands in this folder.

 

- **sudo git status**. Enter your server password. To enter just right-click, not Ctrl-v.
- Check what branch you’re on here. If on *master*, go to *dev* with **sudo git checkout dev**. If merging into staging dev, go to the branch you would like merge – then do **sudo git pull**
- Before you run those, have a think about what you've already done - on Github, have you just merged the branch into dev, so if the staging site is already on dev, all you need to do is run **sudo git pull** (or the updated way is to specify the branch you want to pull **sudo git pull origin dev** )
- However, if you're trying to checkout a new branch, you first need to tell git to check for any new branches with **sudo git fetch** then your command should work. Alternatively, you can do it in a single command by qualifying the branch name with origin, so **sudo git checkout origin addition/BI-form-new-field** for instance.
- Ctrl-X if there is the contents of the commit message showing
- **Now check the UAT website for your changes and test.**
- Ctrl-X when done.
- If the .env file is not the same, you can update it manually.
- Create pull request on Github to merge dev into live.
- It will be base:main and compare:dev. Add a descriptive name of the changes in heading.
- Merged when approved.

 

#### Pushing master into the live server

 

- Go to production server in Putty
- Same as dev to get into htdocs (if no htdocs, just do it in the project folder).
- If merging into live, go to *master*(if not already on it) with **sudo git checkout master**
- Change .env to what it needs to be for the live server:

 

1. Right-click to paste (no keyboard shortcuts)
2. Add updated passwords etc
3. Ctrl-X saves and closes
4. Press Y and enter to close

 

- **Sudo git status**
- **sudo git pull origin master**
- Check live website for changes

 

 

 

##### Uncaught ReferenceError: route is not defined

 

- In the site’s directory on Putty, run **composer install**.
- You might have to change the owner of the site’s files to www-data (that's the user that gets created by Apache)
- To do this: **sudo chown www-data:www-data -R /var/www/project/htdocs**
- Then try **composer install** again
- You then may have to try **php artisan view:clear** after adding

 

*Vue.mixin({ methods: { route }});*

 

to app.js if you are getting @routes due to Ziggy.

 

##### If it says that ‘Your local changes to the following files would be overwritten by merge’:

 

**sudo git stash**

 

**sudo git pull origin dev (or master)**