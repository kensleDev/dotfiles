[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Motor Elite Extra

 

---

 

Our Motor Elite Extra Legal Protection product provides all of the benefits of our standard [Motor Legal Protection](/insurance-products/lawshield-dsp-b2b/motor-elite/) product and also provides a replacement hire vehicle if needed.

 

## Product Details

  **Product Reference:** MTREXAM **Product Type Id:** 672  

---

 

## Schemes

 

- [Motor Elite Extra AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite-extra/motor-elite-extra-amtrust/)
- [Motor Elite Extra Panel Van AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite-extra/motor-elite-extra-panel-van-amtrust/)
- [Motor Legal Protection Extra with Hire Car S1 Class AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite-extra/motor-legal-protection-extra-with-hire-car-s1-class-amtrust/)
- [Motor Legal Protection Extra with Hire Van PV2 Class AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite-extra/motor-legal-protection-extra-with-hire-van-pv2-class-amtrust/)
- [Motor Legal Protection Extra with Upgraded Hire Car P5 Class AmTrust](/insurance-products/lawshield-dsp-b2b/motor-elite-extra/motor-legal-protection-extra-with-upgraded-hire-car-p5-class-amtrust/)

 

---