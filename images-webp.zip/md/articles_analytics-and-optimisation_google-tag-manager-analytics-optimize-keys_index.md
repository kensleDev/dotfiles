[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Google Tag Manager, Analytics & Optimize Keys

 

---

 

## Google Tag Manager

 

Velosure is in the Velosure Account

 

### Live

 

All live VWFS Containers are in the Connexus Account

 

- Audi: GTM-TXC6XK
- Porsche: GTM-MLP5B82
- SEAT: GTM-T6JS2RD
- Skoda: GTM-PVPHZW
- VW: GTM-5RVRTC
- VWCV: GTM-KP9KXBD
- Velosure: GTM-P2T73NN
- Velosure GA4:GTM-P8CX5TS

 

### UAT

 

All VWFS UAT Containers are in the VWFS Account

 

- Audi: GTM-N7WDVL2
- SEAT: GTM-W3S865J
- Skoda: GTM-PCPQH77
- VW: GTM-KJ4RGXM
- VWCV: GTM-5X5QKR2
- Velosure: N/A
- Velosure GA4:GTM-NMVDPNC

 

## Google Analytics

 

### Live

 

 

 

| BRAND | UA | GA4 Property Name | Property Id | Measurement ID |
| --- | --- | --- | --- | --- |
| Audi | UA-23869986-1 | LIVE Insure with Audi - GA4 | 381983898 | G-LQ4T4HLED0 |
| SEAT | UA-165030466-1 | LIVE Insure with SEAT - GA4 | 382413637 | G-LDSD1MHT3P |
| SKODA | UA-23871605-1 | LIVE Insure with Skoda - GA4 | 382629390 | G-3K3PE9SMRG |
| Volkswagen | UA-23870497-1 | LIVE Insure with Volkswagen - GA4 | 382619347 | G-CWPJTZ1VE2 |
| VWCV | UA-87284222-1 | LIVE Insure With VWCV - GA4 | 382611322 | G-TPBBV0CC45 |
| Porsche | UA-106862194-1 | Live_Classic_Insurance | 334296035 | G-YMBEQJC75R |
| Velosure | UA-119995630-6 | Velosure GA4 | 351532898 | G-BBKKW550X3 |

 

### UAT

 

 

 

| BRAND | UA | GA4 Property Name | Property Id | Measurement ID |
| --- | --- | --- | --- | --- |
| Audi | UA-165030466-2 | Insure with Audi - GA4 | 381960455 | G-18PZ49MJM4 |
| SEAT | UA-165030466-1 | Insure with SEAT - GA4 | 382618108 | G-J803SV59S2 |
| SKODA | UA-165030466-4 | Insure with Skoda - GA4 | 382399498 | G-WKDFTMY4VP |
| Volkswagen | UA-165030466-5 | Insure with Volkswagen - GA4 | 382624120 | G-N1FP7EXRF8 |
| VWCV | UA-165030466-6 | Insure with VWCV - GA4 | 382617429 | G-YK71TJ9ZZ6 |
| Porsche | N/A | Classic_Car_Insurance | 333721150 | G-7GD5J0L0D5 |
| Velosure | N/A | Velosure 2022 | 334314866 | G-RZD0307369 |

 

## Google Optimize

 

All VWFS Containers are within the VWFS Account

 

### Live

 

- Audi: OPT-T6LCGNV
- Porsche: N/A
- SEAT: OPT-TV9VQML
- Skoda: OPT-TTXHPL4
- VW: OPT-MNWL7W3
- VWCV: OPT-5PLVMCK
- Velosure: N/A

 

### UAT

 

- Audi: OPT-NMPL27J
- Porsche: N/A
- SEAT: OPT-NP2KQRV
- Skoda: OPT-TXVK8GQ
- VW: OPT-PVKH8HT
- VWCV: OPT-NR753VK
- Velosure: N/A