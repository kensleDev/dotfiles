[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Updating an Email Address

 

---

 

This should normally be done via the intranet. However in case there are any issues it would be worth having access to the script that the intranet app was based on. Note that this was later considered to be incorrect as it updates every instance of an email address rather than just those which relate to the specific policy, and it may be that an old email address was correct for older policies but not for newer ones. In addition, the warranty table may also need updating which is not handled by the intranet

 

```
DECLARE@policy_number nvarchar(20) = 'EWC000000',@old_email_address nvarchar(255) = 'a@b.com',@new_email_address nvarchar(255) = 'c@d.com';SELECT TOP 10 *--UPDATE cip--SET--EMAIL = @new_email_addressFROM CUSTOMER_INSURED_PARTY cipJOIN CUSTOMER_POLICY_LINK cpl ON cip.INSURED_PARTY_ID = cpl.INSURED_PARTY_IDJOIN CUSTOMER_POLICY_DETAILS cpd ON cpd.POLICY_DETAILS_ID = cpl.POLICY_DETAILS_IDWHERE cpd.POLICYNUMBER = @policy_number OR cip.EMAIL = @old_email_address;SELECT TOP 10 *--UPDATE uvc--SET--EMAIL = @new_email_address,--RETEMAIL = @new_email_addressFROM USER_VW_CLIENTDT uvcJOIN CUSTOMER_POLICY_DETAILS cpd ON cpd.POLICY_DETAILS_ID = uvc.POLICY_DETAILS_IDWHERE cpd.POLICYNUMBER = @policy_number OR uvc.RETEMAIL = @old_email_address;
```

 

If this returns the required results, comment out the SELECT clauses, uncomment the UPDATE clauses and re-run

 

 

 

## Update the Warranty table

 

This is not done in the intranet

 

```
DECLARE @oldEmail NVARCHAR(MAX) = 'old_email_address';DECLARE @newEmail NVARCHAR(MAX) = 'new_email_address';SELECT TOP 10 w.email, * FROM [VWFSMarketing].dbo.Warranty w WITH (NOLOCK)WHERE w.email in (@oldEmail, @newEmail);--If this needs updating, run the following SQL:BEGIN TRANDECLARE @oldEmail NVARCHAR(MAX) = 'old_email_address';DECLARE @newEmail NVARCHAR(MAX) = 'new_email_address';UPDATE [VWFSMarketing].dbo.WarrantySET Email = @newEmailWHERE email = @oldEmail;ROLLBACK--COMMIT
```