[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Adding an MVC controller + template + Document type

 

---

 

Usually adding a new document in Umbraco doesn't result in a c# controller being added in the solution. In the following example we needed to add a Quote Summary page in Umbraco so we could interface with the EW journey (insureWith sites) a little easier.

 

The 'missing piece' for me was the fact the controller needed to be named appropriately matching that of the template name. Also the controller needs to inherit 'RenderMvcController' not surfaceController.

 

Here is the step by step for creating a Quote Summary