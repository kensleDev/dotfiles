[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Specters

 

---

   

## Website Details

  **Live URL:** [https://www.specters.co.uk/](https://www.specters.co.uk/) **UAT URL:** []()      

---

 

This is the main hub for all of our legal services. Some areas are redirected to MNS or Cycle Accident for more information.

 

| URL | https://www.specters.co.uk/ |
| --- | --- |
| Admin URL | https://specters3.connexus.co.uk/ |
| CMS | Cockpit 0.8.11 |
| PHP version | ~7.2.19 |
| Location | prd-ubuntu-20 |
| Database location | N/A (SQLite hosted with CMS) |
| SSL Cert | IT issue, on prd-ubuntu-20 |
| SSL Expires | June 30, 2024 |