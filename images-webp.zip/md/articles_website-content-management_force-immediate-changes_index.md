[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Force immediate changes

 

---

 

Changes made to the production Admin CMS may not propagate immediately to the front end sites. Once the content has been saved and published on the admin site (e.g. Admin.InsureWithSeat.co.uk/umbraco) The following process can be done to ensure the changes are public.

 

Using Remote Desktop visit the production servers (PRODWEB03 / PRODWEB04) in turn

 

In IIS - select the required site

 

-> Add Bindings

 

-> Add new - setting it as Port 81

 

-> URL Rewrite

 

-> Disable the 'BackOffice' rule (DO NOT DELETE)

 

This will allow you to visit the /umbraco content of the production sites.

 

Once complete,

 

-> re-enable the URL rewrite rule

 

-> remove binding for port 81