[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Google Pay - Setup and Testing

 

---

 

# Setup

 

The google pay button has one of the clearer [setup steps](https://developers.google.com/pay/api/web/guides/tutorial#add-button), the only quirk for this one specifically, is that the required [JS file](https://developers.google.com/pay/api/web/guides/tutorial#js-load) for the payments API it not small and as such the button load in most examples for google pay makes use of the script > onload function to create the actual button. this has caused a few issues in react, so we are using the[google-pay/button-react](https://www.npmjs.com/package/@google-pay/button-react) instead for this website. The contents and goal are essentially the same, to provide the button that will return a payment token from the google pay API, 

 

for this button we're intercepting the [onPaymentAuthorised](https://developers.google.com/pay/api/web/guides/tutorial#authorize-payments)

 

```
function onPaymentAuthorized(paymentData) {  return new Promise(function(resolve, reject){    // handle the response    processPayment(paymentData)    .then(function() {      resolve({transactionState: 'SUCCESS'});    })    .catch(function() {      resolve({        transactionState: 'ERROR',        error: {          intent: 'PAYMENT_AUTHORIZATION',          message: 'Insufficient funds',          reason: 'PAYMENT_DATA_INVALID'        }      });    });  });}
```

 

The paymentData returned above contains the token we need so we're intercepting this to be sent to the API.

 

# Testing

 

You'll need a valid google pay account 

 

if correctly enabled you should see cards similar to this in the selection options:

 

![UI](https://developers.google.com/static/pay/api/images-webp/testcard.webp)

 

 

 

**GlobalPay Quirks.**

 

Google pay authorisation (or failure) is handled by the value submitted to the google pay button. (this can not be handled via the api directly therefore (although the values submitted to both must match. 

 

Testing codes can be found here: [Global Pay - Google Testing](https://developer.globalpay.com/resources/test-card-numbers#google-pay)