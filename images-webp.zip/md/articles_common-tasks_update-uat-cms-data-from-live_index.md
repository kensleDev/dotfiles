[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Update UAT CMS data from Live

 

---

 

**Two main tasks -**

 

1. Use RedGate SQL Data Compare to bring the live database down to UAT
2. Take a copy of the /Media folder from the live 'admin' site and overwrite the UAT /Media folder. You'll likely have to .zip - they're normally 100+MB

 

**Task 1**

 

- Open RedGate SQL Data Compare 13 software
- Select the source as the live site, the target will be UAT as in

 

![](../images-webp/image_73.webp)

 

Then click compare now. Save this project 

 

 

 

Results screen 

 

![](../images-webp/image_74.webp)

 

Click DEPLOY to commit (after lots of warnings) 

 

Do this for each brand if required 

 

**TASK 2 Copying the media folder**

 

Use RDM to open the 'live' server **PRDWEB03 192.168.105.105** 

 

Use IIS to locate the Seat Admin site 

 

![](../images-webp/image_75.webp)

 

 

 

Zip up the contents of the media folder and copy the zip to local desktop. Ignore the web.config file in the media folder 

 

Open **DEVWEB01 (192.168.204.217)** 

 

Copy zip to the server desktop 

 

Use IIS to locate the media folder and unzip the content here after creating a backup. DOUBLE CHECK BRAND!!!!! 

 

Restart the site in UAT IIS