[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Email API

 

---

   

## Website Details

  **Live URL:** [https://email-api.lawshield.co.uk](https://email-api.lawshield.co.uk) **UAT URL:** [https://email-api.connexus-test.co.uk/](https://email-api.connexus-test.co.uk/)    C# .NET Core 6   

---

 

#### Summary

 

This is a micro service of sorts written in dot net 8, it's purpose is to standardise sending email across all our applications / websites and remove the need to rewrite an email client in any applications / websites that might need to, replace that task with a simple API call.

 

This API is documented with swagger, which can be [found here](https://email-api.connexus-test.co.uk/swagger/index.html) which has one pretty simple endpoint to use that is reasonably flexible, allowing basic content to be sent through the content field or pre build html.

 

Set **isContentHTML** flag = true, to pass HTML in the content field.

 

Set **Priority** flag to 'Normal', 'Low' or 'High' - 0 ,1 2 as below

 

```
////
Summary:// Specifies the priority of a System.Net.Mail.MailMessage.public enum MailPriority{//// Summary:// The email has normal priority.Normal = 0,//// Summary:// The email has low priority.Low = 1,//// Summary:// The email has high priority.High = 2}
```

 

The email credentials used and the API Key required to use this API can be found with the appsetting.json