[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Add Goals to Google Analytics

 

---

 

## Introduction

 

**Goals**, also known as **Conversions**, are activities that contribute towards the success of a business. A goal is something that the business would want to measure which could be something as simple as whether the user has viewed a document, but can be more complex such as completing a journey.

 

In this latter case, the steps that are taken to achieve the goal would be defined and can then be viewed in the **Funnel Visualisation** under **Conversions** -> **Goals**. This shows how many users completed the journey, and how many exited the journey at each step, including where they went to.

 

## Setting up a journey as a Goal

 

In Google Analytics:

 

1. Click the **Admin** gear icon in the bottom left
2. Select the correct **Account**, **Property** and **View** from the relevant dropdowns
3. Click **New goal**
4. Google provides some predefined goal templates but we will create a custom goal
5. Select **Custom** for Goal set-up
6. Click **Continue**
7. Enter a **Name**
8. Select **Destination** from the Type radio buttons
9. Click **Continue**
10. Select "Equal to" from the **Destination** dropdown
11. Enter the **target URL**, ensuring **Case sensitive** is left unchecked
12. Leave **Value** off
13. Turn **Funnel** on; this enables previous steps to be defined
14. Enter a **Name** for the entry point
15. Enter the URL of the entry point
16. Switch **Required** on, assuming that the entry point is required
17. Repeat steps 14 & 15 for any subsequent steps in the journey
18. **Save**

 

Note that if there are no goals, the Set up goals screen can also be reached by ensuring the correct **Account**, **Property** and **View** are selected and selecting Conversions -> Goals -> Overview from the menu bar on the left hand side of the screen. The user is warned that there are no goals, click on **Set up goals** to be taken to the Set up goals screen.

 

## Example: The Insure With Extended Warranty Goal

 

- The name of the Goal is "Extended Warranty Purchase"
- The Destination is "/extended-warranty-confirmation"
- The steps are as follows: 

1. Name = "Your Vehicle", Screen/Page = "/extended-warranty"
2. Name = "Your Cover", Screen/Page = "/extended-warranty#your-cover"
3. Name = "Your Details", Screen/Page = "/extended-warranty#your-details"
4. Name = "Payment", Screen/Page = "/extended-warranty#payment"

 

Note that steps 2-4 contain hash properties; this is not supported by GA and needs additional work as described in the next section. 

 

## Caveat: The journey is an SPA

 

The steps of a journey in an SPA may have the same URL and be navigated by visibility, or they may have hash properties which are not supported by GA. In this case the website's navigation code needs to fire a **pageview** trigger to GA that it can utilise. The following generic code snippet shows how that would be done:

 

```
if ("ga" in window) {
    let tracker = ga.getAll()[0];
    if (tracker) {
        tracker.send("pageview", "url-with-hash-property");
    }
}
```

 

## Example: Handling the above caveat in the Insure With sites

 

As can be seen in the Extended Warranty Goal example above, the Insure With sites' JavaScript needs to fire triggers when the /extended-warranty#your-cover, /extended-warranty#your-details and /extended-warranty#payment URLs are navigated to.

 

The following code example is from the SEAT-specific code in *WarrantyTabScopeService.navigateToStep*, and will send a pageview trigger to Google Analytics when any of the specified hash properties are navigated to:

 

```
var stepHashTarget = '';switch (step) {
    case TabSteps.One:
        stepHashTarget = '#your-vehicle';
        break;
    case TabSteps.Two:
        stepHashTarget = '#your-cover';
        break;
    case TabSteps.Three:
        stepHashTarget = '#your-details';
        break;
    case TabSteps.Four:
        stepHashTarget = '#payment';
        break;
}
 
if ("ga" in window) {
    let tracker = ga.getAll()[0];
    if (tracker) {
        tracker.send("pageview", `/extended-warranty${stepHashTarget}`);
    }
}
```