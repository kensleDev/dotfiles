[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Restict Back Office /UMBRACO Access

 

---

 

The regular InsureWith sites ( insureWithAudi etc) Should not have access to Umbraco from the URL - typing [www.insurewithAudi.co.uk/umbraco](http://www.insurewithAudi/umbraco) should redirect to InsureWithAudi.co.uk

 

These rules are set up in the web.config files and look like this...

 

<!-- RESTRICT THE BACK OFFICE FOR THE NON-ADMIN SITE -->

 

 <!-- MAKE SURE THIS IS COMMENTED OUT IN THE ADMIN SITE -->

 

 <rule name="Backoffice access" enabled="true">

 

 <match url="^umbraco(#/)?(#)?(.*)"/>

 

 <conditions logicalGrouping="MatchAll">

 

 <add input="{R:0}" pattern="^umbraco/masterpages/?" ignoreCase="true" negate="true"/>

 

 <add input="{R:0}" pattern="^umbraco/RestServices/?" ignoreCase="true" negate="true"/>

 

 <add input="{R:0}" pattern="^umbraco/webservices/?" ignoreCase="true" negate="true"/>

 

 <add input="{R:0}" pattern="^umbraco/Surface/?" ignoreCase="true" negate="true"/>

 

 <add input="{R:0}" pattern="^umbraco/api/?" ignoreCase="true" negate="true"/>

 

 <add input="{R:0}" pattern="^umbraco/ping.aspx" ignoreCase="true" negate="true"/>

 

 <add input="{HTTP_HOST}" pattern="^(a.com)$" ignoreCase="true" negate="true"/>

 

 </conditions>

 

 <action type="Redirect" url="http://{HTTP_HOST}/"/>

 

 </rule>

 

This code ensures that the regular InsureWith sites do not allow umbraco access.

 

Very Important to note that this *must be commented out in the ADMIN versions* on ProdWeb01 or live access will be blocked.