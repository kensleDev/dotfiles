[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# PRDAPP7

 

---

 

## Server Details

  **Server Type:** Transactor **IP Address:** 192.168.104.74  

---

 

This server is the **Transactor v6 Application Server** for Lawshield DSP products and hosts all Transactor v6 applications and services, including:

 

- TCAS
- TES Tool Suite
- Relationship Manager
- TES Screen Builder
- Relationship Manager Service
- Document Service (incl. MSMQ etc.)
- TES PCEFT Server

 

 

 

---

 

## Insurance Products

 

- [Motor Elite](/insurance-products/lawshield-dsp-b2b/motor-elite/)
- [Motor Elite Extra](/insurance-products/lawshield-dsp-b2b/motor-elite-extra/)
- [Family Select Legal Expenses](/insurance-products/lawshield-dsp-b2b/family-select-legal-expenses/)
- [Equestrian Plan Legal Protection](/insurance-products/lawshield-dsp-b2b/equestrian-plan-legal-protection/)
- [Park Homes and Static Caravan Legal Protection](/insurance-products/lawshield-dsp-b2b/park-homes-and-static-caravan-legal-protection/)
- [Home Emergency](/insurance-products/lawshield-dsp-b2b/home-emergency/)
- [Keycare](/insurance-products/lawshield-dsp-b2b/keycare/)
- [Excess Waiver](/insurance-products/lawshield-dsp-b2b/excess-waiver/)
- [Brokerbility Breakdown Insurance](/insurance-products/lawshield-dsp-b2b/brokerbility-breakdown-insurance/)
- [Landlord Home Emergency](/insurance-products/lawshield-dsp-b2b/landlord-home-emergency/)
- [Landlord Legal Expenses](/insurance-products/lawshield-dsp-b2b/landlord-legal-expenses/)
- [Landlord Rent Guarantee](/insurance-products/lawshield-dsp-b2b/landlord-rent-guarantee/)