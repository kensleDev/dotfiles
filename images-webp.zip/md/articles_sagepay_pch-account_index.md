[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# PCH Account

 

---

 

Performance Car Hire (PCH) have a dedicated SagePay account for taking card payments for hire vehicles. Full details of the account and how to access it are stored in a password-protected document on the CompanyData drive at:

 

- \\db2003b\CompanyData\Connexus Digital\Web Development\Documentation\SagePay\

 

The password for this document is: **S4g3p4y**