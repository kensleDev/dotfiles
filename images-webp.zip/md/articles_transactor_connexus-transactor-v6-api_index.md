[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Connexus - Transactor V6 API

 

---

 

## Introduction

 

### Transactor "Screen Builder" Websites

 

TGSL and their successor OpenGI expect Transactor-based websites to be built in a fully integrated fashion. That is that Transactor is responsible for navigating the user through the journey as per the screens defined within Transactor itself and those followed in the same process in TCAS. This includes all risk data fields being named appropriately so that Transactor itself can recognise them and collect the data itself.

 

This puts a technological restriction on all Transactor-based websites; they must be built using .NET Framework and ASP.NET Web Forms in order to facilitate the direct integration with Transactor.

 

The one remaining example of this form of integration at Connexus is the [Lawshield Digital Sales Platform (DSP)](/websites-and-applications/lawshield-connexus/lawshield-digital-sales-platform-dsp/).

 

### Connexus Transactor Websites

 

Wanting to move forwards with technology; Connexus websites that need to communicate with Transactor have moved away from the "Screen Builder" integration described above to a semi-disconnected architecture. This disconnects the user interface from Transactor but still requires the website to communicate with Transactor via direct integration with its own set of libraries (DLLs). This gives more freedom around the business logic, user experience and journey navigation, and allowed migration to ASP.NET MVC 5, but still ties the website technology base to the .NET Framework.

 

All of the VWFS "Insure with" websites currently use this form of integration with Transactor.

 

## Connexus Transactor V6 API

 

In order to allow for the greatest level of flexibility when implementing new website solutions that require integration with Transactor, a new *middleware* API layer has been created to provide a complete disconnect between the websites and Transactor.

 

The **Connexus Transactor V6 API** takes the responsibility of integrating directly with Transactor via its own set of libraries and exposes the facilities required by insurance websites via a REST API. The API itself is therefore tied to .NET Framework and ASP.NET MVC 5 but allows for complete freedom when selecting a technology base for any new website implementations. As long as the technology selected can communicate with a REST API, it can communicate with Transactor.

 

The [Velosure](/websites-and-applications/lawshield-connexus/velosure/) website is the first example of integration with the Connexus Transactor V6 API.