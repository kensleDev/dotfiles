[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Porsche - Transactor V7 API

 

---

 

## Introduction

 

In contrast with version 6, Transactor version 7 includes a REST API that allows websites to communicate with Transactor without requiring the Transactor DLLs to be integrated directly into the website. The **Insure with Porsche** website makes use of this API via a *wrapper* library implemented by Connexus.

 

## API Documentation

 

The Transactor V7 API integrates Swagger in order to provide documentation and test facilities for the API directly. The **UAT** deployment of this at Rackspace can be found at:

 

[http://192.168.204.116/Transactor.API/swagger/ui/index](http://192.168.204.116/Transactor.API/swagger/ui/index)

 

## Connexus Transactor V7 API Wrapper

 

In order to provide the best possible programming interface to the Transactor V7 API a set of *wrapper* libraries has been implemented at Connexus; the architecture of which provides the facility for expansion to consume different insurance products and schemes in the future.

 

This set of libraries can be found in DevOps source control at $/Connexus/ConnexusServices/TransactorV7

 

### ConnexusServices.TransactorV7

 

This class library implements the *core* functionality required to communicate with the Transactor V7 API, regardless of the risk or product being quoted or incepted. It provides wrapper functions around the API endpoints in order to simplify the process of making a call to the API and receiving a response from it.

 

Included are *Converter* classes for items such as Endorsements, Employment Statuses, Occupations etc, core *Enumerations*, *Infrastructure*-based helpers including JSON serialisation, configuration classes and HttpWebRequest extensions, and, most importantly, the base set of *Models* that represent the data that can be passed to and from the Transactor V7 API.

 

### ConnexusServices.TransactorV7.OmrMotor

 

This class library builds on the **ConnexusServices.TransactorV7** base library described above to provide **Open Market Motor (OMR Motor)** product and scheme-specific implementations for interfacing with the Transactor V7 API.

 

Included are wrappers around the *core* implementations that provide OMR Motor-specific business logic, *Converters*, *Enumerations* and *Models*.

 

## Further Reading

 

Please see the [Connexus Transactor V7 Application Architecture](/articles/vwfs-porsche/connexus-transactor-v7-web-application-architecture/) article for further details on where these layers sit in the overall application architecture. The two libraries described above are referenced in the diagram as the **Product Layer**, **Companion Library** and **Transactor Layer**.