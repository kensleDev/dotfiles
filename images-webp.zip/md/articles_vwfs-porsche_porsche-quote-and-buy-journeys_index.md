[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Porsche - Quote and Buy Journeys

 

---

 

The **Annual** and **Drive Away** Motor Insurance journeys on Insure with Porsche both utilise the same user flow, design elements, forms, validation and codebase for the most part. They are driven through a combination of ASP.NET MVC 5 controllers and views with AngularJS (version 1) embedded in each view for client-side functionalities.

 

## Risk Details

 

A high proportion of the risk questions in both journeys are identical, with only these few differences:

 

- **Drive Away** asks for a *Porsche Centre Number* and *Porsche Centre Email Address* in order to validate that the customer is eligible for a free 5-day Drive Away policy
- **Annual** asks for the *Date Purchased* for the vehicle
- **Drive Away** asks for a *Current Policy Renewal Date* in order that an Annual invitation can be sent at the appropriate time should the customer agree to the necessary marketing communications under GDPR

 

Therefore as much of the two journeys as possible is generic and applies to both, including controller actions, view models and views themselves being driven by a collection of *partial* views

 

## Views and Partials

 

Each journey has a separate set of MVC **Views**. The only reason for this is that UmbracoCMS is responsible for routing and view selection; the contents of the two sets of views are almost identical and include the following:

 

1. Vehicle.cshtml
2. Drivers.cshtml
3. Cover.cshtml
4. Quote.cshtml
5. AnnualPayment.cshml
6. DirectDebitPayment.cshtml
7. DirectDebitDeposit.cshtml
8. ProcessingPayment.cshtml
9. ThreeDSecureRequest.cshtml
10. ThreeDSecureResponse.cshtml
11. Confirmation.cshtml
12. Decline.cshtml
13. Referral.cshtml
14. ProtectedNoClaims.cshtml

 

### Journey Navigation

 

Navigation through the journey is presented with *partial* views but controlled centrally by a common HTTP POST handling controller action. The *partial* views involved are:

 

- ~/Views/Partials/Navigation/_journeyNavigation.cshtml
- ~/Views/Partials/Navigation/_journeyNavigationForm.cshtml
- ~/Views/Partials/Navigation/_journeyGoToQuote.cshtml

 

### 1. Vehicle

 

The **Vehicle** step first contains a section to perform a **Vehicle Lookup**, either based on the VRM or, if not available via a **Manual Entry** form. These are both contained in *partial* views:

 

- ~/Views/Partials/CarInsuranceJourney/1-Vehicle/_vehicleRegistrationLookup.cshtml
- ~/Views/Partials/CarInsuranceJourney/1-Vehicle/_vehicleManualEntry.cshtml

 

The results of the vehicle lookup are also contained in a *partial* view:

 

- ~/Views/Partials/CarInsuranceJourney/1-Vehicle/_vehicleRegistrationPlateControl.cshtml

 

The **Vehicle** step then contains an accordion with two collapsible sections; **Vehicle Details** and **Vehicle Usage**. The forms for these two sections are contained in *partial* views:

 

- ~/Views/Partials/CarInsuranceJourney/1-Vehicle/_vehicleDetailsForm.cshtml
- ~/Views/Partials/CarInsuranceJourney/1-Vehicle/_vehicleUsageForm.cshtml

 

### 2. Drivers

 

The **Drivers** step contains an accordion with three collapsible sections; **Personal Details**, **Driving History** and **Additional Drivers**. The forms for these three sections are contained in *partial* views:

 

- ~/Views/Partials/CarInsuranceJourney/2-Driver/_driverPersonalDetails.cshtml
- ~/Views/Partials/CarInsuranceJourney/2-Driver/_addressLookup.cshtml
- ~/Views/Partials/CarInsuranceJourney/2-Driver/_driverEmploymentDetails.cshtml
- ~/Views/Partials/CarInsuranceJourney/2-Driver/_drivingHistory.cshtml
- ~/Views/Partials/CarInsuranceJourney/2-Driver/_claimsSection.cshtml
- ~/Views/Partials/CarInsuranceJourney/2-Driver/_convictionsSection.cshtml
- ~/Views/Partials/CarInsuranceJourney/2-Driver/_additionalDrivers.cshtml

 

### 3. Cover

 

The **Cover** step contains an accordion with two collapsible sections; **Cover Details** and **Contact Details**. The forms for these two sections are contained in *partial* views:

 

- ~/Views/Partials/CarInsuranceJourney/3-Cover/_coverDetails.cshtml
- ~/Views/Partials/CarInsuranceJourney/3-Cover/_contactDetails.cshtml

 

### 4. Quote

 

The **Quote** step contains six sections, none of which are contained in an accordion. Each of the six sections are contained in *partial* views:

 

- **Annual:** ~/Views/Partials/CarInsuranceJourney/4-Quote/_quoteDetails.cshtml
- **Drive Away:** ~/Views/Partials/CarInsuranceJourney/4-Quote/_quoteDetailsDriveAway.cshtml
- ~/Views/Partials/CarInsuranceJourney/4-Quote/_protectedNoClaims.cshtml
- ~/Views/Partials/CarInsuranceJourney/4-Quote/_summaryOfCover.cshtml
- ~/Views/Partials/CarInsuranceJourney/4-Quote/_endorsements.cshtml
- ~/Views/Partials/CarInsuranceJourney/_accountPreferences.cshtml
- **Annual:** ~/Views/Partials/CarInsuranceJourney/4-Quote/_importantInformation.cshtml
- **Drive Away:**~/Views/Partials/CarInsuranceJourney/4-Quote/__importantInformationDriveAway.cshtml

 

The **Quote** step provides the customer with two payment options; *Annual* and *Direct Debit*. On the **Drive Away** journey they are also presented with a third option, allowing them to proceed with the Drive Away cover only. In this third case, all subsequent payment-related steps are skipped and the Drive Away policy is incepted stand-alone.

 

### 5. and 7. Annual Payment

 

The **Annual Payment** step is used for both the *Annual* and *Direct Debit* payment options. The form for this section is contained in a single *partial* view:

 

- ~/Views/Partials/CarInsuranceJourney/5-AnnualPayment/_CardPaymentDetails.cshtml

 

### 6. Direct Debit Payment

 

The **Direct Debit Payment** step is used to collect Direct Debit details when the customer selects the Direct Debit payment option. The form for this section is contained in a single *partial* view:

 

- ~/Views/Partials/CarInsuranceJourney/5-DirectDebitDeposit/_DirectDebitDepositPaymentDetails.cshtml

 

### 8. Processing Payment

 

This is effectively a "holding" page for the customer whilst their payment details are processed. The loading of this page initialises the process to take an appropriate card payment with **SagePay** for either payment option.

 

### 9. 3D-Secure Request

 

This is the view that processes a 3D-Secure request when required to do so by **SagePay**. The view contains a simple form that is pre-populated and then automatically submitted to **SagePay**, who then carry out the 3D-Secure process with the customer's bank.

 

### 10. 3D-Secure Response

 

This is the view that **SagePay** redirects to once the 3D-Secure check has completed. As with the 3D-Secure Request view, this view is automatically processed based on a successful/failed response from **SagePay**.

 

Given a successful payment and 3D-Secure check, 

 

### 11. Confirmation

 

Assuming payment, 3D-Secure checks and policy inception have been completed successfully, the customer is then redirected to the **Confirmation** page and presented with a policy number. This completes the journey.

 

### 12. and 13. Decline and Referral

 

If for any reason the risk details are declined or referred by the underwriter, the customer journey skips steps 4 through 11 and redirects the customer straight to the **Decline** or **Referral** view and informs that they should contact the administrative team for assistance.

 

### 14. Protected No Claims

 

This view is accessed via a link on the **Quote** page and demonstrates the advantages gained by protecting any no-claims bonus the customer already has before incepting the policy.