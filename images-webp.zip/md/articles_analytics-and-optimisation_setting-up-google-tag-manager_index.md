[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Setting up Google Tag Manager

 

---

 

## Introduction

 

Google Tag Manager (GTM) is an application available on the Google platform that allows actions to be triggered when certain events occur on a website or application - for example when a page is viewed, a button or link is clicked, or an element's visibility changes.

 

GTM provides the ability to 'listen' for these events in **triggers** that fire under configurable conditions. These triggers cause various types of actions known as **tags** to execute when they are fired - for example raising an event with Google Analytics (GA) or causing a piece of Javascript to be loaded and executed on the page.

 

At Connexus, GTM is used for a few reasons:

 

- To enhance the data collected by GA
- To drive marketing campaigns, e.g. pay-per-click

 

You can log in to our [Google Tag Manager](https://tagmanager.google.com/) setup with: websitesupport@connexus.co.uk.

 

## GTM Accounts

 

When setting up GTM for the first time for a new customer, website or application, it may be necessary to create a new **Account**. Accounts are placeholders for all data associated with a high-level entity such as an entire customer; for example, we have an account for all websites and applications we manage for **VWFS**.

 

### Existing Account

 

It is likely that a valid account already exists for the website or application you are implementing in GTM; it is important to check before creating a new account.

 

### New Account

 

You can follow the below steps to create a new account:

 

1. In the *All Accounts* page, click **Create Account** (you can always click the GTM icon at the top-left to navigate to the *All Accounts* page)
2. Type the new **Account Name** e.g. "VWFS"
3. Select "United Kingdom" from the **Country** dropdown
4. Continue with configuring a **Container** by following the instructions below

 

## GTM Containers

 

**Containers** are placeholders that uniquely identify an individual website or application. They are configured with a unique *code* that is used to ensure data for that website or application is always associated with the correct **Container** in GTM.

 

### Creating a new Container

 

If you have identified an existing **Account** to use for integrating your website or application, you can create a new **Container** as follows:

 

1. Find the required account and click the ellipsis to the right of the panel
2. Select **Create Container**
3. Type the **Container Name** e.g. "Insure with Skoda - UAT" (this must be unique for each website/application and environment (i.e. UAT and live environments must have separate **Containers**)
4. Select "Web" as the **Target platform**
5. Click **Create**
6. If prompted, accept the Terms of Service Agreement

 

GTM will present you with a dialog containing the Javascript that must be added to the source of the website or application in order to integrate them correctly. You should take a copy of this code for use later and in particular note the unique *code* within the Javascript that uniquely identifies your new container; it will begin "GTM-".

 

## Adding Google Tag Manager to a website or application

 

The Javascript code necessary to integrate your website or application with GTM can be accessed at any time from the **Admin** tab of your **Container** under "Install Google Tag Manager". For GTM there are two code blocks required; one for the <head /> tag and one for the <body /> tag.

 

The first segment must sit as high in the <head> as reasonably possible, and the second as high as reasonably possible after the opening <body> tag. At Connexus these code blocks are usually separated into partial views in MVC solutions or separate components in SPA-driven websites. They may also be conditionally rendered by the website for privacy reasons such as GDPR cookie acceptance.

 

**Note:** if the code already exists in the source, only the unique "GTM-" code needs to be updated in the relevant places.

 

### Environment Switching

 

As mentioned above it is necessary to configure separate GTM **Containers** for each environment a website resides in. This means each environment has its own, unique **Container** *code* required in the HTML. We are steadily implementing storage of the unique *code* in AppSettings -> GoogleTagManagerKey in the web.config file; this has already been completed for Insure with Audi.

 

## Example: adding Google Tag Manager to a VWFS InsureWith website

 

The VWFS "Insure with" websites hold the GTM Javascript code blocks in two separate partial views:

 

- **/Views/Shared/_googleTagManager.cshtml**
- **/Views/Shared/_googleTagManagerNoScript.cshtml**