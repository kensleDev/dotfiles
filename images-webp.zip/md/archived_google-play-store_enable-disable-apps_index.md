[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Enable /Disable Apps

 

---

 

We have recently been requested to decommission a number of VW apps previously available in the Google play store. 

 

[https://play.google.com/console/u/2/developers/6700359308767204557/app-list](https://play.google.com/console/u/2/developers/6700359308767204557/app-list)

 

Select the app and within 'Advanced Settings' choose publish/unpublish.

 

 

 

Login details

 

p.adamson.connexus@gmail.com

 

AFyuuLKc7zsSBdXA