[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Lawshield V6 API

 

---

   

## Website Details

  **Live URL:** [https://lawshieldv6-api.lawshield.co.uk/](https://lawshieldv6-api.lawshield.co.uk/) **UAT URL:** [https://lawshieldv6-api.connexus-test.co.uk/](https://lawshieldv6-api.connexus-test.co.uk/)    .NET Framework C# ASP.NET MVC Entity Framework 6   

---

 

## Introduction

 

The Lawshield V6 API is a "Middleware" API for communicating with Transactor V6 environments. It takes on the responsibility of communicating with Transactor using a set of embedded .NET Framework libraries (DLLs). This allows consuming applications the freedom to use an independent technology stack with the only caveat that the technologies of choice must be able to consume a RESTful API.

 

[Velosure](/websites-and-applications/lawshield-connexus/velosure/) was the first website to consume this API and is built using .NET Core 3.1, ASP.NET Core WebAPI and VueJS.

 

The API is self-documenting and provides a full description of each endpoint including the definition of the expected and returned JSON data. It can be viewed at: [https://lawshieldv6-api.lawshield.co.uk/docs](https://lawshieldv6-api.lawshield.co.uk/docs)

 

## Swagger

 

http://192.168.204.116/Transactor.API/swagger/ui/index#/

 

## Pseudo-RESTful API

 

Communicating with Transactor directly using the Transactor .NET Framework DLLs requires a *stateful* application presence. This means the application performing the communication must be able to store and hold information in an **ASP.NET Session**. Given this requirement, the Lawshield V6 API is implemented as a pseudo-RESTful API.

 

Consumers can make HTTP GET and POST requests to the API as would be expected of a normal RESTful API, but the implementation of the endpoints uses **ASP.NET MVC** Controllers and Actions, rather than WebAPI. It is this implementation that allows the use of **ASP.NET Session** for storage and retrieval of data in communications with Transactor.

 

## Architecture

 

The goal with this API is to provide a single entry point for all communications to and from Transactor V6 environments, the architecture is designed to make the introduction of functionality for new insurance products as easy as possible.

 

The solution contains multiple projects; the first three are common across all insurance products:

 

- **ConnexusServices.TransactorV6** 

- ASP.NET MVC 5 *API* client layer exposing endpoints for consumers
- **ConnexusServices.TransactorV6.Common** 

- Provides error codes, configuration classes and core Transactor risk model definitions
- **ConnexusServices.TransactorV6.Services** 

- Core business logic layer implementing all *base* communications with Transactor common to all insurance products, an Entity Framework 6 context for direct communications with the Transactor database, and the API authorisation service

 

There are then product-specific layers:

 

- **ConnexusServices.TransactorV6.PedalCycle** 

- Inherits from *base* services in the **Services** layer and implements all additional *Lawshield Pedal Cycle* business logic required to quote and incept policies on this insurance product
- **ConnexusServices.TransactorV6.ExtendedWarranty** 

- Inherits from *base* services in the **Services** layer and implements all additional *VWFS Extended Warranty* business logic required to quote and incept policies on this insurance product

 

Finally, there is a further stand-alone console application:

 

- **ConnexusServices.TransactorV6.TokenGenerator** 

- Provides a console-based facility for generating valid authentication tokens for communicating with the Lawshield V6 API

 

### Core Implementation Principles

 

The **ConnexusServices.TransactorV6.Services** layer contains several *base* implementations that provide the core business logic for communicating with Transactor:

 

#### TransactorServiceBase

 

Provides a base abstract implementation for storing core services and configuration required by all classes implementing business logic:

 

- **IConfiguration** 

- Hold configuration specific to an insurance product, such as *ProjectCode* and *PaymentTypeIDs*
- **ExceptionHelper** 

- Guarantees responses from business logic with flags indicating success or failure. See [here](/articles/software-development-principles/connexus-exceptionhelper-and-execresponse/) for further details

 

#### TransactorQuoteServiceBase

 

Provides a base abstract implementation for quoting a risk model for any insurance product. It exposes one key public method **GetQuote**, which accepts a generic *TRiskModel* risk model and performs the following actions:

 

1. Establishes which scheme associated with the specific insurance product should be quoted against; using a JSON configuration file within the Lawshield V6 API to do so.
2. Performs any product-specific pre-processing of the risk model. In the case of *Lawshield Pedal Cycle*, the code determines if there is a discount to be applied from a **SaleId** provided in the risk model.
3. Establishes base *Session* details for Transactor.
4. Sets all generic risk data values in *Session* for Transactor to pick up. This makes a further call to an abstract method **SetTransactorData** which must be implemented by the product-specific inheritors of this class to set the product-specific risk data.
5. Requests a quote from Transactor.
6. On a successful quote, the risk is then saved as a *Prospect* if required and the response is processed for returning to the consuming application by the product-specific implementation of another abstract method **ProcessSuccessfulQuote**.
7. On a failed quote, the failure, referral or decline message is retrieved for returning to the consuming application

 

#### TransactorInceptionServiceBase

 

Provides a base abstract implementation for incepting a risk model for any insurance product. It exposes one key public method **InceptPolicy**, which accepts a generic *TRiskModel* risk model and a *QuoteResponse*, and performs the following actions:

 

1. Captures cover start and end dates for Transactor
2. Determines the payment type selected by the customer. **NOTE:** this currently only handles full annual payment by credit/debit card and monthly payments by direct debit.
3. If payment is by credit/debit card an attempt to convert to a policy is made directly with Transactor
4. If payment is by direct debit, the bank details are set in *Session* before then attempting to convert to a policy directly with Transactor.
5. Finally, on successful inception by either payment method, additional generic inception steps are carried out including log actions and queuing the INTERNET NB event, which ultimately triggers the sending of any Confirmation of Cover documentation

 

#### RiskModelValidatorBase

 

Provides a base abstract implementation for validating risk model details for quoting and inception operations for any insurance product. It exposes two key public methods; **IsValidForQuote** and **IsValidForInception**, which both accept a generic *TRiskModel* to be validated.

 

In line with other *base* classes in this library, this class performs validation of all *generic* risk model data, including Proposer, Addresses, base Policy details, Payment details etc. and subsequently calls to abstract methods **ProductDetailsAreValidForQuote** and **ProductDetailsAreValidForInception** which must be implemented by the product-specific inheritors of this class in order to validate the product-specific risk model details.