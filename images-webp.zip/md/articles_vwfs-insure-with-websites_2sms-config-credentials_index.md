[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# 2Sms Config Credentials

 

---

 

[2Sms](https://gb.2sms.com/) is a service used by the InsureWith websites and Velosure to send sms messages with policy numbers for customers. Below are the credentials used by the ConnexusConfig database:

 

**UAT and LIVE:**

 

**InsureWith Audi**
Username: Audi
Password: Audi123@

 

**InsureWith SKODA**
Username: Skoda
Password: Skoda123@

 

**InsureWith SEAT**
Username: Seat
Password: Seat123@

 

**InsureWith Porsche**
Username: Porsche
Password: Porsche123@

 

**InsureWith Volkswagen**
Username: volkswagen1
Password: Volkswagen123@

 

**InsureWith VWCV**
Username: volkswagencv
Password: Volkswagen123@

 

**Velosure**
Username: velosure
Password: Velosure2019