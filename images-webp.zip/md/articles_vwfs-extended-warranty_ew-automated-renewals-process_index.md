[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# EW - Automated Renewals Process

 

---

 

### Renewals Process

 

The renewal process is now automated and consists of the following: In TCAS (Transactor) there is a scheduling option for renewals. (See transactor documentation on the share drive \db2003b\CompanyData\Transactor User Guides )

 

**PN 29/08/19 update starts**

 

This TCAS renewal schedule function has been enabled for both Extended Warranty and Ensurance as they now set up correctly. The process is scheduled to run each morning at 6:00hrs, you should be able to see a task named 'TGSL(MultiTask)'. If you cannot see this task then you will need to set it up again using the TCAS Scheduling renewals config option; you can access this using a normal TCAS logon; the last time we had to reset this config was on 29/08/19. When you go into the config screen it DOES NOT show you the config settings even if the task is properly set up and running.

 

If you find the task named 'TGSL(MultiTask)' has ended unexpectedly and left some invites outstanding you can restart it manually and hopefully, it will be ok the second time around. If it fails repeated without processing any invites you will need to escalate to OGI.

 

To check whether the process is running you can run a script like this:

 

```
select top 1000 'auto renewal invites issued today, latest first >>>' as Warning1, * from REPORT_ACTION_LOG where ACTIONTYPE = 10 and loginname = 'system' and datediff(day,getdate(),actiondate) = 0
```

 

**update ends**

 

For EW there are two types of renewal invite (FCA eligible and FCA ineligible) and the appropriate document is selected via a user event. (See the “Renewal – Invite Auto” in the User Event Configuration in the Transactor Tool Suite)

 

The Renewal process will run every day at **08:45** through which a status email will be sent once complete. As this runs every day there is not much to pick up. Therefore shouldn’t take longer than 10 minutes. At **09:00** the Automated reporting will send an email out, of who has been invited for renewal.

 

This has been done through SQL as Transactor cannot automate daily renewal reports (Not to my knowledge). This report is an exact replica of the Audit report that is generated if we ran the invite automatic option in TCAS itself.

 

There is a separate email from both Ensurance and Extended Warranty. This is done in the SQL agent job **Email Daily VW Reports**

 

### Extended Warranty Renewals

 

For Extended Warranty, there is an extra step that runs before all this which gets us the correct renewal prices.

 

To do this a SQL update script runs every morning at **02:00**. This finds everything that is up for that renewal that day and increases the mileage by a predicted amount. And sets them to a Day One rate.

 

See the Store Procedure section of the wiki for a detailed break down. This is a SQL agent job called UPDATE_POLICY_RENEWAL_QUOTES