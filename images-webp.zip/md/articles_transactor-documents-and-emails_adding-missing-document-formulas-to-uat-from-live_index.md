[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Adding Missing Document Formulas to UAT from Live

 

---

 

In Tools Suite on dev (DEVAPP 192.168.204.108):
Document Manager -> Document Formulas
Look for the existing formula, did you really think Transactor would make it easy by adding a search or even sorting the formulae?

 

If it doesn't exist:
Find the formula on live (PRDAPP1 192.168.104.58)
Edit, copy the Description, add a new formula on Dev and and paste the Description into Name and Description
Copy the Formula to dev

 

Check the SP exists on dev (DEV_CNX_TGSL\395747_LawShield), if not then copy it from live (CNX_TGSL\582499_LawshieldVW)
(Click Change Connection next to the database name dropdown)