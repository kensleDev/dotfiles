[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# DEVAPP5

 

---

 

## Server Details

  **Server Type:** Transactor **IP Address:** 192.168.204.180  

---

 

This server is the development and test **Transactor v7 Application Server** for VWFS Porsche products and hosts all development and test Transactor v7 applications and services, including:

 

- TCAS
- TES Tool Suite
- Relationship Manager
- TES Screen Builder
- Relationship Manager Service
- Document Service (incl. MSMQ etc.)
- Transactor v7 API

 

---

 

## Insurance Products

 

- [Porsche OMR Motor (Annual)](/insurance-products/volkswagen-financial-services-vwfs/porsche-omr-motor-annual/)
- [Porsche OMR Motor (5-day Drive Away)](/insurance-products/volkswagen-financial-services-vwfs/porsche-omr-motor-5-day-drive-away/)