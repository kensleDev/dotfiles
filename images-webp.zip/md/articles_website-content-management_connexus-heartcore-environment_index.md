[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Connexus Heartcore Environment

 

---

 

## Heartcore Cloud

 

The Heartcore cloud is located at: [Heartcore Cloud](https://identity.umbraco.com/5f36b6cc-f3ae-4a05-8ce1-826d1068a97d/b2c_1a_signincloudportal/oauth2/v2.0/authorize?client_id=8df798d3-d083-446d-bb41-02b2c6de4b8f&redirect_uri=https%3A%2F%2Fwww.s1.umbraco.io%2Fsignin-oidc&response_type=code%20id_token&scope=openid%20profile%20offline_access&state=OpenIdConnect.AuthenticationProperties%3Dy82_0ryO2FIrZV2Fea0E5D7ywj9EJCyFR86grc0yudk6-Z-C8wdJkb7gsAV18NGpNk_zNcXPQ3mU4gVR677-_RCbEh252REssyVFlZxwRbqb1Wvaze-W3qWnKZxWwLi8wFCUItJrMz4e9jyTUEmIp8yxXUHnapaeC2QPhb3uLg7qVssiHYhMcmC4X7XqLQ2R4kp1npGZrhukl3sKF7OgayWz4GaTdbEJEi-5moXXSXwIGT3ysEVYFVHySfigTodWuJamM_7GdoPNO0w_0an914G2vA4-4z9WTrHAZ3HX-o0&response_mode=form_post&nonce=637468360644946069.NGZhNDEzMGEtYTkxOC00YWFhLWJiNmEtZTY2YWVkMzBjNjFhZmY0YjBmM2ItNDY0Yi00ZTVhLThjMzctYWU0OGQzZDJiMjNk&x-client-SKU=ID_NET461&x-client-ver=5.3.0.0)

 

The development login is development@connexus.co.uk with the usual password.

 

## Projects

 

### Velosure

 

- [Development](https://dev-velosure.euwest01.umbraco.io/umbraco) for all content updates to be tested and signed-off in UAT
- [Live](https://velosure.euwest01.umbraco.io/umbraco/) to make immediate changes to LIVE