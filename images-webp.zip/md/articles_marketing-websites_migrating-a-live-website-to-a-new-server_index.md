[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Migrating a live website to a new server

 

---

 

#### Setting up the Website

 

1. On your new Ubuntu/Apache server, navigate to the configuration files: 

 

```
cd /etc/apache2/sites-available
```

 

2. Create a new .conf file for your project e.g.

 

```
sudo nano portalclaimsline.co.uk.conf
```

 

*Put the Private IP of the server next to :80 or :443*

 

3. Navigate to the website folder:

 

```
Cd /var/www
```

 

4. Create a folder for the website e.g.:

 

```
sudo mkdir officialclaimsassist.co.uk
```

 

5. Navigate into the new folder and create a logs folder:

 

```
sudo mkdir logs
```

 

6. Take DevOps/Github cloned url:

 

```
sudo git clone URL
```

 

Check contents

 

There will now be a file called after your website e.g. Portal%20Claims%20Line

 

7. Change this files name to htdocs e.g.

 

```
sudo mv Portal%20Claims%20Line/ htdocs
```

 

8. Update permissions and ownership for the newly created project folder:

 

```
sudo chmod 775 -R ./htdocs
```

 

```
sudo chown www-data:www-data -R ./htdocs
```

 

You should now be able to see all your files from var/www/websiteName

 

9. Update .env file

 

10. Run composer install in the htdocs of new project if used

 

11. Check the git is on master branch: git status

 

```
sudo git checkout master
```

 

```
sudo git status again
```

 

If there’s a bunch of extra files you can 

 

```
sudo git stash
```

 

and 

 

```
sudo git status
```

 

again should say ‘nothing to commit.’

 

12. Add SSL cert located in -

 

```
/etc/ssl/certs/2021
```

 

13. Test the configuration:

 

```
sudo apachectl configtest
```

 

14. Activate the sites e.g.

 

```
sudo a2ensite portalclaimsline.co.uk.conf
```

 

15. Test again:

 

```
sudo apachectl configtest
```

 

16. Reload the server:

 

```
sudo service apache2 reload
```

 

17. Check if it’s working on the browser using Notepad. See below for more information.

 

18. Point forms to your email

 

19. Test form.

 

20. If all good, let Mark R/IT know to test and switch website to the DNS.

 

21. When switched, test forms again.

 

22. Test SSL cert in [SSLLabs](https://www.ssllabs.com/ssltest/)

 

23. Is there a web.config file generated in htdocs/public?

 

Remove it with:

 

```
sudo rm web.config
```

 

24. Add HSTS to .conf file. [Here](https://www.xolphin.com/support/Apache_FAQ/Apache_-_Configuring_HTTP_Strict_Transport_Security) is a useful article on this.

 

```
Header always set Strict-Transport-Security "max-age=63072000; includeSubdomains;"
```

 

25. You can add expires headings to the vhost too. [Here](http://codebeerstartups.com/how-to-set-an-expires-header-in-apache/) is a useful article.

 

26. Test form is going to CRM and email addresses.

 

#### Testing with Notepad

 

You can test your websites locally before they are switched on the DNS and live to the public. To do this, you will need Notepad and the Windows Command Line.

 

1. Right-click Notepad and select Open Notepad **as Administrator**.
2. Click File > Open File.
3. Go to C:\Windows\System32\drivers\etc. Make sure 'all files' is selected if you cannot see anything there. There should be a file there called hosts.
4. In this file, add the IP of your new server next to the URL of the website you are testing e.g.

 

```
51.145.114.15 www.officialclaimsassist.co.uk
```

 

1. Save the note and go into the Command Line Prompt for Windows and ping officialclaimsassist.co.uk. It should respond with the IP on the new server you just added to Notepad.
2. Open your browser and test this website from the new server (despite it not yet being connected to the DNS/live).
3. You may need to run ipconfig /flushdns when you're done testing it.
4. When you are happy with testing, comment out the addition you made to Notepad. Check that the old server appears on a ping.
5. Continue on with your set up.