[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Articles

 

---

   

#### Acturis

 

---

 

- ** [Access the Academy](/articles/acturis/access-the-academy/)
- ** [Add the Word Plugin](/articles/acturis/add-the-word-plugin/)
- ** [Swapping between Environments](/articles/acturis/swapping-between-environments/)

   

#### Mobius

 

---

 

- ** [Mobius Database](/articles/mobius/mobius-database/)
- ** [Global Pay credentials](/articles/mobius/global-pay-credentials/)

   

#### Deployment

 

---

 

- ** [Site 24/7 Monitoring](/articles/deployment/site-24-7-monitoring/)

   

#### Website Content Management

 

---

 

- ** [Connexus Heartcore Environment](/articles/website-content-management/connexus-heartcore-environment/)
- ** [Setting up Umbraco V7](/articles/website-content-management/setting-up-umbraco-v7/)
- ** [Force immediate changes](/articles/website-content-management/force-immediate-changes/)

   

#### VWFS - Insure with Websites

 

---

 

- ** [VWFS Websites - Architecture](/articles/vwfs-insure-with-websites/vwfs-websites-architecture/)
- ** [VWFS Websites - Design Patterns](/articles/vwfs-insure-with-websites/vwfs-websites-design-patterns/)
- ** [Sizing and Positioning an Image Based on a Guide Image](/articles/vwfs-insure-with-websites/sizing-and-positioning-an-image-based-on-a-guide-image/)
- ** [2Sms Config Credentials](/articles/vwfs-insure-with-websites/2sms-config-credentials/)
- ** [VW Ancillary Import Process (Opteven)](/articles/vwfs-insure-with-websites/vw-ancillary-import-process-opteven/)

   

#### Velosure

 

---

 

- ** [Velosure - Customer Communications - Emails and Letters](/articles/velosure/velosure-customer-communications-emails-and-letters/)
- ** [Velosure - Renewals](/articles/velosure/velosure-renewals/)
- ** [Velosure - Architecture - needs a Rewrite](/articles/velosure/velosure-architecture-needs-a-rewrite/)
- ** [Pre-Population from QuoteZone](/articles/velosure/pre-population-from-quotezone/)
- ** [Velosure API](/articles/velosure/velosure-api/)
- ** [TESTING Data](/articles/velosure/testing-data/)

   

#### Global Pay / Realex Payments

 

---

 

- ** [Login credentials](/articles/global-pay-realex-payments/login-credentials/)
- ** [HPP](/articles/global-pay-realex-payments/hpp/)

   

#### VWFS - Extended Warranty

 

---

 

- ** [EW - Eligibility Criteria](/articles/vwfs-extended-warranty/ew-eligibility-criteria/)
- ** [EW - Rating Criteria](/articles/vwfs-extended-warranty/ew-rating-criteria/)
- ** [EW - Warranty Rating Tables + Importing new rates](/articles/vwfs-extended-warranty/ew-warranty-rating-tables-importing-new-rates/)
- ** [EW - Useful Stored Procedures](/articles/vwfs-extended-warranty/ew-useful-stored-procedures/)
- ** [EW - Automated Renewals Process](/articles/vwfs-extended-warranty/ew-automated-renewals-process/)
- ** [EW - Customer Communications - Emails and Letters](/articles/vwfs-extended-warranty/ew-customer-communications-emails-and-letters/)
- ** [EW - Troubleshooting](/articles/vwfs-extended-warranty/ew-troubleshooting/)
- ** [Troubleshooting Opteven Reports](/articles/vwfs-extended-warranty/troubleshooting-opteven-reports/)
- ** [Opteven Data Feed Errors](/articles/vwfs-extended-warranty/opteven-data-feed-errors/)

   

#### Website Server Configuration

 

---

 

- ** [IIS - URL Rewrites and "Vanity" URLs](/articles/website-server-configuration/iis-url-rewrites-and-vanity-urls/)
- ** [SMTP Email Configuration](/articles/website-server-configuration/smtp-email-configuration/)

   

#### Transactor

 

---

 

- ** [Useful Transactor Information](/articles/transactor/useful-transactor-information/)
- ** [Bomgar Access details](/articles/transactor/bomgar-access-details/)
- ** [Checking Payment is Working](/articles/transactor/checking-payment-is-working/)
- ** [Connexus - Transactor V6 API](/articles/transactor/connexus-transactor-v6-api/)
- ** [Data Dictionary](/articles/transactor/data-dictionary/)
- ** [GDPR data removal request](/articles/transactor/gdpr-data-removal-request/)
- ** [Getting the Last EW Policy Details](/articles/transactor/getting-the-last-ew-policy-details/)
- ** [Open GI FTP Connection details](/articles/transactor/open-gi-ftp-connection-details/)
- ** [OpenGI - Support (Jira)](/articles/transactor/opengi-support-jira/)
- ** [Products, Schemes and Lines of Business (LOBs)](/articles/transactor/products-schemes-and-lines-of-business-lobs/)
- ** [Scheme Files](/articles/transactor/scheme-files/)
- ** [Transactor Development Environment Setup](/articles/transactor/transactor-development-environment-setup/)
- ** [Transactor policy number ranges](/articles/transactor/transactor-policy-number-ranges/)
- ** [Transactor Server Setup - issues encountered and resolution](/articles/transactor/transactor-server-setup-issues-encountered-and-resolution/)
- ** [Troubleshooting Payment Failures](/articles/transactor/troubleshooting-payment-failures/)
- ** [Troubleshooting Permissions Problems](/articles/transactor/troubleshooting-permissions-problems/)
- ** [Useful Transactor Scripts](/articles/transactor/useful-transactor-scripts/)
- ** [Testing the OGI/Transactor monthly rates release](/articles/transactor/testing-the-ogi-transactor-monthly-rates-release/)
- ** [HTTP Aggregator Monitor installation and usage](/articles/transactor/http-aggregator-monitor-installation-and-usage/)

   

#### Transactor Documents and Emails

 

---

 

- ** [Uploading Documents](/articles/transactor-documents-and-emails/uploading-documents/)
- ** [Update letter or email templates](/articles/transactor-documents-and-emails/update-letter-or-email-templates/)
- ** [Transactor Email Queues](/articles/transactor-documents-and-emails/transactor-email-queues/)
- ** [Testing Emails](/articles/transactor-documents-and-emails/testing-emails/)
- ** [SQL to Find and Update Documents](/articles/transactor-documents-and-emails/sql-to-find-and-update-documents/)
- ** [Resending Emails](/articles/transactor-documents-and-emails/resending-emails/)
- ** [Manually Changing the Effective and Expiry Date of Templates](/articles/transactor-documents-and-emails/manually-changing-the-effective-and-expiry-date-of-templates/)
- ** [Getting the Filename of Email Templates](/articles/transactor-documents-and-emails/getting-the-filename-of-email-templates/)
- ** [Adding Events to Print Documents](/articles/transactor-documents-and-emails/adding-events-to-print-documents/)
- ** [Adding Missing Document Formulas to UAT from Live](/articles/transactor-documents-and-emails/adding-missing-document-formulas-to-uat-from-live/)
- ** [Updating an Email Address](/articles/transactor-documents-and-emails/updating-an-email-address/)

   

#### Actito

 

---

 

- ** [Adding Parameters to Email Links](/articles/actito/adding-parameters-to-email-links/)
- ** [Updating Email Template](/articles/actito/updating-email-template/)
- ** [Adding Conditional Content to HTML Emails](/articles/actito/adding-conditional-content-to-html-emails/)

   

#### VWFS - Ensurance

 

---

 

- ** [Ensurance - Customer Communications - Emails and Letters](/articles/vwfs-ensurance/ensurance-customer-communications-emails-and-letters/)
- ** [Ensurance - Automated Renewals Process](/articles/vwfs-ensurance/ensurance-automated-renewals-process/)

   

#### VWFS - Porsche

 

---

 

- ** [Porsche - showing "holding page" for Aviva downtime](/articles/vwfs-porsche/porsche-showing-holding-page-for-aviva-downtime/)
- ** [Connexus - Transactor V7 Web Application Architecture](/articles/vwfs-porsche/connexus-transactor-v7-web-application-architecture/)
- ** [Porsche - Quote and Buy Journeys](/articles/vwfs-porsche/porsche-quote-and-buy-journeys/)
- ** [Porsche - Transactor V7 API](/articles/vwfs-porsche/porsche-transactor-v7-api/)
- ** [Getting the correct typescript version](/articles/vwfs-porsche/getting-the-correct-typescript-version/)
- ** [Porsche Standard UAT and Dev setup](/articles/vwfs-porsche/porsche-standard-uat-and-dev-setup/)
- ** [Porsche Standard Merge](/articles/vwfs-porsche/porsche-standard-merge/)
- ** [Updating Paint and Bodyshop content](/articles/vwfs-porsche/updating-paint-and-bodyshop-content/)
- ** [Updating Porsche Centres](/articles/vwfs-porsche/updating-porsche-centres/)
- ** [Vehicle Model ABI scripts from Transactor / OGI - Porsche fix](/articles/vwfs-porsche/vehicle-model-abi-scripts-from-transactor-ogi-porsche-fix/)

   

#### Useful Testing Knowledge for Dummies

 

---

 

- ** [Transactor](/articles/useful-testing-knowledge-for-dummies/transactor/)
- ** [Lapsed/Day One Functionality](/articles/useful-testing-knowledge-for-dummies/lapsed-day-one-functionality/)

   

#### Proclaim

 

---

 

- ** [Proclaim API - Architecture](/articles/proclaim/proclaim-api-architecture/)
- ** [Policy Validator - Architecture](/articles/proclaim/policy-validator-architecture/)

   

#### CMA Core

 

---

 

- ** [CMA Core - Architecture](/articles/cma-core/cma-core-architecture/)

   

#### Claim Tracker

 

---

 

- ** [JSON Definition](/articles/claim-tracker/json-definition/)
- ** [Claim Tracker Timeline Structure](/articles/claim-tracker/claim-tracker-timeline-structure/)

   

#### Connexus CMS

 

---

 

- ** [Data Models](/articles/connexus-cms/data-models/)

   

#### SagePay

 

---

 

- ** [PCH Account](/articles/sagepay/pch-account/)
- ** [Porsche Account](/articles/sagepay/porsche-account/)
- ** [SagePay API Integration - Insure with Porsche](/articles/sagepay/sagepay-api-integration-insure-with-porsche/)
- ** [Setting up a SagePay User](/articles/sagepay/setting-up-a-sagepay-user/)

   

#### Common Tasks

 

---

 

- ** [Update UAT CMS data from Live](/articles/common-tasks/update-uat-cms-data-from-live/)
- ** [Card Payment Inceptor](/articles/common-tasks/card-payment-inceptor/)
- ** [Setting up Visual Studio to Access Connexus Nuget Packages](/articles/common-tasks/setting-up-visual-studio-to-access-connexus-nuget-packages/)

   

#### Software Development - Code Samples

 

---

 

- ** [Newtonsoft.Json and British Summer Time](/articles/software-development-code-samples/newtonsoft-json-and-british-summer-time/)
- ** [Webpack Configuration](/articles/software-development-code-samples/webpack-configuration/)
- ** [White Labelling with SCSS](/articles/software-development-code-samples/white-labelling-with-scss/)
- ** [Working with ASP.Net MVC, ReactJS and TypeScript](/articles/software-development-code-samples/working-with-asp-net-mvc-reactjs-and-typescript/)
- ** [VSTS NuGet Deployment](/articles/software-development-code-samples/vsts-nuget-deployment/)
- ** [Displaying SSRS Reports in an ASP.Net MVC Site](/articles/software-development-code-samples/displaying-ssrs-reports-in-an-asp-net-mvc-site/)
- ** [React Basics](/articles/software-development-code-samples/react-basics/)
- ** [Vue & Web API - Publish to Multiple Enviroments](/articles/software-development-code-samples/vue-web-api-publish-to-multiple-enviroments/)
- ** [Dependency Injection with Factories Relying on Runtime Parameters](/articles/software-development-code-samples/dependency-injection-with-factories-relying-on-runtime-parameters/)
- ** [Integrating Swagger into a .Net Core Web API with Swashbuckle](/articles/software-development-code-samples/integrating-swagger-into-a-net-core-web-api-with-swashbuckle/)

   

#### CSS / SCSS

 

---

 

- ** [SCSS Mixins](/articles/css-scss/scss-mixins/)
- ** [Selector Cheat Sheet](/articles/css-scss/selector-cheat-sheet/)

   

#### Training

 

---

 

- ** [Pluralsight access](/articles/training/pluralsight-access/)

   

#### Umbraco Tutorials

 

---

 

- ** [How to build a website with Umbraco - Tutorial](/articles/umbraco-tutorials/how-to-build-a-website-with-umbraco-tutorial/)
- ** [Adding an MVC controller + template + Document type](/articles/umbraco-tutorials/adding-an-mvc-controller-template-document-type/)

   

#### Database / SQL Useful Information

 

---

 

- ** [Restoring orphaned user permissions after a backup and restore in to a new database](/articles/database-sql-useful-information/restoring-orphaned-user-permissions-after-a-backup-and-restore-in-to-a-new-database/)
- ** [SQL Instance Collation Transactor requirement](/articles/database-sql-useful-information/sql-instance-collation-transactor-requirement/)

   

#### React

 

---

 

- ** [IIS config for routing](/articles/react/iis-config-for-routing/)

   

#### Marketing Websites

 

---

 

- ** [Intro to Servers](/articles/marketing-websites/intro-to-servers/)
- ** [Laravel Commands](/articles/marketing-websites/laravel-commands/)
- ** [Migrating a live website to a new server](/articles/marketing-websites/migrating-a-live-website-to-a-new-server/)
- ** [Setting up an Ubuntu 20.04.3 server](/articles/marketing-websites/setting-up-an-ubuntu-20-04-3-server/)
- ** [Create .pfx using OpenSSL](/articles/marketing-websites/create-pfx-using-openssl/)
- ** [Website List](/articles/marketing-websites/website-list/)
- ** [When the server goes down](/articles/marketing-websites/when-the-server-goes-down/)
- ** [Renewing SSL Certs (Apache)](/articles/marketing-websites/renewing-ssl-certs-apache/)
- ** [Adding a new project to a dev & prod server](/articles/marketing-websites/adding-a-new-project-to-a-dev-prod-server/)
- ** [Deploying changes to Apache Server](/articles/marketing-websites/deploying-changes-to-apache-server/)

   

#### Payments API

 

---

 

- ** [API Main](/articles/payments-api/api-main/)
- ** [Apple Pay - Setup and Testing](/articles/payments-api/apple-pay-setup-and-testing/)
- ** [Google Pay - Setup and Testing](/articles/payments-api/google-pay-setup-and-testing/)
- ** [Paypal Pay](/articles/payments-api/paypal-pay/)
- ** [Card Payments](/articles/payments-api/card-payments/)

   

#### Other Useful Info

 

---

 

- ** [Browser Custom Search Engines](/articles/other-useful-info/browser-custom-search-engines/)

   

#### Maintenance Pages

 

---

 

- ** [Maintenance Pages](/articles/maintenance-pages/maintenance-pages/)

   

#### Analytics and Optimisation

 

---

 

- ** [Google Tag Manager, Analytics & Optimize Keys](/articles/analytics-and-optimisation/google-tag-manager-analytics-optimize-keys/)
- ** [Setting up Google Tag Manager](/articles/analytics-and-optimisation/setting-up-google-tag-manager/)
- ** [Setup Google Analytics](/articles/analytics-and-optimisation/setup-google-analytics/)
- ** [Link Google Tag Manager to Google Analytics](/articles/analytics-and-optimisation/link-google-tag-manager-to-google-analytics/)
- ** [Add Goals to Google Analytics](/articles/analytics-and-optimisation/add-goals-to-google-analytics/)
- ** [Add some Events](/articles/analytics-and-optimisation/add-some-events/)
- ** [Setup Google Optimize](/articles/analytics-and-optimisation/setup-google-optimize/)
- ** [Create Google Analytics segments for Optimize experiments](/articles/analytics-and-optimisation/create-google-analytics-segments-for-optimize-experiments/)
- ** [Setting up users in Google Optimize](/articles/analytics-and-optimisation/setting-up-users-in-google-optimize/)
- ** [SessionCam](/articles/analytics-and-optimisation/sessioncam/)
- ** [GA4 Property IDs](/articles/analytics-and-optimisation/ga4-property-ids/)

   

#### Setup InsureWith Sites

 

---

 

   

#### Software Development - Principles

 

---

 

- ** [SOLID Principles](/articles/software-development-principles/solid-principles/)
- ** [KISS Principle](/articles/software-development-principles/kiss-principle/)
- ** [YAGNI Principle](/articles/software-development-principles/yagni-principle/)
- ** [Connexus ExceptionHelper and ExecResponse](/articles/software-development-principles/connexus-exceptionhelper-and-execresponse/)