[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Product - Park Homes and Static Caravan Legal Protection

 

---

 

Park Homes and Static Caravans Legal Protection provides one of the most comprehensive legal expenses insurance policies on the market providing up to £50,000 legal expenses cover for clients and their families.

 

## Product Details

  **Product Reference:** PARKHOMES **Product Type Id:** 705  

---

 

## Schemes

 

- [Park Homes and Static Caravans Legal Protection F&L](/insurance-products/lawshield-dsp-b2b/park-homes-and-static-caravan-legal-protection/park-homes-and-static-caravans-legal-protection-f-l/)

 

---