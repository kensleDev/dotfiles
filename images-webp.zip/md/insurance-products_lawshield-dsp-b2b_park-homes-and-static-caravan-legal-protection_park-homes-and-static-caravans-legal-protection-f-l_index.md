[Knowledgebase](/)     

- [Articles](/articles/)
- [Websites and Applications](/websites-and-applications/)
- [Servers](/servers/)
- [Insurance Products](/insurance-products/)
- [ARCHIVED](/archived/)

     

# Scheme - Park Homes and Static Caravans Legal Protection F&L

    **Underwriter:** Financial & Legal Insurance Company Limited **Net Premium:** £2.29     **UAT Scheme Table Id:** 1560 **UAT Scheme File Name:** 43I6VBM4.wpd  

---

  **Live Scheme Table Id:** 1521 **Live Scheme File Name:** 43ISBF19.wpd    

---

 

## Product

 

- [Park Homes and Static Caravan Legal Protection](/insurance-products/lawshield-dsp-b2b/park-homes-and-static-caravan-legal-protection/)

 

---

 

## Scheme Description

 

No rating logic required for the Park Homes and Static Caravan scheme. There is simply a DateDiff operation ensuring that policy start dates are on or after 1st January 2021 (when the scheme started).

 

---